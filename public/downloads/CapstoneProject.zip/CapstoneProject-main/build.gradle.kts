
plugins {
    // Remove the google-services plugin from here.
    // id("com.google.gms.google-services") version "4.4.2" apply true
    alias(libs.plugins.android.application) apply false
}

// You might also have a buildscript block; if so, ensure it includes:
buildscript {
    repositories {
        google()
        mavenCentral()
    }
    dependencies {
        // Note: Only include the google-services classpath here.
        classpath(libs.google.services)
    }
}




