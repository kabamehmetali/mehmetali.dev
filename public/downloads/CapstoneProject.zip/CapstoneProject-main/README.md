# 🌹 Rose Flower Delivery App

Welcome to the Rose Flower Delivery App, a capstone project developed collaboratively by [Mehmet Ali](https://github.com/kabamehmetali), [Miguel Angel Gutierrez](https://github.com/MigueGs), [Parisam Karimi](https://github.com/parisamkarimi), and [Pang](https://github.com/Sunkkadithee). This app simplifies the process of ordering and delivering flowers efficiently and reliably.

---

## 📖 Project Overview

Rose Flower Delivery App provides a seamless experience for clients, drivers, and store managers. Leveraging Firebase Firestore and Google Maps API, the app includes features such as real-time order tracking, optimized delivery route calculations, and user-friendly order management interfaces.

---

## ✨ Features

- **Real-Time Order Tracking**: View live updates of order statuses.
- **Driver Assignment & Management**: Efficient assignment of delivery tasks to available drivers.
- **Optimized Routing**: Integration with Google Directions API to ensure drivers take the fastest route.
- **User-Friendly Interface**: Simple, intuitive user interfaces for clients, drivers, and store managers.
- **Secure Authentication**: Managed via Firebase Authentication for secure login.
- **Persistent Cart Management**: Reliable cart management using SharedPreferences.
- **Live Location Updates**: Real-time tracking of driver locations with Firebase Firestore.

---

## 🚀 Getting Started

### Prerequisites

- Android Studio (latest version recommended)
- Java SDK
- Firebase Account (Firestore & Authentication enabled)
- Google Maps API key (Directions API & Maps SDK enabled)

### Installation

1. **Clone the repository**
   ```bash
   git clone https://github.com/kabamehmetali/CapstoneProject.git
   ```

2. **Setup Firebase**
   - Create a Firebase project and register your app.
   - Download `google-services.json` and add it to your app's `app/` directory.
   - Enable Firestore Database, Firebase Authentication.

3. **Setup Google Maps**
   - Obtain your Google Maps API key.
   - Add the API key in `google_maps_api.xml`.

4. **Build & Run**
   - Open the project in Android Studio.
   - Sync Gradle files.
   - Run the project on a virtual or physical Android device.

---

## 🛠️ Project Structure

```
RoseFlowerDelivery
├── adapters
│   ├── DriverOrdersAdapter.java
│   └── StoreOrdersAdapter.java
├── models
│   ├── Order.java
│   ├── Users.java
│   └── Location.java
├── repositories
│   ├── FirebaseOrderRepository.java
│   └── FirebaseStoreRepository.java
├── managers
│   ├── CartManager.java
│   ├── DriverAssignmentManager.java
│   ├── DriverLocationManager.java
│   ├── DriverOrderDialogManager.java
│   └── ClientLocationManager.java
├── ui
│   ├── fragments
│   │   └── DriverOrdersFragment.java
│   ├── activities
│   │   ├── DriverPage.java
│   │   └── DeliveryNavigationActivity.java
│   └── dialogs
│       └── OrderDialogManager.java
└── utils
    └── GoogleDirectionsUtil.java
```

---

## 🤝 Collaborators

- [Mehmet Ali](https://github.com/kabamehmetali)
- [Miguel Angel Gutierrez](https://github.com/MigueGs)
- [Parisam Karimi](https://github.com/parisamkarimi)
- [Pang](https://github.com/Sunkkadithee)

---

## 📜 License

Distributed under the MIT License. See `LICENSE` for more information.

---

## 📬 Contact

If you have questions or suggestions, please contact the project maintainer [Mehmet Ali](https://github.com/kabamehmetali).


## 🎨 Screenshots

![images](images/1.png)
![images](images/2.png)
![images](images/3.png)
![images](images/4.png)
![images](images/5.png)
![images](images/6.png)
![images](images/7.png)

