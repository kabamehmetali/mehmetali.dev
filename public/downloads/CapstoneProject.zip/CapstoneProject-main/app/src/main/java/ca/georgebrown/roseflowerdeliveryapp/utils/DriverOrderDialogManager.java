package ca.georgebrown.roseflowerdeliveryapp.utils;

import android.app.Dialog;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.firestore.GeoPoint;

import java.util.Locale;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Location;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

/**
 * Utility class for showing the driver’s order popup dialog.
 */
public class DriverOrderDialogManager {

    public interface DriverOrderDialogListener {
        void onAccept(Order order);
        void onReject(Order order);
    }

    /**
     * Displays the driver order popup with a 20-second timer, a map showing store and delivery locations,
     * a looping ringtone, and shows the computed distance and driver fee.
     *
     * @param context          the context
     * @param order            the order
     * @param driverId         the driver id (for reference)
     * @param storeName        the fetched store name from Firestore
     * @param storeLocation    the store location as a GeoPoint
     * @param storeAddress     the store address (readable)
     * @param deliveryLocation the delivery destination as a custom Location
     * @param deliveryAddress  the delivery address (readable)
     * @param listener         callback listener for accept/reject
     */
    public static void showDriverOrderPopup(Context context,
                                            Order order,
                                            String driverId,
                                            String storeName,
                                            GeoPoint storeLocation,
                                            String storeAddress,
                                            Location deliveryLocation,
                                            String deliveryAddress,
                                            DriverOrderDialogListener listener) {
        // Start playing the ringtone.
        final MediaPlayer mediaPlayer = MediaPlayer.create(context, R.raw.ringtone);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

        // Create and configure the dialog.
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_driver_order);

        if (dialog.getWindow() != null) {
            WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
            params.width = WindowManager.LayoutParams.WRAP_CONTENT;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.gravity = Gravity.CENTER;
            dialog.getWindow().setAttributes(params);
        }

        // Get references to the views in the layout.
        TextView tvOrderId        = dialog.findViewById(R.id.tvOrderId);
        TextView tvDriverMessage  = dialog.findViewById(R.id.tvDriverMessage);

        // NEW: store name text
        TextView tvStoreName      = dialog.findViewById(R.id.tvStoreName);

        TextView tvStoreAddress   = dialog.findViewById(R.id.tvStoreAddress);
        TextView tvDeliveryAddress= dialog.findViewById(R.id.tvDeliveryAddress);
        TextView tvTimer          = dialog.findViewById(R.id.tvTimer);
        TextView tvDistanceLabel  = dialog.findViewById(R.id.tvDistanceLabel);
        TextView tvDriverFeeLabel = dialog.findViewById(R.id.tvDriverFeeLabel);

        Button btnAccept          = dialog.findViewById(R.id.btnAccept);
        Button btnReject          = dialog.findViewById(R.id.btnReject);
        MapView mapView           = dialog.findViewById(R.id.mapViewOrder);

        // Set texts for order id, store name, store and delivery addresses.
        tvOrderId.setText("Order " + order.getId());
        tvDriverMessage.setText("New order assigned. Do you accept?");

        // Display the store name that we fetched from Firestore
        tvStoreName.setText("Store: " + (storeName != null ? storeName : "N/A"));

        // Store address is now labeled "Address: "
        tvStoreAddress.setText("Address: " + storeAddress);
        tvDeliveryAddress.setText("Delivery: " + deliveryAddress);

        // Calculate distance and driver fee.
        double distanceVal = (order.getDistance() != null && order.getDistance() > 0)
                ? order.getDistance()
                : computeDistance(storeLocation.getLatitude(), storeLocation.getLongitude(),
                deliveryLocation.getLatitude(), deliveryLocation.getLongitude());
        double driverFeeVal = (order.getDriverFee() != null && order.getDriverFee() > 0)
                ? order.getDriverFee()
                : (5.0 + distanceVal); // base fee + per km

        // Format the distance:
        String formattedDistance = formatDistance(distanceVal);
        tvDistanceLabel.setText("Distance: " + formattedDistance);
        tvDriverFeeLabel.setText(String.format(Locale.getDefault(), "Driver Fee: $%.2f", driverFeeVal));

        // Setup MapView.
        Bundle mapViewBundle = new Bundle();
        mapView.onCreate(mapViewBundle);
        mapView.onResume();
        MapsInitializer.initialize(context);
        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                LatLng storeLatLng = new LatLng(storeLocation.getLatitude(), storeLocation.getLongitude());
                googleMap.addMarker(new MarkerOptions().position(storeLatLng).title("Store Location"));

                LatLng deliveryLatLng = new LatLng(deliveryLocation.getLatitude(), deliveryLocation.getLongitude());
                googleMap.addMarker(new MarkerOptions().position(deliveryLatLng).title("Delivery Destination"));

                double centerLat = (storeLocation.getLatitude() + deliveryLocation.getLatitude()) / 2;
                double centerLng = (storeLocation.getLongitude() + deliveryLocation.getLongitude()) / 2;
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(centerLat, centerLng), 12));
            }
        });

        // Create a 20-second countdown timer.
        CountDownTimer timer = new CountDownTimer(20000, 1000) {
            public void onTick(long millisUntilFinished) {
                tvTimer.setText("Time remaining: " + millisUntilFinished / 1000 + "s");
            }
            public void onFinish() {
                tvTimer.setText("Time's up!");
                mediaPlayer.stop();
                mediaPlayer.release();
                dialog.dismiss();
                if (listener != null) {
                    listener.onReject(order);
                }
            }
        };
        timer.start();

        btnAccept.setOnClickListener(v -> {
            timer.cancel();
            mediaPlayer.stop();
            mediaPlayer.release();
            dialog.dismiss();
            if (listener != null) {
                listener.onAccept(order);
            }
        });

        btnReject.setOnClickListener(v -> {
            timer.cancel();
            mediaPlayer.stop();
            mediaPlayer.release();
            dialog.dismiss();
            if (listener != null) {
                listener.onReject(order);
            }
        });

        dialog.setCancelable(false);
        dialog.show();
    }

    /**
     * Computes the distance in kilometers between two geographic points using the Haversine formula.
     */
    private static double computeDistance(double lat1, double lng1, double lat2, double lng2) {
        double earthRadius = 6371; // km
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return earthRadius * c;
    }

    /**
     * Formats the distance value (m if <1km, else km with 2 decimals).
     */
    private static String formatDistance(double km) {
        if (km < 1.0) {
            double meters = km * 1000;
            return String.format(Locale.getDefault(), "%.0f m", meters);
        } else {
            return String.format(Locale.getDefault(), "%.2f km", km);
        }
    }
}
