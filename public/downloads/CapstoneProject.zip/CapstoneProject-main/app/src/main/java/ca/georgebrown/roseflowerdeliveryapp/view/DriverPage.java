package ca.georgebrown.roseflowerdeliveryapp.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.QueryDocumentSnapshot;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.databinding.ActivityDriverPageBinding;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;
import ca.georgebrown.roseflowerdeliveryapp.utils.DriverAssignmentManager;
import ca.georgebrown.roseflowerdeliveryapp.utils.DriverLocationManager;
import ca.georgebrown.roseflowerdeliveryapp.utils.DriverOrderDialogManager;

public class DriverPage extends AppCompatActivity {

    private ActivityDriverPageBinding binding;
    private FirebaseFirestore firestore;
    private String driverId;
    private SharedPreferences prefs;
    private static final String PREFS_NAME = "DriverDeliveryPrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDriverPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.driver_navigation_orders, R.id.navigation_dashboard, R.id.driver_navigation_profile
        ).build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_driver_page);
        NavigationUI.setupWithNavController(binding.navView, navController);

        // Start live location updates.
        DriverLocationManager.getInstance(this).startLocationUpdates();

        driverId = FirebaseAuth.getInstance().getUid();
        firestore = FirebaseFirestore.getInstance();
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        listenForAssignedOrders();
    }

    /**
     * Listen for orders with assignedDriverId == this driver and status=4 ("Ready for Pickup")
     * so we can show a pop-up dialog (accept/reject).
     */
    private void listenForAssignedOrders() {
        firestore.collectionGroup("orderItems")
                .whereEqualTo("assignedDriverId", driverId)
                .whereEqualTo("status", 4)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Log.e("DriverPage", "Error listening for orders: " + e.getMessage());
                        return;
                    }
                    if (snapshots != null && !snapshots.isEmpty()) {
                        for (QueryDocumentSnapshot doc : snapshots) {
                            Order order = doc.toObject(Order.class);
                            if (order != null) {
                                order.setId(doc.getId());

                                // Extract storeId from doc path: orders/{storeId}/orderItems/{orderId}
                                DocumentReference orderDocRef = doc.getReference();
                                final String orderStoreId = orderDocRef.getParent().getParent().getId();
                                if (orderStoreId == null || orderStoreId.trim().isEmpty()) {
                                    Log.e("DriverPage", "Order " + order.getId() + " has invalid store id.");
                                    continue;
                                }

                                // Fetch store info from "users/{storeId}"
                                firestore.collection("users")
                                        .document(orderStoreId)
                                        .get()
                                        .addOnSuccessListener(storeDoc -> {
                                            if (storeDoc.exists()) {
                                                // Retrieve store name from "users" doc
                                                String storeName = storeDoc.getString("storeName");
                                                if (storeName == null || storeName.isEmpty()) {
                                                    storeName = "Unknown Store";
                                                }
                                                // Retrieve store address + location
                                                Users storeUser = storeDoc.toObject(Users.class);
                                                String storeAddress = "N/A";
                                                GeoPoint storeLocationGeo = new GeoPoint(43.6532, -79.3832); // fallback
                                                if (storeUser != null && storeUser.getStoreLocation() != null) {
                                                    ca.georgebrown.roseflowerdeliveryapp.model.Location loc = storeUser.getStoreLocation();
                                                    storeAddress = (loc.getFormattedAddress() != null && !loc.getFormattedAddress().isEmpty())
                                                            ? loc.getFormattedAddress()
                                                            : "N/A";
                                                    storeLocationGeo = new GeoPoint(loc.getLatitude(), loc.getLongitude());
                                                }

                                                // Delivery location from order; fallback if missing
                                                ca.georgebrown.roseflowerdeliveryapp.model.Location deliveryLocation = order.getDeliveryLocation();
                                                if (deliveryLocation == null) {
                                                    deliveryLocation = new ca.georgebrown.roseflowerdeliveryapp.model.Location();
                                                    deliveryLocation.setLatitude(43.7000);
                                                    deliveryLocation.setLongitude(-79.4000);
                                                    deliveryLocation.setFormattedAddress("456 Queen St, Toronto, ON");
                                                    order.setDeliveryLocation(deliveryLocation);
                                                }
                                                final String deliveryAddress;
                                                if (deliveryLocation.getFormattedAddress() != null && !deliveryLocation.getFormattedAddress().isEmpty()) {
                                                    deliveryAddress = deliveryLocation.getFormattedAddress();
                                                } else if (deliveryLocation.getAddress() != null && !deliveryLocation.getAddress().isEmpty()) {
                                                    deliveryAddress = deliveryLocation.getAddress();
                                                } else {
                                                    deliveryAddress = "Delivery Address";
                                                }

                                                final String finalStoreName = storeName;
                                                final GeoPoint finalStoreLocationGeo = storeLocationGeo;
                                                final String finalStoreAddress = storeAddress;
                                                final ca.georgebrown.roseflowerdeliveryapp.model.Location finalDeliveryLocation = deliveryLocation;

                                                runOnUiThread(() -> {
                                                    // Show the driver order dialog
                                                    DriverOrderDialogManager.showDriverOrderPopup(
                                                            DriverPage.this,
                                                            order,
                                                            driverId,
                                                            finalStoreName,
                                                            finalStoreLocationGeo,
                                                            finalStoreAddress,
                                                            finalDeliveryLocation,
                                                            deliveryAddress,
                                                            new DriverOrderDialogManager.DriverOrderDialogListener() {
                                                                @Override
                                                                public void onAccept(Order order) {
                                                                    // (A) Immediately update the store doc:
                                                                    //     set status=5 (In Progress),
                                                                    //     AND storeName/storeId so the driver sees it right away.
                                                                    orderDocRef.update(
                                                                            "status", 5,
                                                                            "storeName", finalStoreName,
                                                                            "storeId", orderStoreId
                                                                    ).addOnSuccessListener(aVoid -> {
                                                                        Log.d("DriverPage", "Order " + order.getId() + " accepted with storeName.");

                                                                        // (B) Also save relevant fields into the driver's subcollection doc
                                                                        double distance = computeDistance(
                                                                                finalStoreLocationGeo.getLatitude(), finalStoreLocationGeo.getLongitude(),
                                                                                finalDeliveryLocation.getLatitude(), finalDeliveryLocation.getLongitude()
                                                                        );
                                                                        double driverFee = 5.0 + distance; // base + distance
                                                                        String orderPlacedDate = "";
                                                                        if (order.getTimestamp() != null) {
                                                                            orderPlacedDate = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                                                                                    .format(order.getTimestamp().toDate());
                                                                        }

                                                                        Map<String, Object> driverOrderData = new HashMap<>();
                                                                        driverOrderData.put("orderId", order.getId());
                                                                        driverOrderData.put("userName", order.getUserName());
                                                                        // put store info
                                                                        driverOrderData.put("storeId", orderStoreId);
                                                                        driverOrderData.put("storeName", finalStoreName);
                                                                        driverOrderData.put("storeAddress", finalStoreAddress);
                                                                        driverOrderData.put("storeLatitude", finalStoreLocationGeo.getLatitude());
                                                                        driverOrderData.put("storeLongitude", finalStoreLocationGeo.getLongitude());

                                                                        // put delivery info
                                                                        driverOrderData.put("deliveryAddress", deliveryAddress);
                                                                        driverOrderData.put("deliveryLatitude", finalDeliveryLocation.getLatitude());
                                                                        driverOrderData.put("deliveryLongitude", finalDeliveryLocation.getLongitude());

                                                                        // rest
                                                                        driverOrderData.put("distance", distance);
                                                                        driverOrderData.put("driverFee", driverFee);
                                                                        driverOrderData.put("orderItems", order.getOrderItems());
                                                                        driverOrderData.put("orderPlacedDate", orderPlacedDate);
                                                                        driverOrderData.put("status", 5);

                                                                        DocumentReference driverOrderRef = firestore.collection("drivers")
                                                                                .document(driverId)
                                                                                .collection("orders")
                                                                                .document(order.getId());
                                                                        driverOrderRef.set(driverOrderData)
                                                                                .addOnSuccessListener(unused -> {
                                                                                    Log.d("DriverPage", "Saved driver order data with store name.");
                                                                                    // Optionally fetch route
                                                                                    String directionsUrl = getDirectionsUrl(
                                                                                            new GeoPoint(finalStoreLocationGeo.getLatitude(), finalStoreLocationGeo.getLongitude()),
                                                                                            new GeoPoint(finalDeliveryLocation.getLatitude(), finalDeliveryLocation.getLongitude())
                                                                                    );
                                                                                    new FetchEncodedRouteTask(driverOrderRef).execute(directionsUrl);
                                                                                })
                                                                                .addOnFailureListener(err -> Log.e("DriverPage", "Error saving driver order data: " + err.getMessage()));

                                                                        // Launch the map screen right away
                                                                        Intent intent = new Intent(DriverPage.this, DeliveryNavigationActivity.class);
                                                                        intent.putExtra("orderId", order.getId());
                                                                        intent.putExtra("orderStoreId", orderStoreId);
                                                                        intent.putExtra("driverId", driverId);
                                                                        intent.putExtra("store_lat", finalStoreLocationGeo.getLatitude());
                                                                        intent.putExtra("store_lng", finalStoreLocationGeo.getLongitude());
                                                                        intent.putExtra("delivery_lat", finalDeliveryLocation.getLatitude());
                                                                        intent.putExtra("delivery_lng", finalDeliveryLocation.getLongitude());
                                                                        intent.putExtra("store_address", finalStoreAddress);
                                                                        intent.putExtra("delivery_address", deliveryAddress);
                                                                        intent.putExtra("orderStatus", 5);
                                                                        startActivity(intent);
                                                                    }).addOnFailureListener(err -> {
                                                                        Log.e("DriverPage", "Error updating order status: " + err.getMessage());
                                                                    });
                                                                }

                                                                @Override
                                                                public void onReject(Order order) {
                                                                    // status=6, assignedDriverId=null
                                                                    orderDocRef.update("status", 6, "assignedDriverId", null)
                                                                            .addOnSuccessListener(aVoid -> {
                                                                                Log.d("DriverPage", "Order " + order.getId() + " rejected.");
                                                                                // Update driver doc to status=6
                                                                                DocumentReference driverOrderRef = firestore.collection("drivers")
                                                                                        .document(driverId)
                                                                                        .collection("orders")
                                                                                        .document(order.getId());
                                                                                driverOrderRef.update("status", 6)
                                                                                        .addOnSuccessListener(aVoid2 -> Log.d("DriverPage", "Driver doc updated to rejected status."))
                                                                                        .addOnFailureListener(err -> Log.e("DriverPage", "Error updating driver doc: " + err.getMessage()));
                                                                                new DriverAssignmentManager(DriverPage.this)
                                                                                        .assignDriver(orderStoreId, order, new GeoPoint(43.6532, -79.3832));
                                                                            })
                                                                            .addOnFailureListener(err -> Log.e("DriverPage", "Error updating order status on rejection: " + err.getMessage()));
                                                                }
                                                            }
                                                    );
                                                });
                                            }
                                        })
                                        .addOnFailureListener(err -> Log.e("DriverPage", "Error fetching store document: " + err.getMessage()));
                            }
                        }
                    }
                });
    }

    /**
     * Compute distance in km using Haversine.
     */
    private double computeDistance(double lat1, double lng1, double lat2, double lng2) {
        double earthRadius = 6371; // km
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return earthRadius * c;
    }

    /**
     * Build the Google Directions API URL
     */
    private String getDirectionsUrl(GeoPoint origin, GeoPoint dest) {
        String str_origin = "origin=" + origin.getLatitude() + "," + origin.getLongitude();
        String str_dest = "destination=" + dest.getLatitude() + "," + dest.getLongitude();
        String mode = "mode=driving";
        String parameters = str_origin + "&" + str_dest + "&" + mode;
        String output = "json";
        String apiKey = getString(R.string.google_maps_key);
        return "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters + "&key=" + apiKey;
    }

    /**
     * AsyncTask to fetch the encoded route polyline from the Directions API and update driver doc.
     */
    private class FetchEncodedRouteTask extends AsyncTask<String, Void, String> {
        private DocumentReference driverOrderRef;

        public FetchEncodedRouteTask(DocumentReference ref) {
            driverOrderRef = ref;
        }

        @Override
        protected String doInBackground(String... urls) {
            String data = "";
            try {
                data = downloadUrl(urls[0]);
            } catch (Exception e) {
                Log.e("FetchRouteTask", "Error: " + e.getMessage());
            }
            try {
                JSONObject jsonObject = new JSONObject(data);
                JSONArray routes = jsonObject.getJSONArray("routes");
                if (routes.length() > 0) {
                    JSONObject route = routes.getJSONObject(0);
                    JSONObject overviewPolyline = route.getJSONObject("overview_polyline");
                    return overviewPolyline.getString("points");
                }
            } catch (JSONException e) {
                Log.e("FetchRouteTask", "JSON Error: " + e.getMessage());
            }
            return "";
        }

        @Override
        protected void onPostExecute(String encodedPolyline) {
            if (!encodedPolyline.isEmpty() && driverOrderRef != null) {
                driverOrderRef.update("routePolyline", encodedPolyline)
                        .addOnSuccessListener(aVoid ->
                                Log.d("DriverPage", "Route polyline updated in driver doc.")
                        )
                        .addOnFailureListener(e ->
                                Log.e("DriverPage", "Error updating route polyline: " + e.getMessage())
                        );
            }
        }

        private String downloadUrl(String strUrl) throws Exception {
            StringBuilder sb = new StringBuilder();
            URL url = new URL(strUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.connect();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
            }
            return sb.toString();
        }
    }

    public void driverLogoutBtn(View view) {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(this, LoginPage.class);
        startActivity(intent);
        finish();
    }
}
