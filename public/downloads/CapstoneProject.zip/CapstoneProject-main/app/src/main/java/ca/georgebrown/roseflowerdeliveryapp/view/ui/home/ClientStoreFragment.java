package ca.georgebrown.roseflowerdeliveryapp.view.ui.home;

import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.widget.Toolbar;
import androidx.coordinatorlayout.widget.CoordinatorLayout;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.google.android.material.floatingactionbutton.FloatingActionButton;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.ClientStoreCategoryAdapter;
import ca.georgebrown.roseflowerdeliveryapp.model.Category;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;
import ca.georgebrown.roseflowerdeliveryapp.utils.CartManager;

public class ClientStoreFragment extends Fragment {

    private static final String TAG = "ClientStoreFragment";

    private RecyclerView rvCategories;
    private ClientStoreCategoryAdapter categoryAdapter;
    private ClientStoreViewModel viewModel;
    private String storeId; // Must be non-null when passed
    private Toolbar toolbar;
    private ImageView ivStoreImage;
    private TextView tvStoreName;
    private TextView tvStoreDescription;
    private TextView tvStoreLocation;

    // Variables for store coordinates and logo.
    private double storeLatitude = 0.0;
    private double storeLongitude = 0.0;
    private String storeLogoUrl = "";

    // Backup list for original categories (used for filtering).
    private final List<Category> originalCategories = new ArrayList<>();

    // Cart FloatingActionButton and badge.
    private FloatingActionButton fabCart;
    private TextView tvCartBadge;

    public ClientStoreFragment() {
        // Required empty public constructor.
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            storeId = getArguments().getString("storeId");
            Log.d(TAG, "Received storeId: " + storeId);
        } else {
            Log.e(TAG, "No storeId argument found!");
        }
        setHasOptionsMenu(true);
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View rootView = inflater.inflate(R.layout.fragment_client_store, container, false);

        // Set up toolbar with back button.
        toolbar = rootView.findViewById(R.id.toolbar);
        toolbar.setTitle("Store Menu");
        toolbar.setNavigationIcon(R.drawable.back);
        toolbar.setNavigationOnClickListener(v -> Navigation.findNavController(rootView).navigateUp());

        // Bind header views.
        ivStoreImage = rootView.findViewById(R.id.ivStoreImage);
        tvStoreName = rootView.findViewById(R.id.tvStoreName);
        tvStoreDescription = rootView.findViewById(R.id.tvStoreDescription);
        tvStoreLocation = rootView.findViewById(R.id.tvStoreLocation);

        // Bind cart views.
        fabCart = rootView.findViewById(R.id.fabCart);
        tvCartBadge = rootView.findViewById(R.id.tvCartBadge);

        fabCart.setOnClickListener(v -> {
            updateCartCounter();
            CartDialogFragment cartDialogFragment = new CartDialogFragment();
            cartDialogFragment.show(getChildFragmentManager(), "CartDialog");
        });

        // Listen for cart update events so that the counter is updated in real time.
        getChildFragmentManager().setFragmentResultListener("itemAddedKey", this, (requestKey, bundle) -> {
            if (bundle.getBoolean("itemAdded", false)) {
                updateCartCounter();
            }
        });
        getChildFragmentManager().setFragmentResultListener("cartUpdatedKey", this, (requestKey, bundle) -> {
            if (bundle.getBoolean("cartUpdated", false)) {
                updateCartCounter();
            }
        });

        // Make the store location clickable to open a location dialog.
        tvStoreLocation.setClickable(true);
        tvStoreLocation.setOnClickListener(v -> {
            if (storeLatitude != 0.0 && storeLongitude != 0.0) {
                StoreLocationDialogFragment dialog = StoreLocationDialogFragment.newInstance(
                        tvStoreName.getText().toString(),
                        tvStoreLocation.getText().toString(),
                        storeLogoUrl,
                        storeLatitude,
                        storeLongitude);
                dialog.show(getChildFragmentManager(), "StoreLocationDialog");
            }
        });

        // Set up RecyclerView for categories.
        rvCategories = rootView.findViewById(R.id.rvCategories);
        rvCategories.setLayoutManager(new LinearLayoutManager(getContext()));
        categoryAdapter = new ClientStoreCategoryAdapter(getContext());
        categoryAdapter.setOnItemClickListener(item -> {
            ClientItemDetailDialogFragment detailDialog = ClientItemDetailDialogFragment.newInstance(item);
            detailDialog.show(getChildFragmentManager(), "ItemDetailDialog");
        });
        rvCategories.setAdapter(categoryAdapter);

        // Set up search EditText with TextWatcher.
        EditText etSearch = rootView.findViewById(R.id.etSearch);
        etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applySearchFilter(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });

        // Load store header info.
        loadStoreInfo();

        // Set up ViewModel to load menu categories.
        viewModel = new ViewModelProvider(this).get(ClientStoreViewModel.class);
        viewModel.getCategoriesLiveData().observe(getViewLifecycleOwner(), categories -> {
            if (categories != null) {
                originalCategories.clear();
                originalCategories.addAll(categories);
                // Apply the search filter in case there is text already.
                applySearchFilter(etSearch.getText().toString());
            } else {
                Log.d(TAG, "No categories found for storeId: " + storeId);
            }
        });
        if (storeId != null) {
            viewModel.loadMenu(storeId);
        } else {
            Log.e(TAG, "storeId is null. Cannot load menu data.");
        }

        return rootView;
    }

    /**
     * Filters the categories and their items based on the search query.
     * @param query The search text entered by the user.
     */
    private void applySearchFilter(String query) {
        String searchQuery = query.toLowerCase().trim();
        List<Category> filteredCategories = new ArrayList<>();
        for (Category category : originalCategories) {
            boolean categoryMatch = category.getName().toLowerCase().contains(searchQuery);
            List<Item> filteredItems = new ArrayList<>();
            if (category.getItems() != null) {
                for (Item item : category.getItems()) {
                    boolean itemMatch = item.getName().toLowerCase().contains(searchQuery)
                            || item.getDescription().toLowerCase().contains(searchQuery);
                    if (itemMatch) {
                        filteredItems.add(item);
                    }
                }
            }
            // If the category name matches or any items match, add it to the filtered list.
            if (categoryMatch || !filteredItems.isEmpty()) {
                Category newCategory = new Category();
                newCategory.setId(category.getId());
                newCategory.setName(category.getName());
                newCategory.setDescription(category.getDescription());
                newCategory.setPriority(category.getPriority());
                newCategory.setUserId(category.getUserId());
                newCategory.setItems(filteredItems);
                filteredCategories.add(newCategory);
            }
        }
        categoryAdapter.setCategories(filteredCategories);
    }

    /**
     * Loads store header information from the "users" collection.
     * Displays store name, description, image, and a full address that is clickable.
     */
    private void loadStoreInfo() {
        if (storeId == null) {
            Log.e(TAG, "storeId is null. Cannot load store header info.");
            return;
        }
        FirebaseFirestore.getInstance()
                .collection("users")
                .document(storeId)
                .get()
                .addOnSuccessListener((DocumentSnapshot documentSnapshot) -> {
                    if (documentSnapshot.exists()) {
                        Users store = documentSnapshot.toObject(Users.class);
                        if (store != null) {
                            tvStoreName.setText(store.getStoreName() != null ? store.getStoreName() : "Store");
                            tvStoreDescription.setText(store.getDescription() != null ? store.getDescription() : "");
                            if (store.getImageUrl() != null && !store.getImageUrl().isEmpty()) {
                                storeLogoUrl = store.getImageUrl();
                                Picasso.get().load(storeLogoUrl).into(ivStoreImage);
                            } else {
                                ivStoreImage.setImageResource(R.drawable.pictureselect);
                            }
                            // Process store location
                            if (store.getStoreLocation() != null) {
                                storeLatitude = store.getStoreLocation().getLatitude();
                                storeLongitude = store.getStoreLocation().getLongitude();
                                // Use Geocoder to obtain a full, human-readable address.
                                Geocoder geocoder = new Geocoder(getContext(), Locale.getDefault());
                                try {
                                    List<Address> addresses = geocoder.getFromLocation(storeLatitude, storeLongitude, 1);
                                    if (addresses != null && !addresses.isEmpty()) {
                                        Address address = addresses.get(0);
                                        StringBuilder fullAddress = new StringBuilder();
                                        if (address.getAddressLine(0) != null) {
                                            fullAddress.append(address.getAddressLine(0));
                                        }
                                        if (address.getLocality() != null) {
                                            if (fullAddress.length() > 0) fullAddress.append(", ");
                                            fullAddress.append(address.getLocality());
                                        }
                                        if (address.getAdminArea() != null) {
                                            if (fullAddress.length() > 0) fullAddress.append(", ");
                                            fullAddress.append(address.getAdminArea());
                                        }
                                        if (address.getPostalCode() != null) {
                                            if (fullAddress.length() > 0) fullAddress.append(", ");
                                            fullAddress.append(address.getPostalCode());
                                        }
                                        tvStoreLocation.setText(fullAddress.toString());
                                    } else {
                                        tvStoreLocation.setText("Location not available");
                                    }
                                } catch (IOException e) {
                                    e.printStackTrace();
                                    tvStoreLocation.setText("Location not available");
                                }
                            } else {
                                tvStoreLocation.setText("Location not available");
                            }
                            Log.d(TAG, "Loaded store header info from users collection.");
                        } else {
                            Log.e(TAG, "Store object is null.");
                        }
                    } else {
                        Log.e(TAG, "Store document does not exist for storeId: " + storeId);
                    }
                })
                .addOnFailureListener(e -> Log.e(TAG, "Failed to load store info", e));
    }

    /**
     * Updates the cart counter badge with the current number of items.
     */
    private void updateCartCounter() {
        int count = CartManager.getInstance(getContext()).getCartItemCount();
        if (tvCartBadge != null) {
            if (count > 0) {
                tvCartBadge.setVisibility(View.VISIBLE);
                tvCartBadge.setText(String.valueOf(count));
            } else {
                tvCartBadge.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        updateCartCounter();
    }
}
