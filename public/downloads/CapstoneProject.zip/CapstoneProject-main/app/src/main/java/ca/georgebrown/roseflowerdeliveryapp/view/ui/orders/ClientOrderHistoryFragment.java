package ca.georgebrown.roseflowerdeliveryapp.view.ui.orders;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.ClientOrderHistoryAdapter;
import ca.georgebrown.roseflowerdeliveryapp.databinding.ClientFragmentOrderHistoryBinding;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class ClientOrderHistoryFragment extends Fragment {

    private ClientFragmentOrderHistoryBinding binding;
    private ClientOrderHistoryAdapter adapter;
    private List<Order> orderList = new ArrayList<>();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        binding = ClientFragmentOrderHistoryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Setup RecyclerView
        adapter = new ClientOrderHistoryAdapter(requireContext(), orderList);
        binding.recyclerOrderHistory.setLayoutManager(new LinearLayoutManager(getContext()));
        binding.recyclerOrderHistory.setAdapter(adapter);

        // "No orders" state: When "Order Now" button is clicked, navigate to home fragment.
        binding.layoutNoOrders.btnOrderNow.setOnClickListener(v -> {
            Navigation.findNavController(v).navigate(R.id.client_navigation_home);
        });

        subscribeToOrders();

        return root;
    }

    private void subscribeToOrders() {
        String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        FirebaseFirestore.getInstance()
                .collectionGroup("orderItems")
                .whereEqualTo("userId", userId)
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .addSnapshotListener((QuerySnapshot querySnapshot, com.google.firebase.firestore.FirebaseFirestoreException e) -> {
                    if (e != null) {
                        Toast.makeText(getContext(), "Error loading orders: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        return;
                    }
                    if (querySnapshot != null) {
                        orderList.clear();
                        querySnapshot.getDocuments().forEach(doc -> {
                            Order order = doc.toObject(Order.class);
                            if (order != null) {
                                order.setId(doc.getId());
                                orderList.add(order);
                            }
                        });
                        adapter.notifyDataSetChanged();
                        toggleEmptyState();
                    }
                });
    }

    private void toggleEmptyState() {
        if (binding == null) return;
        if (orderList.isEmpty()) {
            binding.recyclerOrderHistory.setVisibility(View.GONE);
            binding.layoutNoOrders.getRoot().setVisibility(View.VISIBLE);
        } else {
            binding.recyclerOrderHistory.setVisibility(View.VISIBLE);
            binding.layoutNoOrders.getRoot().setVisibility(View.GONE);
        }
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
