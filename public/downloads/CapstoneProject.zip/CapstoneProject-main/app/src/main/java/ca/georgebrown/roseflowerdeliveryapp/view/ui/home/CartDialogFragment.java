package ca.georgebrown.roseflowerdeliveryapp.view.ui.home;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.location.Address;
import android.location.Geocoder;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.ViewGroup.LayoutParams;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.libraries.places.api.Places;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;
import com.google.android.material.textview.MaterialTextView;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.CartAdapter;
import ca.georgebrown.roseflowerdeliveryapp.adapter.PlaceAutoSuggestAdapter;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;
import ca.georgebrown.roseflowerdeliveryapp.utils.CartManager;
import ca.georgebrown.roseflowerdeliveryapp.utils.CircleTransform;

public class CartDialogFragment extends DialogFragment implements OnMapReadyCallback {

    private RecyclerView recyclerCartItems;
    private Button btnPlaceOrder, btnClearCart, btnAddMore;
    private ImageButton btnCloseDialog;
    private ImageView ivStoreImage;
    private MaterialTextView tvStoreName, tvStoreLocation;
    private MaterialTextView tvTotalItems, tvSubtotal, tvDeliveryFee, tvTax, tvGrandTotal;
    // Delivery location views
    private AutoCompleteTextView actvDeliveryLocation;
    private MapView mapViewDelivery;
    private GoogleMap googleMapDelivery;
    private LatLng deliveryLatLng = null;
    private String deliveryAddress = "";

    // Store coordinates and logo
    private double storeLatitude = 0.0;
    private double storeLongitude = 0.0;
    private String storeLogoUrl = "";

    // SharedPreferences keys
    private static final String PREFS_NAME = "cart_prefs";
    private static final String KEY_DELIVERY_ADDRESS = "lastDeliveryAddress";
    private static final String KEY_DELIVERY_LAT = "lastDeliveryLat";
    private static final String KEY_DELIVERY_LNG = "lastDeliveryLng";

    // Hold the cart items for summary updates.
    private List<CartItem> cartItems;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.client_cart_dialog, container, false);
        recyclerCartItems = view.findViewById(R.id.recyclerCartItems);
        btnPlaceOrder = view.findViewById(R.id.btnPlaceOrder);
        btnClearCart = view.findViewById(R.id.btnClearCart);
        btnAddMore = view.findViewById(R.id.btnAddMore);
        btnCloseDialog = view.findViewById(R.id.btnCloseDialog);
        ivStoreImage = view.findViewById(R.id.ivStoreImage);
        tvStoreName = view.findViewById(R.id.tvStoreName);
        tvStoreLocation = view.findViewById(R.id.tvStoreLocation);
        tvTotalItems = view.findViewById(R.id.tvTotalItems);
        tvSubtotal = view.findViewById(R.id.tvSubtotal);
        tvDeliveryFee = view.findViewById(R.id.tvDeliveryFee);
        tvTax = view.findViewById(R.id.tvTax);
        tvGrandTotal = view.findViewById(R.id.tvGrandTotal);
        actvDeliveryLocation = view.findViewById(R.id.actvDeliveryLocation);
        mapViewDelivery = view.findViewById(R.id.mapViewDelivery);
        return view;
    }

    @Override
    public void onStart() {
        super.onStart();
        // Force the dialog to full screen.
        Dialog dialog = getDialog();
        if (dialog != null && dialog.getWindow() != null) {
            dialog.getWindow().setLayout(LayoutParams.MATCH_PARENT, LayoutParams.MATCH_PARENT);
        }
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        super.onViewCreated(view, savedInstanceState);

        // Initialize Places if not already initialized.
        if (!Places.isInitialized()) {
            Places.initialize(getContext(), getString(R.string.google_maps_key));
        }

        // Setup auto-suggest adapter
        PlaceAutoSuggestAdapter autoSuggestAdapter = new PlaceAutoSuggestAdapter(getContext(),
                android.R.layout.simple_dropdown_item_1line,
                Places.createClient(getContext()));
        actvDeliveryLocation.setAdapter(autoSuggestAdapter);
        actvDeliveryLocation.setThreshold(1);
        actvDeliveryLocation.setOnItemClickListener((parent, view1, position, id) -> {
            deliveryAddress = (String) parent.getItemAtPosition(position);
            actvDeliveryLocation.setText(deliveryAddress);
            Geocoder geocoder = new Geocoder(getContext(), Locale.getDefault());
            try {
                List<Address> addresses = geocoder.getFromLocationName(deliveryAddress, 1);
                if (addresses != null && !addresses.isEmpty()) {
                    Address address = addresses.get(0);
                    deliveryLatLng = new LatLng(address.getLatitude(), address.getLongitude());
                    mapViewDelivery.setVisibility(View.VISIBLE);
                    mapViewDelivery.onCreate(null);
                    mapViewDelivery.getMapAsync(CartDialogFragment.this);
                    saveDeliveryLocation();
                    updateSummary(cartItems);
                } else {
                    Toast.makeText(getContext(), "Location not found", Toast.LENGTH_SHORT).show();
                    mapViewDelivery.setVisibility(View.GONE);
                    deliveryLatLng = null;
                    updateSummary(cartItems);
                }
            } catch (IOException e) {
                e.printStackTrace();
                Toast.makeText(getContext(), "Error retrieving location", Toast.LENGTH_SHORT).show();
                mapViewDelivery.setVisibility(View.GONE);
                deliveryLatLng = null;
                updateSummary(cartItems);
            }
        });

        // Watch for empty location input
        actvDeliveryLocation.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.toString().trim().isEmpty()){
                    deliveryLatLng = null;
                    mapViewDelivery.setVisibility(View.GONE);
                    updateSummary(cartItems);
                }
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });

        // Restore saved location
        restoreDeliveryLocation();

        // Close button
        btnCloseDialog.setOnClickListener(v -> {
            sendCartUpdateResult();
            dismiss();
        });

        cartItems = CartManager.getInstance(getContext()).getCartItems();
        if (cartItems == null || cartItems.isEmpty()) {
            Toast.makeText(getContext(), "Your cart is empty", Toast.LENGTH_SHORT).show();
            sendCartUpdateResult();
            dismiss();
            return;
        }

        // Set up RecyclerView
        CartAdapter cartAdapter = new CartAdapter(cartItems, getContext());
        recyclerCartItems.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerCartItems.setAdapter(cartAdapter);
        cartAdapter.setOnCartChangedListener(updatedCartItems -> {
            cartItems = updatedCartItems;
            updateSummary(cartItems);
            if (updatedCartItems.isEmpty()) {
                Toast.makeText(getContext(), "No items in your cart", Toast.LENGTH_SHORT).show();
                sendCartUpdateResult();
                dismiss();
            }
        });

        updateSummary(cartItems);

        // Fetch store details
        String cartStoreId = CartManager.getInstance(getContext()).getCartStoreId();
        if (cartStoreId != null) {
            FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(cartStoreId)
                    .get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            Users store = documentSnapshot.toObject(Users.class);
                            if (store != null) {
                                tvStoreName.setText((store.getStoreName() != null && !store.getStoreName().isEmpty())
                                        ? store.getStoreName() : "Store");
                                if (store.getImageUrl() != null && !store.getImageUrl().isEmpty()) {
                                    storeLogoUrl = store.getImageUrl();
                                    Picasso.get()
                                            .load(storeLogoUrl)
                                            .transform(new CircleTransform())
                                            .into(ivStoreImage);
                                } else {
                                    ivStoreImage.setImageResource(R.drawable.pictureselect);
                                }
                                if (store.getStoreLocation() != null) {
                                    storeLatitude = store.getStoreLocation().getLatitude();
                                    storeLongitude = store.getStoreLocation().getLongitude();
                                    Geocoder geocoder = new Geocoder(getContext(), Locale.getDefault());
                                    try {
                                        List<Address> addresses = geocoder.getFromLocation(storeLatitude, storeLongitude, 1);
                                        if (addresses != null && !addresses.isEmpty()) {
                                            Address address = addresses.get(0);
                                            StringBuilder fullAddress = new StringBuilder();
                                            if (address.getAddressLine(0) != null) {
                                                fullAddress.append(address.getAddressLine(0));
                                            }
                                            if (address.getLocality() != null) {
                                                if (fullAddress.length() > 0) fullAddress.append(", ");
                                                fullAddress.append(address.getLocality());
                                            }
                                            if (address.getAdminArea() != null) {
                                                if (fullAddress.length() > 0) fullAddress.append(", ");
                                                fullAddress.append(address.getAdminArea());
                                            }
                                            if (address.getPostalCode() != null) {
                                                if (fullAddress.length() > 0) fullAddress.append(", ");
                                                fullAddress.append(address.getPostalCode());
                                            }
                                            String readableAddress = fullAddress.toString();
                                            tvStoreLocation.setText(readableAddress);
                                            tvStoreLocation.setClickable(true);
                                            tvStoreLocation.setOnClickListener(v -> {
                                                StoreLocationDialogFragment dialogFragment = StoreLocationDialogFragment.newInstance(
                                                        store.getStoreName() != null ? store.getStoreName() : "Store",
                                                        readableAddress,
                                                        storeLogoUrl,
                                                        storeLatitude,
                                                        storeLongitude);
                                                dialogFragment.show(getChildFragmentManager(), "StoreLocationDialog");
                                            });
                                        } else {
                                            tvStoreLocation.setText("Location not available");
                                        }
                                    } catch (IOException e) {
                                        e.printStackTrace();
                                        tvStoreLocation.setText("Location not available");
                                    }
                                    updateSummary(cartItems);
                                } else {
                                    tvStoreLocation.setText("Location not available");
                                }
                            }
                        }
                    });
        }

        btnPlaceOrder.setOnClickListener(v -> placeOrder(cartItems));

        btnClearCart.setOnClickListener(v -> {
            new AlertDialog.Builder(getContext())
                    .setTitle("Clear Cart")
                    .setMessage("Are you sure you want to clear your cart?")
                    .setPositiveButton("Clear", (dialog, which) -> {
                        CartManager.getInstance(getContext()).clearCart();
                        Toast.makeText(getContext(), "Cart cleared", Toast.LENGTH_SHORT).show();
                        sendCartUpdateResult();
                        dismiss();
                    })
                    .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                    .show();
        });

        btnAddMore.setOnClickListener(v -> {
            sendCartUpdateResult();
            dismiss();
        });
    }

    private void updateSummary(List<CartItem> cartItems) {
        int totalItems = 0;
        double subtotal = 0.0;
        for (CartItem cartItem : cartItems) {
            totalItems += cartItem.getQuantity();
            subtotal += cartItem.getItem().getPrice() * cartItem.getQuantity();
        }
        double deliveryFee = calculateDeliveryFee();
        double distanceKm = calculateDistanceKm();
        double tax = (subtotal + deliveryFee) * 0.13;
        double grandTotal = subtotal + deliveryFee + tax;

        tvTotalItems.setText("Total Items: " + totalItems);
        tvSubtotal.setText(String.format("Subtotal: $%.2f", subtotal));
        tvDeliveryFee.setText(String.format("Delivery Fee: $%.2f (%.2f km)", deliveryFee, distanceKm));
        tvTax.setText(String.format("Tax (13%%): $%.2f", tax));
        tvGrandTotal.setText(String.format("Grand Total: $%.2f", grandTotal));
    }

    private double calculateDistanceKm() {
        if (deliveryLatLng == null || storeLatitude == 0.0 || storeLongitude == 0.0) {
            return 0.0;
        }
        float[] results = new float[1];
        android.location.Location.distanceBetween(
                storeLatitude, storeLongitude,
                deliveryLatLng.latitude, deliveryLatLng.longitude,
                results
        );
        double distanceInKm = results[0] / 1000.0;
        return Math.round(distanceInKm * 100.0) / 100.0;
    }

    private double calculateDeliveryFee() {
        if (deliveryLatLng == null) {
            return 0.0;
        }
        double km = calculateDistanceKm();
        if (km < 5) {
            return 5.0; // minimum fee
        } else {
            return km * 1.0; // $1 per km
        }
    }

    private void placeOrder(List<CartItem> cartItems) {
        // Check for unavailable items
        List<CartItem> unavailableItems = new ArrayList<>();
        for (CartItem cartItem : cartItems) {
            if (!cartItem.getItem().isAvailable()) {
                unavailableItems.add(cartItem);
            }
        }
        if (!unavailableItems.isEmpty()) {
            StringBuilder names = new StringBuilder();
            for (CartItem ci : unavailableItems) {
                if (names.length() > 0) names.append(", ");
                names.append(ci.getItem().getName());
            }
            new AlertDialog.Builder(getContext())
                    .setTitle("Unavailable Items")
                    .setMessage("The following items are no longer available: " + names.toString())
                    .setPositiveButton("OK", (dialog, which) -> dialog.dismiss())
                    .show();
            return;
        }

        // Require delivery location
        if (deliveryLatLng == null || deliveryAddress.isEmpty()) {
            Toast.makeText(getContext(), "Please select a delivery location.", Toast.LENGTH_SHORT).show();
            return;
        }

        double computedSubtotal = 0.0;
        for (CartItem cartItem : cartItems) {
            computedSubtotal += cartItem.getItem().getPrice() * cartItem.getQuantity();
        }
        final double subtotal = computedSubtotal;
        final double deliveryFee = calculateDeliveryFee();
        final double tax = (subtotal + deliveryFee) * 0.13;
        final double total = subtotal + deliveryFee + tax;

        final String cartStoreId = CartManager.getInstance(getContext()).getCartStoreId();
        final String userId = FirebaseAuth.getInstance().getCurrentUser().getUid();

        FirebaseFirestore.getInstance()
                .collection("users")
                .document(userId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    String userName = "";
                    if (documentSnapshot.exists()) {
                        String firstName = documentSnapshot.getString("firstName");
                        String lastName = documentSnapshot.getString("lastName");
                        if (firstName != null && lastName != null) {
                            userName = firstName + " " + lastName;
                        } else {
                            userName = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                        }
                    } else {
                        userName = FirebaseAuth.getInstance().getCurrentUser().getEmail();
                    }

                    Map<String, Object> orderData = new HashMap<>();
                    orderData.put("status", 1);
                    orderData.put("orderItems", cartItems);
                    orderData.put("timestamp", FieldValue.serverTimestamp());
                    orderData.put("userId", userId);
                    orderData.put("userName", userName);

                    Map<String, Object> deliveryLocation = new HashMap<>();
                    deliveryLocation.put("address", deliveryAddress);
                    deliveryLocation.put("latitude", deliveryLatLng.latitude);
                    deliveryLocation.put("longitude", deliveryLatLng.longitude);
                    orderData.put("deliveryLocation", deliveryLocation);

                    orderData.put("subtotal", subtotal);
                    orderData.put("deliveryFee", deliveryFee);
                    orderData.put("tax", tax);
                    orderData.put("total", total);

                    FirebaseFirestore.getInstance()
                            .collection("orders")
                            .document(cartStoreId)
                            .collection("orderItems")
                            .add(orderData)
                            .addOnSuccessListener(documentReference -> {
                                CartManager.getInstance(getContext()).clearCart();
                                Toast.makeText(getContext(), "Order placed successfully", Toast.LENGTH_SHORT).show();
                                sendCartUpdateResult();
                                dismiss();
                            })
                            .addOnFailureListener(e -> {
                                Toast.makeText(getContext(), "Order placement failed: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                            });
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(getContext(), "Failed to retrieve user info: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                });
    }

    private void saveDeliveryLocation() {
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_DELIVERY_ADDRESS, deliveryAddress);
        if (deliveryLatLng != null) {
            editor.putString(KEY_DELIVERY_LAT, String.valueOf(deliveryLatLng.latitude));
            editor.putString(KEY_DELIVERY_LNG, String.valueOf(deliveryLatLng.longitude));
        }
        editor.apply();
    }

    private void restoreDeliveryLocation() {
        SharedPreferences prefs = getContext().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String savedAddress = prefs.getString(KEY_DELIVERY_ADDRESS, "");
        String savedLat = prefs.getString(KEY_DELIVERY_LAT, "");
        String savedLng = prefs.getString(KEY_DELIVERY_LNG, "");
        if (!savedAddress.isEmpty() && !savedLat.isEmpty() && !savedLng.isEmpty()) {
            deliveryAddress = savedAddress;
            actvDeliveryLocation.setText(deliveryAddress);
            try {
                double lat = Double.parseDouble(savedLat);
                double lng = Double.parseDouble(savedLng);
                deliveryLatLng = new LatLng(lat, lng);
                mapViewDelivery.setVisibility(View.VISIBLE);
                mapViewDelivery.onCreate(null);
                mapViewDelivery.getMapAsync(this);
            } catch (NumberFormatException e) {
                e.printStackTrace();
            }
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        googleMapDelivery = googleMap;
        if (deliveryLatLng != null) {
            googleMapDelivery.clear();
            googleMapDelivery.addMarker(new MarkerOptions().position(deliveryLatLng).title("Delivery Location"));
            googleMapDelivery.moveCamera(CameraUpdateFactory.newLatLngZoom(deliveryLatLng, 15f));
        }
    }

    private void sendCartUpdateResult() {
        Bundle result = new Bundle();
        result.putBoolean("cartUpdated", true);
        getParentFragmentManager().setFragmentResult("cartUpdatedKey", result);
    }

    @Override
    public void onResume() {
        super.onResume();
        if (mapViewDelivery != null) {
            mapViewDelivery.onResume();
        }
    }

    @Override
    public void onPause() {
        if (mapViewDelivery != null) {
            mapViewDelivery.onPause();
        }
        super.onPause();
    }

    @Override
    public void onDestroy() {
        if (mapViewDelivery != null) {
            mapViewDelivery.onDestroy();
        }
        super.onDestroy();
    }

    @Override
    public void onLowMemory() {
        super.onLowMemory();
        if (mapViewDelivery != null) {
            mapViewDelivery.onLowMemory();
        }
    }
}
