package ca.georgebrown.roseflowerdeliveryapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;

public class OrderItemsAdapter extends RecyclerView.Adapter<OrderItemsAdapter.OrderItemViewHolder> {

    private List<CartItem> cartItems;
    private Context context;

    public OrderItemsAdapter(Context context, List<CartItem> cartItems) {
        this.context = context;
        this.cartItems = cartItems;
    }

    @NonNull
    @Override
    public OrderItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_store_order_item, parent, false);
        return new OrderItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderItemViewHolder holder, int position) {
        CartItem cartItem = cartItems.get(position);
        Item item = cartItem.getItem();
        if (item != null) {
            holder.tvItemName.setText(item.getName());
            holder.tvItemDescription.setText(item.getDescription() != null ? item.getDescription() : "");
            if (cartItem.getNote() != null && !cartItem.getNote().isEmpty()) {
                holder.tvItemNote.setText("Note: " + cartItem.getNote());
            } else {
                holder.tvItemNote.setText("Note: None");
            }
            holder.tvItemQuantity.setText("Qty: " + cartItem.getQuantity());
            if (item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
                Picasso.get().load(item.getImageUrl()).into(holder.ivItemImage);
            } else {
                holder.ivItemImage.setImageResource(R.drawable.pictureselect);
            }
        }
    }

    @Override
    public int getItemCount() {
        return (cartItems != null) ? cartItems.size() : 0;
    }

    static class OrderItemViewHolder extends RecyclerView.ViewHolder {
        ImageView ivItemImage;
        TextView tvItemName, tvItemDescription, tvItemNote, tvItemQuantity;

        public OrderItemViewHolder(@NonNull View itemView) {
            super(itemView);
            ivItemImage = itemView.findViewById(R.id.ivStoreOrderItemImage);
            tvItemName = itemView.findViewById(R.id.tvStoreOrderItemName);
            tvItemDescription = itemView.findViewById(R.id.tvStoreOrderItemDescription);
            tvItemNote = itemView.findViewById(R.id.tvStoreOrderItemNote);
            tvItemQuantity = itemView.findViewById(R.id.tvStoreOrderItemQuantity);
        }
    }
}
