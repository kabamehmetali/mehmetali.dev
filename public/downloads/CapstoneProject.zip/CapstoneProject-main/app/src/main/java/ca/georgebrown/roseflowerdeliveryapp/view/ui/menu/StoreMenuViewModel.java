package ca.georgebrown.roseflowerdeliveryapp.view.ui.menu;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import android.net.Uri;
import java.util.List;
import ca.georgebrown.roseflowerdeliveryapp.model.Category;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseMenuRepository;

public class StoreMenuViewModel extends ViewModel {

    private final MutableLiveData<List<Category>> categoriesLiveData = new MutableLiveData<>();
    private final FirebaseMenuRepository repository = new FirebaseMenuRepository();
    private String storeId; // Set this to your store's UID.

    public void setStoreId(String storeId) {
        this.storeId = storeId;
        loadMenu();
    }

    public String getStoreId() {
        return storeId;
    }

    public LiveData<List<Category>> getCategories() {
        return categoriesLiveData;
    }

    public void loadMenu() {
        if (storeId == null) return;
        repository.getMenu(storeId, new FirebaseMenuRepository.RepositoryCallback<List<Category>>() {
            @Override
            public void onSuccess(List<Category> result) {
                categoriesLiveData.postValue(result);
            }
            @Override
            public void onFailure(Exception e) {
                // Log or handle error as needed.
            }
        });
    }

    public void addCategory(Category category) {
        if (storeId == null) return;
        repository.addCategory(storeId, category, new FirebaseMenuRepository.RepositoryCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                loadMenu();
            }
            @Override
            public void onFailure(Exception e) {
                // Handle error.
            }
        });
    }

    public void updateCategory(Category category) {
        if (storeId == null) return;
        repository.updateCategory(storeId, category, new FirebaseMenuRepository.RepositoryCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                loadMenu();
            }
            @Override
            public void onFailure(Exception e) {
                // Handle error.
            }
        });
    }

    public void deleteCategory(String categoryId) {
        if (storeId == null) return;
        repository.deleteCategory(storeId, categoryId, new FirebaseMenuRepository.RepositoryCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                loadMenu();
            }
            @Override
            public void onFailure(Exception e) {
                // Handle error.
            }
        });
    }

    // Standard addItem (without image) remains.
    public void addItem(String categoryId, Item item) {
        if (storeId == null) return;
        repository.addItem(storeId, categoryId, item, new FirebaseMenuRepository.RepositoryCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                loadMenu();
            }
            @Override
            public void onFailure(Exception e) {
                // Handle error.
            }
        });
    }

    // New overloaded addItem method that accepts an image URI.
    public void addItem(String categoryId, Item item, Uri imageUri) {
        if (storeId == null) return;
        repository.addItemWithImage(storeId, categoryId, item, imageUri, new FirebaseMenuRepository.RepositoryCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                loadMenu();
            }
            @Override
            public void onFailure(Exception e) {
                // Handle error.
            }
        });
    }

    // Standard updateItem (without image) remains.
    public void updateItem(String categoryId, Item item) {
        if (storeId == null) return;
        repository.updateItem(storeId, categoryId, item, new FirebaseMenuRepository.RepositoryCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                loadMenu();
            }
            @Override
            public void onFailure(Exception e) {
                // Handle error.
            }
        });
    }

    // New overloaded updateItem method that accepts an image URI.
    public void updateItem(String categoryId, Item item, Uri imageUri) {
        if (storeId == null) return;
        repository.updateItemWithImage(storeId, categoryId, item, imageUri, new FirebaseMenuRepository.RepositoryCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                loadMenu();
            }
            @Override
            public void onFailure(Exception e) {
                // Handle error.
            }
        });
    }

    public void deleteItem(String categoryId, String itemId) {
        if (storeId == null) return;
        repository.deleteItem(storeId, categoryId, itemId, new FirebaseMenuRepository.RepositoryCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                loadMenu();
            }
            @Override
            public void onFailure(Exception e) {
                // Handle error.
            }
        });
    }
}
