package ca.georgebrown.roseflowerdeliveryapp.adapter;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Context;
import android.graphics.Color;
import android.location.Address;
import android.location.Geocoder;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Locale;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Location;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;
import ca.georgebrown.roseflowerdeliveryapp.utils.CircleTransform;
import ca.georgebrown.roseflowerdeliveryapp.view.ui.home.StoreLocationDialogFragment;
import ca.georgebrown.roseflowerdeliveryapp.view.ui.orders.PrintInvoiceDialogFragment;

public class ClientOrderHistoryAdapter extends RecyclerView.Adapter<ClientOrderHistoryAdapter.OrderHistoryViewHolder> {

    private final List<Order> orderList;
    private final Context context;

    public ClientOrderHistoryAdapter(Context context, List<Order> orderList) {
        this.context = context;
        this.orderList = orderList;
    }

    @NonNull
    @Override
    public OrderHistoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_client_order_history, parent, false);
        return new OrderHistoryViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderHistoryViewHolder holder, int position) {
        Order order = orderList.get(position);
        int originalStatus = order.getStatus();

        // If originalStatus == 7 => displayStatus = 4 ("Waiting for driver")
        int displayStatus = originalStatus;
        if (originalStatus == 7) {
            displayStatus = 4;
        }

        // Printer icon -> show invoice details dialog.
        holder.ivPrint.setOnClickListener(v -> {
            PrintInvoiceDialogFragment dialogFragment = PrintInvoiceDialogFragment.newInstance(order);
            dialogFragment.show(((FragmentActivity) context).getSupportFragmentManager(), "PrintInvoiceDialog");
        });

        // Show all details
        holder.progressOrderStatus.setVisibility(View.VISIBLE);
        holder.tvSubtotal.setVisibility(View.VISIBLE);
        holder.tvOrderDeliveryFee.setVisibility(View.VISIBLE);
        holder.tvTax.setVisibility(View.VISIBLE);
        holder.tvTotal.setVisibility(View.VISIBLE);
        holder.recyclerOrderItems.setVisibility(View.VISIBLE);
        holder.layoutStoreInfo.setVisibility(View.VISIBLE);

        // Order ID and Time
        holder.tvOrderId.setText("Order ID: " + (order.getId() != null ? order.getId() : "N/A"));
        if (order.getTimestamp() != null) {
            Timestamp ts = order.getTimestamp();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            holder.tvOrderTime.setText("Order Time: " + sdf.format(ts.toDate()));
        } else {
            holder.tvOrderTime.setText("Order Time: N/A");
        }

        // Order Status text
        String statusText = getStatusText(displayStatus);
        if (originalStatus == 7) {
            // If the original status was 7, override text to "Waiting for driver"
            statusText = "Waiting for driver";
        }
        holder.tvOrderStatus.setText("Status: " + statusText);

        // Set the color of the status text (matching store adapter logic)
        holder.tvOrderStatus.setTextColor(getStatusColor(originalStatus));

        // Progress bar
        holder.progressOrderStatus.setMax(8);

        // Updated progress bar logic:
        // - Rejected (3 or 6) => progress=8, tinted red
        // - Picked Up (8) => progress=7, tinted blue
        // - Completed (10) => progress=8, tinted green
        // - Otherwise => progress=displayStatus, tinted blue
        if (originalStatus == 3 || originalStatus == 6) {
            holder.progressOrderStatus.setProgress(8);
            holder.progressOrderStatus.setProgressTintList(
                    context.getColorStateList(android.R.color.holo_red_dark));
        } else if (originalStatus == 8) {
            // Picked Up => partial progress, tinted blue
            holder.progressOrderStatus.setProgress(7);
            holder.progressOrderStatus.setProgressTintList(
                    context.getColorStateList(android.R.color.holo_blue_light));
        } else if (originalStatus == 10) {
            // Completed => full progress, tinted green
            holder.progressOrderStatus.setProgress(8);
            holder.progressOrderStatus.setProgressTintList(
                    context.getColorStateList(android.R.color.holo_green_dark));
        } else {
            // All other statuses => displayStatus as progress, tinted blue
            holder.progressOrderStatus.setProgress(displayStatus);
            holder.progressOrderStatus.setProgressTintList(
                    context.getColorStateList(android.R.color.holo_blue_light));
        }

        // Pricing details
        holder.tvSubtotal.setText(String.format(Locale.getDefault(), "Subtotal: $%.2f", order.getSubtotal()));
        holder.tvOrderDeliveryFee.setText(String.format(Locale.getDefault(), "Delivery Fee: $%.2f", order.getDeliveryFee()));
        holder.tvTax.setText(String.format(Locale.getDefault(), "Tax: $%.2f", order.getTax()));
        holder.tvTotal.setText(String.format(Locale.getDefault(), "Total: $%.2f", order.getTotal()));

        // ---- Store Info (Name, Address, Logo) ----
        String storeId = order.getStoreId();
        if (TextUtils.isEmpty(storeId) && order.getOrderItems() != null && !order.getOrderItems().isEmpty()) {
            String fallbackStoreId = order.getOrderItems().get(0).getItem().getStoreId();
            if (!TextUtils.isEmpty(fallbackStoreId)) {
                storeId = fallbackStoreId;
                order.setStoreId(storeId);
            }
        }

        String storeName = (order.getStoreName() != null) ? order.getStoreName() : "";
        String storeAddress = (order.getStoreAddress() != null) ? order.getStoreAddress() : "";
        String storeLogoUrl = (order.getStoreLogoUrl() != null) ? order.getStoreLogoUrl() : "";

        boolean isStoreNameEmpty = TextUtils.isEmpty(storeName);
        boolean isStoreAddressEmpty = TextUtils.isEmpty(storeAddress);
        boolean isStoreLogoEmpty = TextUtils.isEmpty(storeLogoUrl);

        // If ANY critical store info is missing and we have a valid storeId, fetch from Firestore
        if ((isStoreNameEmpty || isStoreAddressEmpty || isStoreLogoEmpty) && !TextUtils.isEmpty(storeId)) {
            FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(storeId)
                    .get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (!documentSnapshot.exists()) {
                            holder.tvStoreName.setText("Store Name N/A");
                            holder.tvStoreLocation.setText("Address N/A");
                            holder.ivStoreLogo.setImageResource(R.drawable.pictureselect);
                            return;
                        }

                        Users storeUser = documentSnapshot.toObject(Users.class);
                        if (storeUser == null) {
                            holder.tvStoreName.setText("Store Name N/A");
                            holder.tvStoreLocation.setText("Address N/A");
                            holder.ivStoreLogo.setImageResource(R.drawable.pictureselect);
                            return;
                        }

                        // Name
                        String fetchedName = !TextUtils.isEmpty(storeUser.getStoreName())
                                ? storeUser.getStoreName() : "Store Name N/A";
                        holder.tvStoreName.setText(fetchedName);
                        order.setStoreName(fetchedName);

                        // Address from doc or reverse geocoding
                        String fetchedAddress = documentSnapshot.getString("storeAddress");
                        if (TextUtils.isEmpty(fetchedAddress)) {
                            Location loc = storeUser.getStoreLocation();
                            if (loc != null) {
                                double lat = loc.getLatitude();
                                double lng = loc.getLongitude();
                                order.setStoreLatitude(lat);
                                order.setStoreLongitude(lng);
                                if (lat != 0.0 && lng != 0.0) {
                                    holder.tvStoreLocation.setText("Loading address...");
                                    new Thread(() -> {
                                        Geocoder geocoder = new Geocoder(context, Locale.getDefault());
                                        try {
                                            List<Address> addresses = geocoder.getFromLocation(lat, lng, 1);
                                            if (addresses != null && !addresses.isEmpty()) {
                                                String humanReadable = addresses.get(0).getAddressLine(0);
                                                ((Activity) context).runOnUiThread(() -> {
                                                    holder.tvStoreLocation.setText(humanReadable);
                                                    order.setStoreAddress(humanReadable);
                                                });
                                            } else {
                                                ((Activity) context).runOnUiThread(() ->
                                                        holder.tvStoreLocation.setText("Address N/A")
                                                );
                                            }
                                        } catch (IOException e) {
                                            e.printStackTrace();
                                            ((Activity) context).runOnUiThread(() ->
                                                    holder.tvStoreLocation.setText("Address N/A")
                                            );
                                        }
                                    }).start();
                                } else {
                                    holder.tvStoreLocation.setText("Address N/A");
                                }
                            } else {
                                holder.tvStoreLocation.setText("Address N/A");
                            }
                        } else {
                            holder.tvStoreLocation.setText(fetchedAddress);
                            order.setStoreAddress(fetchedAddress);
                        }

                        // Logo
                        String fetchedLogo = (storeUser.getImageUrl() != null) ? storeUser.getImageUrl() : "";
                        if (!TextUtils.isEmpty(fetchedLogo)) {
                            Picasso.get()
                                    .load(fetchedLogo)
                                    .transform(new CircleTransform())
                                    .into(holder.ivStoreLogo);
                            order.setStoreLogoUrl(fetchedLogo);
                        } else {
                            holder.ivStoreLogo.setImageResource(R.drawable.pictureselect);
                        }
                    })
                    .addOnFailureListener(e -> {
                        holder.tvStoreName.setText("Store Name N/A");
                        holder.tvStoreLocation.setText("Address N/A");
                        holder.ivStoreLogo.setImageResource(R.drawable.pictureselect);
                    });
        } else {
            // We have storeName, storeAddress, storeLogoUrl or no storeId
            if (!TextUtils.isEmpty(storeName)) {
                holder.tvStoreName.setText(storeName);
            } else {
                holder.tvStoreName.setText("Store Name N/A");
            }

            if (!TextUtils.isEmpty(storeAddress)) {
                holder.tvStoreLocation.setText(storeAddress);
            } else {
                holder.tvStoreLocation.setText("Address N/A");
            }

            if (!TextUtils.isEmpty(storeLogoUrl)) {
                Picasso.get()
                        .load(storeLogoUrl)
                        .transform(new CircleTransform())
                        .into(holder.ivStoreLogo);
            } else {
                holder.ivStoreLogo.setImageResource(R.drawable.pictureselect);
            }
        }

        // Clicking on the store location text => show store location map
        holder.tvStoreLocation.setOnClickListener(v -> {
            double lat = order.getStoreLatitude();
            double lng = order.getStoreLongitude();
            if (lat != 0 && lng != 0) {
                String currentName = TextUtils.isEmpty(holder.tvStoreName.getText().toString())
                        ? "Store"
                        : holder.tvStoreName.getText().toString();
                String currentAddress = !holder.tvStoreLocation.getText().toString().equals("Address N/A")
                        ? holder.tvStoreLocation.getText().toString()
                        : "Address N/A";
                String logoUrlForDialog = (order.getStoreLogoUrl() != null) ? order.getStoreLogoUrl() : "";

                StoreLocationDialogFragment dialogFragment = StoreLocationDialogFragment.newInstance(
                        currentName,
                        currentAddress,
                        logoUrlForDialog,
                        lat,
                        lng
                );
                dialogFragment.show(((FragmentActivity) context).getSupportFragmentManager(), "StoreLocationDialog");
            }
        });

        // Nested RecyclerView for order items
        List<CartItem> cartItems = order.getOrderItems();
        if (cartItems != null && !cartItems.isEmpty()) {
            holder.recyclerOrderItems.setVisibility(View.VISIBLE);
            OrderItemsAdapter itemsAdapter = new OrderItemsAdapter(context, cartItems);
            holder.recyclerOrderItems.setLayoutManager(new LinearLayoutManager(context));
            holder.recyclerOrderItems.setAdapter(itemsAdapter);
        } else {
            holder.recyclerOrderItems.setVisibility(View.GONE);
        }

        // Driver info and completed message
        holder.layoutDriverInfo.setVisibility(View.GONE);
        holder.tvCompletedMessage.setVisibility(View.GONE);

        // ---- Revised Logic ----
        // Show "Completed" if status == 10
        // Show driver info if not "Waiting for driver" (status != 4) & assignedDriverId is valid
        if (displayStatus == 10) {
            // Show "Completed"
            holder.tvCompletedMessage.setVisibility(View.VISIBLE);
            holder.tvCompletedMessage.setText("Completed");
        } else if (displayStatus != 4
                && order.getAssignedDriverId() != null
                && !order.getAssignedDriverId().isEmpty()) {
            // Show driver info
            holder.layoutDriverInfo.setVisibility(View.VISIBLE);
            FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(order.getAssignedDriverId())
                    .get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (!documentSnapshot.exists()) {
                            holder.layoutDriverInfo.setVisibility(View.GONE);
                            return;
                        }
                        Users driverUser = documentSnapshot.toObject(Users.class);
                        if (driverUser != null && driverUser.getRole() == 2) {
                            String driverName = driverUser.getFirstName() + " " + driverUser.getLastName();
                            holder.tvDriverName.setText("Driver\n" + driverName.toUpperCase());

                            String imgUrl = driverUser.getImageUrl();
                            if (imgUrl != null && !imgUrl.isEmpty()) {
                                Picasso.get()
                                        .load(imgUrl)
                                        .transform(new CircleTransform())
                                        .into(holder.ivDriverPicture);

                                holder.ivDriverPicture.setOnClickListener(v -> {
                                    View dialogView = LayoutInflater.from(context).inflate(R.layout.dialog_circle_image, null);
                                    ImageView ivCircleImage = dialogView.findViewById(R.id.ivCircleImage);
                                    Picasso.get()
                                            .load(imgUrl)
                                            .transform(new CircleTransform())
                                            .into(ivCircleImage);
                                    ImageButton btnCloseImage = dialogView.findViewById(R.id.btnCloseImage);
                                    AlertDialog dialog = new AlertDialog.Builder(context)
                                            .setView(dialogView)
                                            .create();
                                    btnCloseImage.setOnClickListener(v1 -> dialog.dismiss());
                                    dialog.show();
                                });
                            } else {
                                holder.ivDriverPicture.setImageResource(R.drawable.pictureselect);
                            }
                        } else {
                            holder.layoutDriverInfo.setVisibility(View.GONE);
                        }
                    })
                    .addOnFailureListener(e -> holder.layoutDriverInfo.setVisibility(View.GONE));
        }
    }

    @Override
    public int getItemCount() {
        return (orderList != null) ? orderList.size() : 0;
    }

    /**
     * Returns a short text label for each status code.
     */
    private String getStatusText(int status) {
        switch (status) {
            case 1:
                return "New";
            case 2:
                return "Accepted";
            case 3:
                return "Rejected";
            case 4:
                return "Ready for Pickup";
            case 5:
                return "Driver Accepted";
            case 6:
                return "Driver Rejected";
            case 7:
                return "Cancelled";
            case 8:
                return "Picked Up";
            case 10:
                return "Completed";
            default:
                return "Unknown";
        }
    }

    /**
     * Returns the color used for the status text, matching your StoreOrdersAdapter logic.
     */
    private int getStatusColor(int status) {
        switch (status) {
            case 1: // New - Order Placed
                return Color.parseColor("#9C27B0");  // Purple
            case 10: // Completed
                return Color.parseColor("#4CAF50");  // Green
            case 7:  // Cancelled
                return Color.parseColor("#F44336");  // Red
            default:
                // For Accepted, Rejected, Ready for Pickup, Driver Accepted, Driver Rejected, Picked Up
                return Color.parseColor("#2196F3");  // Blue
        }
    }

    public static class OrderHistoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvOrderTime, tvOrderStatus;
        ProgressBar progressOrderStatus;
        TextView tvSubtotal, tvOrderDeliveryFee, tvTax, tvTotal;
        RecyclerView recyclerOrderItems;

        // Driver info views
        View layoutDriverInfo;
        ImageView ivDriverPicture;
        TextView tvDriverName;
        TextView tvCompletedMessage;

        // Printer icon
        ImageView ivPrint;

        // Store info views
        View layoutStoreInfo;
        ImageView ivStoreLogo;
        TextView tvStoreName, tvStoreLocation;

        public OrderHistoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvClientOrderId);
            tvOrderTime = itemView.findViewById(R.id.tvClientOrderTime);
            tvOrderStatus = itemView.findViewById(R.id.tvClientOrderStatus);
            progressOrderStatus = itemView.findViewById(R.id.progressOrderStatus);
            tvSubtotal = itemView.findViewById(R.id.tvClientOrderSubtotal);
            tvOrderDeliveryFee = itemView.findViewById(R.id.tvClientOrderDeliveryFee);
            tvTax = itemView.findViewById(R.id.tvClientOrderTax);
            tvTotal = itemView.findViewById(R.id.tvClientOrderTotal);
            recyclerOrderItems = itemView.findViewById(R.id.recyclerOrderItems);

            layoutDriverInfo = itemView.findViewById(R.id.layoutDriverInfo);
            ivDriverPicture = itemView.findViewById(R.id.ivDriverPicture);
            tvDriverName = itemView.findViewById(R.id.tvDriverName);
            tvCompletedMessage = itemView.findViewById(R.id.tvCompletedMessage);

            ivPrint = itemView.findViewById(R.id.ivPrint);

            layoutStoreInfo = itemView.findViewById(R.id.layoutStoreInfo);
            ivStoreLogo = itemView.findViewById(R.id.ivStoreLogo);
            tvStoreName = itemView.findViewById(R.id.tvStoreName);
            tvStoreLocation = itemView.findViewById(R.id.tvStoreLocation);
        }
    }
}
