package ca.georgebrown.roseflowerdeliveryapp.view;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.location.Location;
import android.net.Uri;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseOrderRepository;

/**
 * Handles the driver’s delivery navigation, including picking up, completing, or canceling an order.
 */
public class DeliveryNavigationActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final String TAG = "DeliveryNavActivity";
    private GoogleMap mMap;
    private Marker driverMarker;
    private Marker destinationMarker;
    private Polyline routePolyline;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;

    // UI elements for order controls (unchanged)
    private Button btnPickedUp, btnComplete, btnCancel;
    private ImageView ivClose;
    private TextView tvStoreAddress, tvDestinationAddress, tvProgressStatus;

    // New map control buttons (custom zoom and navigate)
    private ImageButton ivZoomIn, ivZoomOut, ivNavigateMap;

    // Intent-extras
    private String orderId;
    private String storeId;
    private String driverId;
    private int orderStatus; // 5=In progress, 7=Canceled, 8=Picked Up, 10=Completed
    private LatLng storeLatLng;
    private LatLng deliveryLatLng;
    private String storeAddress;
    private String deliveryAddress;

    // Firebase
    private FirebaseOrderRepository orderRepository;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_navigation);

        // Retrieve extras
        orderId = getIntent().getStringExtra("orderId");
        storeId = getIntent().getStringExtra("orderStoreId");
        driverId = getIntent().getStringExtra("driverId");
        orderStatus = getIntent().getIntExtra("orderStatus", 5); // default: In progress

        if (orderId == null || orderId.isEmpty() || storeId == null || storeId.isEmpty()) {
            Toast.makeText(this, "Missing order or store information.", Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        // Extract location/addresses
        double storeLat = getIntent().getDoubleExtra("store_lat", 0);
        double storeLng = getIntent().getDoubleExtra("store_lng", 0);
        double deliveryLat = getIntent().getDoubleExtra("delivery_lat", 0);
        double deliveryLng = getIntent().getDoubleExtra("delivery_lng", 0);
        storeLatLng = new LatLng(storeLat, storeLng);
        deliveryLatLng = new LatLng(deliveryLat, deliveryLng);

        storeAddress = getIntent().getStringExtra("store_address");
        deliveryAddress = getIntent().getStringExtra("delivery_address");

        // Initialize UI elements for order controls
        tvStoreAddress = findViewById(R.id.tvStoreAddress);
        tvDestinationAddress = findViewById(R.id.tvDestinationAddress);
        tvProgressStatus = findViewById(R.id.tvProgressStatus);
        btnPickedUp = findViewById(R.id.btnPickedUp);
        btnComplete = findViewById(R.id.btnComplete);
        btnCancel = findViewById(R.id.btnCancel);
        ivClose = findViewById(R.id.ivClose);

        // Initialize new map control buttons
        ivZoomIn = findViewById(R.id.ivZoomIn);
        ivZoomOut = findViewById(R.id.ivZoomOut);
        ivNavigateMap = findViewById(R.id.ivNavigateMap);

        // Assign addresses
        tvStoreAddress.setText("Store: " + (storeAddress != null ? storeAddress : "N/A"));
        tvDestinationAddress.setText("Destination: " + (deliveryAddress != null ? deliveryAddress : "N/A"));

        // Firebase
        orderRepository = new FirebaseOrderRepository();
        firestore = FirebaseFirestore.getInstance();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Set up map
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapNavigation);
        if (mapFragment != null) {
            mapFragment.getMapAsync(this);
        }

        // Configure UI based on order status
        updateUIForStatus();

        // Order control button logic
        btnPickedUp.setOnClickListener(v -> {
            orderRepository.updateOrderStatus(storeId, orderId, 8, new FirebaseOrderRepository.StatusUpdateCallback() {
                @Override
                public void onStatusUpdated() {
                    Toast.makeText(DeliveryNavigationActivity.this, "Order marked as Picked Up.", Toast.LENGTH_SHORT).show();
                    updateDriverOrderStatus(8);
                    orderStatus = 8;
                    updateUIForStatus();
                }
                @Override
                public void onError(Exception e) {
                    Toast.makeText(DeliveryNavigationActivity.this, "Error updating status: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });

        btnComplete.setOnClickListener(v -> {
            orderRepository.updateOrderStatus(storeId, orderId, 10, new FirebaseOrderRepository.StatusUpdateCallback() {
                @Override
                public void onStatusUpdated() {
                    updateDriverOrderStatus(10);
                    removeAssignedOrderFromDriver();
                    Toast.makeText(DeliveryNavigationActivity.this, "Delivery completed.", Toast.LENGTH_SHORT).show();
                    orderStatus = 10;
                    updateUIForStatus();
                    finish();
                }
                @Override
                public void onError(Exception e) {
                    Toast.makeText(DeliveryNavigationActivity.this, "Error updating status: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });

        btnCancel.setOnClickListener(v -> {
            firestore.collection("orders")
                    .document(storeId)
                    .collection("orderItems")
                    .document(orderId)
                    .update("status", 7,
                            "assignedDriverId", null,
                            "deliveryFee", 0)
                    .addOnSuccessListener(unused -> {
                        updateDriverOrderStatus(7, true);
                        removeAssignedOrderFromDriver();
                        Toast.makeText(DeliveryNavigationActivity.this, "Order canceled.", Toast.LENGTH_SHORT).show();
                        orderStatus = 7;
                        updateUIForStatus();
                        finish();
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(DeliveryNavigationActivity.this, "Error canceling order: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                    });
        });

        // Existing close button logic
        ivClose.setOnClickListener(v -> finish());

        // Map control button logic

        // Zoom in: animate camera zoom in
        ivZoomIn.setOnClickListener(v -> {
            if (mMap != null) {
                mMap.animateCamera(CameraUpdateFactory.zoomIn());
            }
        });

        // Zoom out: animate camera zoom out
        ivZoomOut.setOnClickListener(v -> {
            if (mMap != null) {
                mMap.animateCamera(CameraUpdateFactory.zoomOut());
            }
        });

        // Navigate button: launch external navigation
        ivNavigateMap.setOnClickListener(v -> launchExternalNavigation());

        startLocationUpdates();
    }

    /**
     * Hide or show UI elements based on orderStatus (7=canceled, 10=completed, 8=picked up, else=5).
     */
    private void updateUIForStatus() {
        if (orderStatus == 10) {
            tvProgressStatus.setVisibility(android.view.View.VISIBLE);
            tvProgressStatus.setText("Completed");
            tvProgressStatus.setTextColor(getResources().getColor(android.R.color.holo_green_dark));
            btnPickedUp.setVisibility(android.view.View.GONE);
            btnComplete.setVisibility(android.view.View.GONE);
            btnCancel.setVisibility(android.view.View.GONE);
            // Hide map control navigate button when order is finished
            ivNavigateMap.setVisibility(android.view.View.GONE);
        } else if (orderStatus == 7) {
            tvProgressStatus.setVisibility(android.view.View.VISIBLE);
            tvProgressStatus.setText("Canceled");
            tvProgressStatus.setTextColor(getResources().getColor(android.R.color.holo_red_dark));
            btnPickedUp.setVisibility(android.view.View.GONE);
            btnComplete.setVisibility(android.view.View.GONE);
            btnCancel.setVisibility(android.view.View.GONE);
            ivNavigateMap.setVisibility(android.view.View.GONE);
        } else if (orderStatus == 8) {
            tvProgressStatus.setVisibility(android.view.View.GONE);
            btnPickedUp.setVisibility(android.view.View.GONE);
            btnComplete.setVisibility(android.view.View.VISIBLE);
            btnCancel.setVisibility(android.view.View.GONE);
            ivNavigateMap.setVisibility(android.view.View.VISIBLE);
        } else {
            tvProgressStatus.setVisibility(android.view.View.GONE);
            btnPickedUp.setVisibility(android.view.View.VISIBLE);
            btnComplete.setVisibility(android.view.View.GONE);
            btnCancel.setVisibility(android.view.View.VISIBLE);
            ivNavigateMap.setVisibility(android.view.View.VISIBLE);
        }
    }

    /**
     * Update driver's subcollection doc with new status, optionally zero out driverFee if canceled.
     */
    private void updateDriverOrderStatus(int newStatus) {
        updateDriverOrderStatus(newStatus, false);
    }
    private void updateDriverOrderStatus(int newStatus, boolean zeroDriverFee) {
        if (driverId == null || orderId == null) return;
        java.util.Map<String, Object> updates = new java.util.HashMap<>();
        updates.put("status", newStatus);
        updates.put("storeId", storeId);
        if (zeroDriverFee) {
            updates.put("driverFee", 0);
        }
        firestore.collection("drivers")
                .document(driverId)
                .collection("orders")
                .document(orderId)
                .update(updates)
                .addOnSuccessListener(aVoid -> Log.d(TAG, "Driver order updated with status " + newStatus))
                .addOnFailureListener(e -> Log.e(TAG, "Error updating driver order status: " + e.getMessage()));
    }

    /**
     * Removes 'assignedOrderId' from the driver doc.
     */
    private void removeAssignedOrderFromDriver() {
        if (driverId != null) {
            firestore.collection("drivers")
                    .document(driverId)
                    .update("assignedOrderId", FieldValue.delete())
                    .addOnSuccessListener(aVoid -> Log.d(TAG, "assignedOrderId removed from driver doc."))
                    .addOnFailureListener(e -> Log.e(TAG, "Error removing assignedOrderId: " + e.getMessage()));
        }
    }

    /**
     * Launches Google Maps external navigation.
     * If order is <8, navigates to store; else to destination.
     */
    private void launchExternalNavigation() {
        LatLng target = (orderStatus < 8) ? storeLatLng : deliveryLatLng;
        String uri = "google.navigation:q=" + target.latitude + "," + target.longitude;
        Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
        intent.setPackage("com.google.android.apps.maps");
        if (intent.resolveActivity(getPackageManager()) != null) {
            startActivity(intent);
        } else {
            Toast.makeText(this, "Google Maps is not installed.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        // Disable the default zoom controls since we are using our own
        mMap.getUiSettings().setZoomControlsEnabled(false);
        destinationMarker = mMap.addMarker(new MarkerOptions().position(storeLatLng).title("Store Location"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(storeLatLng, 14));
    }

    private void startLocationUpdates() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(5000);
        locationRequest.setFastestInterval(3000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Location permissions are not granted.", Toast.LENGTH_SHORT).show();
            return;
        }

        locationCallback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null || mMap == null) return;
                Location location = locationResult.getLastLocation();
                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                if (driverMarker == null) {
                    driverMarker = mMap.addMarker(new MarkerOptions().position(currentLatLng).title("Your Location"));
                } else {
                    driverMarker.setPosition(currentLatLng);
                }
                if (destinationMarker != null) {
                    fetchRoute(currentLatLng, destinationMarker.getPosition());
                }
            }
        };
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
    }

    private void fetchRoute(LatLng origin, LatLng destination) {
        String url = getDirectionsUrl(origin, destination);
        new FetchRouteTask().execute(url);
    }

    private String getDirectionsUrl(LatLng origin, LatLng dest) {
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;
        String mode = "mode=driving";
        String parameters = str_origin + "&" + str_dest + "&" + mode;
        String output = "json";
        String apiKey = getString(R.string.google_maps_key);
        return "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters + "&key=" + apiKey;
    }

    private class FetchRouteTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... url) {
            String data = "";
            try {
                data = downloadUrl(url[0]);
            } catch (Exception e) {
                Log.e(TAG, "Error downloading route", e);
            }
            return data;
        }
        @Override
        protected void onPostExecute(String result) {
            new ParseRouteTask().execute(result);
        }
    }

    private String downloadUrl(String strUrl) throws IOException {
        StringBuilder sb = new StringBuilder();
        HttpURLConnection urlConnection = null;
        InputStream iStream = null;
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            br.close();
        } finally {
            if (iStream != null) iStream.close();
            if (urlConnection != null) urlConnection.disconnect();
        }
        return sb.toString();
    }

    private class ParseRouteTask extends AsyncTask<String, Void, List<LatLng>> {
        @Override
        protected List<LatLng> doInBackground(String... jsonData) {
            List<LatLng> points = new ArrayList<>();
            try {
                JSONObject jsonObject = new JSONObject(jsonData[0]);
                JSONArray routes = jsonObject.getJSONArray("routes");
                if (routes.length() > 0) {
                    JSONObject route = routes.getJSONObject(0);
                    JSONObject overviewPolyline = route.getJSONObject("overview_polyline");
                    String encodedPoints = overviewPolyline.getString("points");
                    points = decodePoly(encodedPoints);
                }
            } catch (JSONException e) {
                Log.e(TAG, "Error parsing route JSON", e);
            }
            return points;
        }
        @Override
        protected void onPostExecute(List<LatLng> points) {
            if (points != null && !points.isEmpty() && mMap != null) {
                if (routePolyline != null) {
                    routePolyline.remove();
                }
                PolylineOptions lineOptions = new PolylineOptions()
                        .addAll(points)
                        .width(10)
                        .color(getResources().getColor(android.R.color.holo_blue_dark));
                routePolyline = mMap.addPolyline(lineOptions);
            }
        }
    }

    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new ArrayList<>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;
        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;
            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;
            LatLng p = new LatLng(((double) lat / 1E5), ((double) lng / 1E5));
            poly.add(p);
        }
        return poly;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (fusedLocationClient != null && locationCallback != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
    }
}
