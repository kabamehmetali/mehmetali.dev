package ca.georgebrown.roseflowerdeliveryapp.model;

import com.google.firebase.Timestamp;
import com.google.gson.annotations.SerializedName;

/**
 * Model representing the store’s current status.
 * - storeId: the unique identifier for the store.
 * - acceptingOrders: whether the store is currently accepting orders.
 * - lastUpdated: the last time the status was updated.
 */
public class StoreStatus {

    @SerializedName("storeId")
    private String storeId;

    @SerializedName("acceptingOrders")
    private boolean acceptingOrders;

    @SerializedName("lastUpdated")
    private Timestamp lastUpdated;

    public StoreStatus() {
    }

    public StoreStatus(String storeId, boolean acceptingOrders, Timestamp lastUpdated) {
        this.storeId = storeId;
        this.acceptingOrders = acceptingOrders;
        this.lastUpdated = lastUpdated;
    }

    // Getters and setters

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public boolean isAcceptingOrders() {
        return acceptingOrders;
    }

    public void setAcceptingOrders(boolean acceptingOrders) {
        this.acceptingOrders = acceptingOrders;
    }

    public Timestamp getLastUpdated() {
        return lastUpdated;
    }

    public void setLastUpdated(Timestamp lastUpdated) {
        this.lastUpdated = lastUpdated;
    }
}
