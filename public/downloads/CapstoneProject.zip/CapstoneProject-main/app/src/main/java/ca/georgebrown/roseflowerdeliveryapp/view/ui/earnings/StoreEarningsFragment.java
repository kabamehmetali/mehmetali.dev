package ca.georgebrown.roseflowerdeliveryapp.view.ui.earnings;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.StoreTransactionAdapter;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class StoreEarningsFragment extends Fragment {

    private static final String TAG = "StoreEarningsFragment";
    private static final String PREFS_NAME = "EarningsPrefs";
    private static final String KEY_FROM_DATE = "fromDate";
    private static final String KEY_TO_DATE = "toDate";

    private TextView tvFromDate, tvToDate, tvTotalEarnings, tvGrossEarnings, tvOrdersCompleted, tvNoOrders;
    private BarChart earningsChart;
    private RecyclerView rvOrders;
    private Spinner spinnerPresets;

    private SimpleDateFormat displayFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
    private SimpleDateFormat firestoreFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    private SimpleDateFormat firestoreFormat2 = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    private Date selectedFromDate, selectedToDate;
    private List<Order> allOrders = new ArrayList<>();
    private List<Order> filteredOrders = new ArrayList<>();
    private StoreTransactionAdapter orderAdapter;
    private FirebaseFirestore firestore;
    private String storeId;

    private List<String> presetOptions;

    public StoreEarningsFragment() {
        // Required empty public constructor.
    }

    public static StoreEarningsFragment newInstance() {
        return new StoreEarningsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firestore = FirebaseFirestore.getInstance();
        // Use FirebaseAuth's UID as storeId (ensure this is correct)
        storeId = FirebaseAuth.getInstance().getUid();

        SharedPreferences prefs = getActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String fromDateStr = prefs.getString(KEY_FROM_DATE, null);
        String toDateStr = prefs.getString(KEY_TO_DATE, null);
        Date today = new Date();
        if (fromDateStr != null && toDateStr != null) {
            try {
                selectedFromDate = displayFormat.parse(fromDateStr);
                selectedToDate = displayFormat.parse(toDateStr);
            } catch (ParseException e) {
                e.printStackTrace();
                selectedFromDate = today;
                selectedToDate = today;
            }
        } else {
            selectedFromDate = today;
            selectedToDate = today;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_store_earnings, container, false);

        tvFromDate = view.findViewById(R.id.tvFromDate);
        tvToDate = view.findViewById(R.id.tvToDate);
        tvTotalEarnings = view.findViewById(R.id.tvTotalEarnings);
        tvGrossEarnings = view.findViewById(R.id.tvGrossEarnings);
        tvOrdersCompleted = view.findViewById(R.id.tvOrdersCompleted);
        tvNoOrders = view.findViewById(R.id.tvNoOrders);
        earningsChart = view.findViewById(R.id.earningsChart);
        rvOrders = view.findViewById(R.id.rvOrders);
        spinnerPresets = view.findViewById(R.id.spinnerPresets);

        tvFromDate.setText(displayFormat.format(selectedFromDate));
        tvToDate.setText(displayFormat.format(selectedToDate));

        rvOrders.setLayoutManager(new LinearLayoutManager(getContext()));
        orderAdapter = new StoreTransactionAdapter(new ArrayList<>());
        rvOrders.setAdapter(orderAdapter);

        // Date pickers.
        tvFromDate.setOnClickListener(v -> {
            showDatePicker(selectedFromDate, date -> {
                selectedFromDate = date;
                if (selectedFromDate.after(selectedToDate)) {
                    selectedToDate = selectedFromDate;
                    tvToDate.setText(displayFormat.format(selectedToDate));
                }
                tvFromDate.setText(displayFormat.format(selectedFromDate));
                filterOrders();
                updateSpinnerSelection();
            });
        });
        tvToDate.setOnClickListener(v -> {
            showDatePicker(selectedToDate, date -> {
                selectedToDate = date;
                if (selectedToDate.before(selectedFromDate)) {
                    selectedFromDate = selectedToDate;
                    tvFromDate.setText(displayFormat.format(selectedFromDate));
                }
                tvToDate.setText(displayFormat.format(selectedToDate));
                filterOrders();
                updateSpinnerSelection();
            });
        });

        presetOptions = new ArrayList<>();
        presetOptions.add("Custom");
        presetOptions.add("Today");
        presetOptions.add("Yesterday");
        presetOptions.add("Last 7 Days");
        presetOptions.add("Last 30 Days");
        presetOptions.add("This Month");
        presetOptions.add("Last Month");

        ArrayAdapter<String> presetAdapter = new ArrayAdapter<>(getContext(), R.layout.spinner_item, presetOptions);
        presetAdapter.setDropDownViewResource(R.layout.spinner_item);
        spinnerPresets.setAdapter(presetAdapter);

        spinnerPresets.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean firstCall = true;
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                if (firstCall) {
                    firstCall = false;
                    return;
                }
                String preset = presetOptions.get(position);
                Date today = removeTime(new Date());
                Calendar cal = Calendar.getInstance();
                switch (preset) {
                    case "Today":
                        selectedFromDate = today;
                        selectedToDate = today;
                        break;
                    case "Yesterday":
                        selectedFromDate = addDays(today, -1);
                        selectedToDate = addDays(today, -1);
                        break;
                    case "Last 7 Days":
                        selectedToDate = today;
                        selectedFromDate = addDays(today, -6);
                        break;
                    case "Last 30 Days":
                        selectedToDate = today;
                        selectedFromDate = addDays(today, -29);
                        break;
                    case "This Month":
                        cal.setTime(today);
                        cal.set(Calendar.DAY_OF_MONTH, 1);
                        selectedFromDate = removeTime(cal.getTime());
                        selectedToDate = today;
                        break;
                    case "Last Month":
                        cal.setTime(today);
                        cal.add(Calendar.MONTH, -1);
                        cal.set(Calendar.DAY_OF_MONTH, 1);
                        selectedFromDate = removeTime(cal.getTime());
                        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
                        selectedToDate = removeTime(cal.getTime());
                        break;
                    default:
                        return;
                }
                updateDateTextViews();
                filterOrders();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        loadOrders();
        updateSpinnerSelection();
        return view;
    }

    private interface DatePickerCallback {
        void onDateSelected(Date date);
    }

    private void showDatePicker(Date initialDate, DatePickerCallback callback) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(initialDate);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog dialog = new DatePickerDialog(getContext(), (DatePicker view, int selectedYear, int selectedMonth, int selectedDay) -> {
            Calendar selectedCal = Calendar.getInstance();
            selectedCal.set(selectedYear, selectedMonth, selectedDay);
            callback.onDateSelected(selectedCal.getTime());
        }, year, month, day);
        dialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        dialog.show();
    }

    /**
     * Parses the order date using the Firebase Timestamp if available.
     */
    private Date parseOrderDate(Order order) {
        if (order.getTimestamp() != null) {
            return order.getTimestamp().toDate();
        } else if (order.getOrderPlacedDate() != null) {
            try {
                return firestoreFormat1.parse(order.getOrderPlacedDate());
            } catch (ParseException e) {
                try {
                    return firestoreFormat2.parse(order.getOrderPlacedDate());
                } catch (ParseException ex) {
                    Log.e(TAG, "Failed to parse orderPlacedDate: " + order.getOrderPlacedDate());
                    return null;
                }
            }
        }
        return null;
    }

    /**
     * Loads orders from Firestore using the path "orders/{storeId}/orderItems".
     */
    private void loadOrders() {
        if (storeId == null) {
            Log.e(TAG, "Store ID is null. Cannot load orders.");
            return;
        }
        Log.d(TAG, "Fetching orders for store ID: " + storeId);
        firestore.collection("orders")
                .document(storeId)
                .collection("orderItems")
                .orderBy("timestamp", Query.Direction.DESCENDING)
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    allOrders.clear();
                    Log.d(TAG, "Documents fetched: " + queryDocumentSnapshots.size());
                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        Log.d(TAG, "Document: " + doc.getId() + " Data: " + doc.getData());
                        Order order = doc.toObject(Order.class);
                        if (order != null) {
                            order.setId(doc.getId());
                            Log.d(TAG, "Order " + order.getId() + " timestamp: " + order.getTimestamp());
                            allOrders.add(order);
                        }
                    }
                    Log.d(TAG, "Number of orders fetched: " + allOrders.size());
                    filterOrders();
                })
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Failed to load orders", Toast.LENGTH_SHORT).show()
                );
    }

    private void filterOrders() {
        filteredOrders.clear();
        Calendar cal = Calendar.getInstance();
        cal.setTime(selectedFromDate);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Date fromDayStart = cal.getTime();

        cal.setTime(selectedToDate);
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        cal.set(Calendar.MILLISECOND, 999);
        Date toDayEnd = cal.getTime();

        for (Order order : allOrders) {
            Date orderDate = parseOrderDate(order);
            if (orderDate != null && !orderDate.before(fromDayStart) && !orderDate.after(toDayEnd)) {
                filteredOrders.add(order);
            }
        }
        Log.d(TAG, "Filtered orders count: " + filteredOrders.size());
        // If no orders exist in the filtered list, clear chart and show message.
        if(filteredOrders.isEmpty()){
            earningsChart.clear();
            tvNoOrders.setVisibility(View.VISIBLE);
            updateStatsUI(filteredOrders, 0, 0, 0);
        } else {
            tvNoOrders.setVisibility(View.GONE);
            updateStatsAndChart();
        }
        saveSelectedDates();
        orderAdapter.updateList(filteredOrders);
    }

    /**
     * Computes total for an order (gross + 13% tax).
     */
    private double computeOrderTotal(Order order) {
        double subtotal = 0;
        if (order.getOrderItems() != null) {
            for (int i = 0; i < order.getOrderItems().size(); i++) {
                double price = order.getOrderItems().get(i).getItem().getPrice();
                int quantity = order.getOrderItems().get(i).getQuantity();
                subtotal += price * quantity;
            }
        }
        double tax = subtotal * 0.13;
        return subtotal + tax;
    }

    /**
     * Computes gross earnings (subtotal) for an order.
     */
    private double computeGross(Order order) {
        double subtotal = 0;
        if (order.getOrderItems() != null) {
            for (int i = 0; i < order.getOrderItems().size(); i++) {
                double price = order.getOrderItems().get(i).getItem().getPrice();
                int quantity = order.getOrderItems().get(i).getQuantity();
                subtotal += price * quantity;
            }
        }
        return subtotal;
    }

    private void updateStatsAndChart() {
        // Map: key = date, value = [gross, tax, completedOrders]
        Map<String, double[]> earningsByDate = new TreeMap<>();
        SimpleDateFormat keyFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        int ordersCompleted = 0;
        double totalEarnings = 0;
        double grossEarnings = 0;
        for (Order order : filteredOrders) {
            if (order.getStatus() == 10) { // Completed orders
                ordersCompleted++;
                double orderGross = computeGross(order);
                double orderTotal = computeOrderTotal(order);
                grossEarnings += orderGross;
                totalEarnings += orderTotal;
                double tax = orderTotal - orderGross;
                Date orderDate = parseOrderDate(order);
                if (orderDate != null) {
                    String key = keyFormat.format(orderDate);
                    double[] values = earningsByDate.getOrDefault(key, new double[]{0.0, 0.0, 0});
                    values[0] += orderGross;
                    values[1] += tax;
                    values[2] += 1;
                    earningsByDate.put(key, values);
                }
            }
        }

        // Even if there are filtered orders, there may be no completed orders.
        // In that case, clear the chart but do not show "No orders available"
        // because the list still displays "in progress" orders.
        if (earningsByDate.isEmpty()) {
            earningsChart.clear();
        } else {
            List<BarEntry> grossEntries = new ArrayList<>();
            List<BarEntry> totalEntries = new ArrayList<>();
            List<String> dateKeys = new ArrayList<>();
            int index = 0;
            for (Map.Entry<String, double[]> entry : earningsByDate.entrySet()) {
                dateKeys.add(entry.getKey());
                double gross = entry.getValue()[0];
                double tax = entry.getValue()[1];
                double total = gross + tax;
                grossEntries.add(new BarEntry(index, (float) gross));
                totalEntries.add(new BarEntry(index, (float) total));
                index++;
            }
            XAxis xAxis = earningsChart.getXAxis();
            xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
            xAxis.setGranularity(1f);
            xAxis.setValueFormatter(new ValueFormatter() {
                @Override
                public String getFormattedValue(float value) {
                    int idx = (int) value;
                    if (dateKeys.isEmpty() || idx < 0 || idx >= dateKeys.size()) {
                        return "";
                    }
                    try {
                        Date date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(dateKeys.get(idx));
                        return new SimpleDateFormat("dd MMM", Locale.getDefault()).format(date);
                    } catch (ParseException e) {
                        return "";
                    }
                }
            });
            BarDataSet grossSet = new BarDataSet(grossEntries, "Gross Earnings");
            grossSet.setColor(Color.parseColor("#2E7D32"));
            grossSet.setValueTextSize(12f);
            grossSet.setValueTypeface(Typeface.DEFAULT_BOLD);
            grossSet.setValueFormatter(new ValueFormatter() {
                @Override
                public String getFormattedValue(float value) {
                    return "G:$" + String.format(Locale.getDefault(), "%.2f", value);
                }
            });
            BarDataSet totalSet = new BarDataSet(totalEntries, "Total Earnings");
            totalSet.setColor(Color.parseColor("#B71C1C"));
            totalSet.setValueTextSize(12f);
            totalSet.setValueTypeface(Typeface.DEFAULT_BOLD);
            totalSet.setValueFormatter(new ValueFormatter() {
                @Override
                public String getFormattedValue(float value) {
                    return "T:$" + String.format(Locale.getDefault(), "%.2f", value);
                }
            });
            BarData barData = new BarData(grossSet, totalSet);
            float barWidth = 0.35f;
            float barSpace = 0.05f;
            float groupSpace = 0.2f;
            barData.setBarWidth(barWidth);
            earningsChart.setData(barData);
            xAxis.setAxisMinimum(0);
            xAxis.setAxisMaximum(0 + barData.getGroupWidth(groupSpace, barSpace) * dateKeys.size());
            earningsChart.groupBars(0f, groupSpace, barSpace);
            earningsChart.getDescription().setEnabled(false);
            earningsChart.invalidate();
        }

        final int finalOrdersCompleted = ordersCompleted;
        final double finalTotalEarnings = totalEarnings;
        final double finalGrossEarnings = grossEarnings;

        updateStatsUI(filteredOrders, finalTotalEarnings, finalOrdersCompleted, finalGrossEarnings);

        earningsChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                BarEntry barEntry = (BarEntry) e;
                int pos = (int) barEntry.getX();
                List<Order> ordersForDay = new ArrayList<>();
                if(pos >= 0) {
                    // Build date keys from the earningsByDate map.
                    List<String> dateKeys = new ArrayList<>();
                    for(String key : earningsByDate.keySet()){
                        dateKeys.add(key);
                    }
                    if(pos < dateKeys.size()){
                        String selectedKey = dateKeys.get(pos);
                        for (Order order : filteredOrders) {
                            Date orderDate = parseOrderDate(order);
                            if (orderDate != null) {
                                String key = keyFormat.format(orderDate);
                                if (key.equals(selectedKey)) {
                                    ordersForDay.add(order);
                                }
                            }
                        }
                    }
                }
                int dayCompleted = 0;
                double dayGross = 0;
                double dayTotal = 0;
                for (Order order : ordersForDay) {
                    if (order.getStatus() == 10) {
                        dayCompleted++;
                        dayGross += computeGross(order);
                        dayTotal += computeOrderTotal(order);
                    }
                }
                orderAdapter.updateList(ordersForDay);
                updateStatsUI(ordersForDay, dayTotal, dayCompleted, dayGross);
                tvNoOrders.setVisibility(ordersForDay.isEmpty() ? View.VISIBLE : View.GONE);
            }

            @Override
            public void onNothingSelected() {
                orderAdapter.updateList(filteredOrders);
                updateStatsUI(filteredOrders, finalTotalEarnings, finalOrdersCompleted, finalGrossEarnings);
                tvNoOrders.setVisibility(earningsChart.getData().getEntryCount() == 0 ? View.VISIBLE : View.GONE);
            }
        });
    }

    private void updateStatsUI(List<Order> orders, double totalEarnings, int ordersCompleted, double grossEarnings) {
        tvTotalEarnings.setText(String.format(Locale.getDefault(), "$%.2f", totalEarnings));
        tvGrossEarnings.setText(String.format(Locale.getDefault(), "$%.2f", grossEarnings));
        tvOrdersCompleted.setText(String.valueOf(ordersCompleted));
    }

    private void saveSelectedDates() {
        SharedPreferences prefs = getActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_FROM_DATE, displayFormat.format(selectedFromDate));
        editor.putString(KEY_TO_DATE, displayFormat.format(selectedToDate));
        editor.apply();
    }

    private Date removeTime(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    private Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_MONTH, days);
        return cal.getTime();
    }

    private void updateDateTextViews() {
        tvFromDate.setText(displayFormat.format(selectedFromDate));
        tvToDate.setText(displayFormat.format(selectedToDate));
        saveSelectedDates();
        updateSpinnerSelection();
    }

    private void updateSpinnerSelection() {
        Date today = removeTime(new Date());
        if (selectedFromDate.equals(today) && selectedToDate.equals(today)) {
            spinnerPresets.setSelection(presetOptions.indexOf("Today"));
            return;
        } else if (selectedFromDate.equals(addDays(today, -1)) && selectedToDate.equals(addDays(today, -1))) {
            spinnerPresets.setSelection(presetOptions.indexOf("Yesterday"));
            return;
        } else if (selectedToDate.equals(today) && selectedFromDate.equals(addDays(today, -6))) {
            spinnerPresets.setSelection(presetOptions.indexOf("Last 7 Days"));
            return;
        } else if (selectedToDate.equals(today) && selectedFromDate.equals(addDays(today, -29))) {
            spinnerPresets.setSelection(presetOptions.indexOf("Last 30 Days"));
            return;
        } else {
            Calendar cal = Calendar.getInstance();
            cal.setTime(new Date());
            cal.set(Calendar.DAY_OF_MONTH, 1);
            Date firstDayThisMonth = removeTime(cal.getTime());
            if (selectedFromDate.equals(firstDayThisMonth) && selectedToDate.equals(today)) {
                spinnerPresets.setSelection(presetOptions.indexOf("This Month"));
                return;
            }
            cal.setTime(new Date());
            cal.add(Calendar.MONTH, -1);
            cal.set(Calendar.DAY_OF_MONTH, 1);
            Date firstDayLastMonth = removeTime(cal.getTime());
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
            Date lastDayLastMonth = removeTime(cal.getTime());
            if (selectedFromDate.equals(firstDayLastMonth) && selectedToDate.equals(lastDayLastMonth)) {
                spinnerPresets.setSelection(presetOptions.indexOf("Last Month"));
                return;
            }
        }
        spinnerPresets.setSelection(presetOptions.indexOf("Custom"));
    }
}
