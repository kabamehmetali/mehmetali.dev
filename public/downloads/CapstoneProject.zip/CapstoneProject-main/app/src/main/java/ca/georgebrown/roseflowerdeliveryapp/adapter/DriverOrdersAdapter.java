package ca.georgebrown.roseflowerdeliveryapp.adapter;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.os.AsyncTask;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.auth.FirebaseAuth;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;
import java.util.Locale;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;
import ca.georgebrown.roseflowerdeliveryapp.view.DeliveryNavigationActivity;

public class DriverOrdersAdapter extends RecyclerView.Adapter<DriverOrdersAdapter.OrderViewHolder> {

    private static final String TAG = "DriverOrdersAdapter";
    private List<Order> orders;
    private final Context context;
    private final String driverId;

    public DriverOrdersAdapter(List<Order> orders, Context context) {
        this.orders = orders;
        this.context = context;
        this.driverId = FirebaseAuth.getInstance().getUid();
    }

    public void updateList(List<Order> updatedOrders) {
        this.orders = updatedOrders;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.item_driver_order, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orders.get(position);

        // Basic info
        holder.tvOrderId.setText("Order #" + order.getId());
        holder.tvOrderPlacedDate.setText("Placed on: " + (order.getOrderPlacedDate() != null ? order.getOrderPlacedDate() : "N/A"));
        holder.tvOrderStatus.setText(getStatusText(order.getStatus()));
        holder.tvOrderStatus.setTextColor(getStatusColor(order.getStatus()));
        holder.tvCustomerName.setText(order.getUserName());

        // Display store name
        holder.tvStoreName.setText("Store Name: " + (order.getStoreName() != null ? order.getStoreName() : "N/A"));

        double fee = (order.getDriverFee() != null) ? order.getDriverFee() : 5.0;
        holder.tvDriverFee.setText(String.format(Locale.getDefault(), "Driver Fee: $%.2f", fee));

        if (order.getDistance() != null && order.getDistance() > 0) {
            holder.tvDistance.setText("Distance: " + formatDistance(order.getDistance()));
        } else {
            holder.tvDistance.setText("Distance: N/A");
        }

        holder.tvStorePickup.setText("Picked up from: " + (order.getStoreAddress() != null ? order.getStoreAddress() : "N/A"));
        String dest = "N/A";
        if (order.getDeliveryLocation() != null && order.getDeliveryLocation().getFormattedAddress() != null) {
            dest = order.getDeliveryLocation().getFormattedAddress();
        } else if (order.getDeliveryAddress() != null) {
            dest = order.getDeliveryAddress();
        }
        holder.tvDelivery.setText("Delivered to: " + dest);

        // Setup MapView
        holder.mapView.onCreate(null);
        holder.mapView.onResume();
        MapsInitializer.initialize(context);
        holder.mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                googleMap.clear();
                LatLng storeLatLng = new LatLng(order.getStoreLatitude(), order.getStoreLongitude());
                String storeMarkerName = (order.getStoreName() != null && !order.getStoreName().isEmpty())
                        ? "Store: " + order.getStoreName()
                        : (order.getStoreAddress() != null ? "Store: " + order.getStoreAddress() : "Store Pickup");
                googleMap.addMarker(new MarkerOptions().position(storeLatLng).title(storeMarkerName));
                if (order.getDeliveryLocation() != null) {
                    LatLng deliveryLatLng = new LatLng(order.getDeliveryLocation().getLatitude(),
                            order.getDeliveryLocation().getLongitude());
                    String userMarkerName = (order.getUserName() != null && !order.getUserName().isEmpty())
                            ? "Destination: " + order.getUserName() : "Destination";
                    googleMap.addMarker(new MarkerOptions().position(deliveryLatLng).title(userMarkerName));
                    googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(storeLatLng, 12));
                    if (order.getRoutePolyline() != null && !order.getRoutePolyline().isEmpty()) {
                        List<LatLng> points = decodePoly(order.getRoutePolyline());
                        PolylineOptions lineOptions = new PolylineOptions()
                                .addAll(points)
                                .width(8)
                                .color(context.getResources().getColor(android.R.color.holo_blue_dark));
                        googleMap.addPolyline(lineOptions);
                    } else {
                        String url = getDirectionsUrl(storeLatLng, deliveryLatLng);
                        new FetchRouteTask(googleMap, holder.tvDistance).execute(url);
                    }
                } else {
                    googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(storeLatLng, 12));
                }
            }
        });

        // Disable clicking on card for canceled or completed orders
        if (order.getStatus() == 7 || order.getStatus() == 10) {
            holder.cardView.setClickable(false);
        } else {
            holder.cardView.setClickable(true);
            holder.cardView.setOnClickListener(v -> {
                if (order.getStatus() < 10) {
                    Intent intent = new Intent(context, DeliveryNavigationActivity.class);
                    intent.putExtra("orderId", order.getId());
                    intent.putExtra("orderStoreId", order.getStoreId() != null ? order.getStoreId() : "");
                    intent.putExtra("driverId", driverId);
                    intent.putExtra("store_lat", order.getStoreLatitude());
                    intent.putExtra("store_lng", order.getStoreLongitude());
                    if (order.getDeliveryLocation() != null) {
                        intent.putExtra("delivery_lat", order.getDeliveryLocation().getLatitude());
                        intent.putExtra("delivery_lng", order.getDeliveryLocation().getLongitude());
                    } else {
                        intent.putExtra("delivery_lat", 0.0);
                        intent.putExtra("delivery_lng", 0.0);
                    }
                    intent.putExtra("store_address", order.getStoreAddress());
                    if (order.getDeliveryLocation() != null && order.getDeliveryLocation().getFormattedAddress() != null) {
                        intent.putExtra("delivery_address", order.getDeliveryLocation().getFormattedAddress());
                    } else {
                        intent.putExtra("delivery_address", order.getDeliveryAddress());
                    }
                    intent.putExtra("orderStatus", order.getStatus());
                    context.startActivity(intent);
                }
            });
        }

        // Toggle dropdown: When clicked, simply expand/collapse order items with animated icon rotation.
        holder.ivToggleItems.setOnClickListener(v -> {
            if (holder.layoutOrderItems.getVisibility() == View.GONE) {
                // Expand: remove any previous views, add header and order items.
                holder.layoutOrderItems.removeAllViews();
                int totalCount = 0;
                if (order.getOrderItems() != null) {
                    for (CartItem cartItem : order.getOrderItems()) {
                        totalCount += cartItem.getQuantity();
                    }
                }
                TextView tvHeader = new TextView(context);
                tvHeader.setText("Total Items: " + totalCount);
                tvHeader.setTextSize(14);
                tvHeader.setTypeface(null, Typeface.BOLD);
                holder.layoutOrderItems.addView(tvHeader);
                if (order.getOrderItems() != null) {
                    for (CartItem cartItem : order.getOrderItems()) {
                        TextView tvItem = new TextView(context);
                        tvItem.setText(cartItem.getItem().getName() + " x " + cartItem.getQuantity());
                        tvItem.setTextSize(14);
                        holder.layoutOrderItems.addView(tvItem);
                    }
                }
                holder.layoutOrderItems.setVisibility(View.VISIBLE);
                // Animate toggle icon rotation (0° -> 180°)
                holder.ivToggleItems.animate().rotation(180).setDuration(300).start();
            } else {
                // Collapse: hide order items.
                holder.layoutOrderItems.setVisibility(View.GONE);
                // Animate toggle icon rotation (180° -> 0°)
                holder.ivToggleItems.animate().rotation(0).setDuration(300).start();
            }
        });
    }

    @Override
    public int getItemCount() {
        return (orders != null) ? orders.size() : 0;
    }

    private String getStatusText(int status) {
        switch (status) {
            case 7:
                return "Canceled";
            case 8:
                return "Picked Up";
            case 10:
                return "Completed";
            case 5:
            default:
                return "In Progress";
        }
    }

    private int getStatusColor(int status) {
        switch (status) {
            case 7:
                return context.getResources().getColor(android.R.color.holo_red_dark);
            case 10:
                return context.getResources().getColor(android.R.color.holo_green_dark);
            case 5:
            case 8:
            default:
                return context.getResources().getColor(android.R.color.holo_blue_dark);
        }
    }

    private String getDirectionsUrl(LatLng origin, LatLng dest) {
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;
        String mode = "mode=driving";
        String parameters = str_origin + "&" + str_dest + "&" + mode;
        String output = "json";
        String apiKey = context.getString(R.string.google_maps_key);
        return "https://maps.googleapis.com/maps/api/directions/" + output + "?" + parameters + "&key=" + apiKey;
    }

    private class FetchRouteTask extends AsyncTask<String, Void, List<LatLng>> {
        private final GoogleMap googleMap;
        private final TextView tvDistance;
        private String distanceText = "N/A";

        public FetchRouteTask(GoogleMap map, TextView tvDistance) {
            this.googleMap = map;
            this.tvDistance = tvDistance;
        }

        @Override
        protected List<LatLng> doInBackground(String... urls) {
            String data = "";
            try {
                data = downloadUrl(urls[0]);
                Log.d(TAG, "Downloaded route data: " + data);
            } catch (Exception e) {
                Log.e(TAG, "Error downloading route", e);
            }
            return parseDirections(data);
        }

        @Override
        protected void onPostExecute(List<LatLng> points) {
            if (points != null && !points.isEmpty()) {
                PolylineOptions lineOptions = new PolylineOptions()
                        .addAll(points)
                        .width(8)
                        .color(context.getResources().getColor(android.R.color.holo_blue_dark));
                googleMap.addPolyline(lineOptions);
            }
            Log.d(TAG, "Extracted distance: " + distanceText);
            tvDistance.setText("Distance: " + distanceText);
        }

        private String downloadUrl(String strUrl) throws Exception {
            StringBuilder sb = new StringBuilder();
            URL url = new URL(strUrl);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.connect();
            try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()))) {
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
            }
            return sb.toString();
        }

        private List<LatLng> parseDirections(String jsonData) {
            List<LatLng> polyPoints = new java.util.ArrayList<>();
            try {
                JSONObject jsonObject = new JSONObject(jsonData);
                JSONArray routes = jsonObject.getJSONArray("routes");
                if (routes.length() > 0) {
                    JSONObject route = routes.getJSONObject(0);
                    JSONArray legs = route.getJSONArray("legs");
                    if (legs.length() > 0) {
                        JSONObject leg = legs.getJSONObject(0);
                        JSONObject distanceObj = leg.getJSONObject("distance");
                        distanceText = distanceObj.getString("text");
                    }
                    JSONObject overviewPolyline = route.getJSONObject("overview_polyline");
                    String encoded = overviewPolyline.getString("points");
                    polyPoints = decodePoly(encoded);
                }
            } catch (JSONException e) {
                Log.e(TAG, "Error parsing route JSON", e);
            }
            return polyPoints;
        }
    }

    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new java.util.ArrayList<>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;
        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;
            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;
            LatLng p = new LatLng(((double) lat / 1E5), ((double) lng / 1E5));
            poly.add(p);
        }
        return poly;
    }

    private String formatDistance(double km) {
        if (km < 1.0) {
            double meters = km * 1000;
            return String.format(Locale.getDefault(), "%.0f m", meters);
        } else {
            return String.format(Locale.getDefault(), "%.2f km", km);
        }
    }

    public static class OrderViewHolder extends RecyclerView.ViewHolder {
        public TextView tvOrderId, tvOrderPlacedDate, tvOrderStatus, tvCustomerName,
                tvDriverFee, tvDistance, tvStorePickup, tvDelivery, tvStoreName;
        public ImageView ivToggleItems;
        public LinearLayout layoutOrderItems;
        public MapView mapView;
        public CardView cardView;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvOrderPlacedDate = itemView.findViewById(R.id.tvOrderPlacedDate);
            tvOrderStatus = itemView.findViewById(R.id.tvOrderStatus);
            tvCustomerName = itemView.findViewById(R.id.tvCustomerName);
            tvDriverFee = itemView.findViewById(R.id.tvDriverFee);
            tvDistance = itemView.findViewById(R.id.tvDistance);
            tvStorePickup = itemView.findViewById(R.id.tvStorePickup);
            tvDelivery = itemView.findViewById(R.id.tvDelivery);
            ivToggleItems = itemView.findViewById(R.id.ivToggleItems);
            layoutOrderItems = itemView.findViewById(R.id.layoutOrderItems);
            mapView = itemView.findViewById(R.id.mapRoute);
            cardView = itemView.findViewById(R.id.cardOrder);
            tvStoreName = itemView.findViewById(R.id.tvStoreName);
        }
    }
}
