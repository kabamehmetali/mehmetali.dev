package ca.georgebrown.roseflowerdeliveryapp.adapter;


import android.content.Context;
import android.util.Log;
import android.widget.ArrayAdapter;
import android.widget.Filter;
import android.widget.Filterable;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;

import com.google.android.libraries.places.api.net.FindAutocompletePredictionsRequest;
import com.google.android.libraries.places.api.net.FindAutocompletePredictionsResponse;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.libraries.places.api.model.AutocompletePrediction;

import java.util.ArrayList;
import java.util.List;


/**
 * Adapter to fetch and display Google Places Autocomplete Predictions in AutoCompleteTextView.
 */
public class PlaceAutoSuggestAdapter extends ArrayAdapter<String> implements Filterable {

    private static final String TAG = "PlaceAutoSuggestAdapter";

    private List<String> resultList;  // List of place predictions
    private List<String> placeIdList; // List of place IDs
    private PlacesClient placesClient;

    public PlaceAutoSuggestAdapter(Context context, int resource, PlacesClient placesClient) {
        super(context, resource);
        this.placesClient = placesClient;
        this.resultList = new ArrayList<>();
        this.placeIdList = new ArrayList<>();
    }

    @Override
    public int getCount() {
        return resultList.size();
    }

    @Override
    public String getItem(int position) {
        return resultList.get(position);
    }

    public String getPlaceId(int position) {
        return placeIdList.get(position);
    }

    @Override
    public Filter getFilter() {
        return new Filter() {
            @Override
            protected FilterResults performFiltering(CharSequence constraint) {
                FilterResults results = new FilterResults();

                if (constraint != null && !constraint.toString().isEmpty()) {
                    // Fetch predictions from Google Places API
                    fetchAutocompletePredictions(constraint.toString());

                    // Return the results
                    results.values = resultList;
                    results.count = resultList.size();
                }

                return results;
            }

            @Override
            protected void publishResults(CharSequence constraint, FilterResults results) {
                if (results != null && results.count > 0) {
                    notifyDataSetChanged();
                } else {
                    notifyDataSetInvalidated();
                }
            }
        };
    }

    /**
     * Fetches autocomplete predictions from Google Places API.
     */
    private void fetchAutocompletePredictions(String query) {
        FindAutocompletePredictionsRequest request =
                FindAutocompletePredictionsRequest.builder()
                        .setQuery(query)
                        .build();

        placesClient.findAutocompletePredictions(request)
                .addOnSuccessListener(response -> {
                    resultList.clear();
                    placeIdList.clear();

                    for (AutocompletePrediction prediction : response.getAutocompletePredictions()) {
                        resultList.add(prediction.getFullText(null).toString());
                        placeIdList.add(prediction.getPlaceId());
                    }

                    notifyDataSetChanged();
                })
                .addOnFailureListener(e -> Log.e(TAG, "Error fetching autocomplete predictions: " + e.getMessage()));
    }
}
