package ca.georgebrown.roseflowerdeliveryapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.squareup.picasso.Picasso;

import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;

public class ClientItemAdapter extends RecyclerView.Adapter<ClientItemAdapter.ItemViewHolder> {

    private Context context;
    private List<Item> itemList;
    private OnItemClickListener listener;

    // Interface for item click callbacks.
    public interface OnItemClickListener {
        void onItemClick(Item item);
    }

    // Set the click listener.
    public void setOnItemClickListener(OnItemClickListener listener) {
        this.listener = listener;
    }

    public ClientItemAdapter(Context context, List<Item> itemList) {
        this.context = context;
        this.itemList = itemList;
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Inflate using your client_item_product.xml layout.
        View view = LayoutInflater.from(context).inflate(R.layout.client_item_product, parent, false);
        return new ItemViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        final Item item = itemList.get(position);

        // Set the item name.
        holder.clientItemName.setText(item.getName());

        // Format and set the price (adjust formatting as needed).
        holder.clientItemPrice.setText("$" + item.getPrice());

        // Load the image using Picasso; fallback to the default image if none provided.
        if (item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
            Picasso.get().load(item.getImageUrl()).into(holder.clientItemImage);
        } else {
            holder.clientItemImage.setImageResource(R.drawable.pictureselect);
        }

        // Set click listener to trigger callback.
        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onItemClick(item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return itemList.size();
    }

    // ViewHolder that matches views in client_item_product.xml.
    public static class ItemViewHolder extends RecyclerView.ViewHolder {
        ImageView clientItemImage;
        TextView clientItemName;
        TextView clientItemPrice;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            clientItemImage = itemView.findViewById(R.id.client_item_image);
            clientItemName = itemView.findViewById(R.id.client_item_name);
            clientItemPrice = itemView.findViewById(R.id.client_item_price);
        }
    }
}
