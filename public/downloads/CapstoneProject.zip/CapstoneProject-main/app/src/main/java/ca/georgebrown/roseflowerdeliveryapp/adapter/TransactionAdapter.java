    package ca.georgebrown.roseflowerdeliveryapp.adapter;

    import android.view.LayoutInflater;
    import android.view.View;
    import android.view.ViewGroup;
    import android.widget.TextView;
    import androidx.annotation.NonNull;
    import androidx.recyclerview.widget.RecyclerView;
    import java.util.List;
    import java.util.Locale;
    import ca.georgebrown.roseflowerdeliveryapp.R;
    import ca.georgebrown.roseflowerdeliveryapp.model.Order;

    public class TransactionAdapter extends RecyclerView.Adapter<TransactionAdapter.TransactionViewHolder> {

        private List<Order> orders;
        private OnTransactionClickListener listener;

        public interface OnTransactionClickListener {
            void onTransactionClick(Order order);
        }

        public TransactionAdapter(List<Order> orders) {
            this.orders = orders;
        }

        public void updateList(List<Order> newOrders) {
            this.orders = newOrders;
            notifyDataSetChanged();
        }

        public void setOnTransactionClickListener(OnTransactionClickListener listener) {
            this.listener = listener;
        }

        @NonNull
        @Override
        public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
            // Inflate your provided item layout.
            View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_transaction, parent, false);
            return new TransactionViewHolder(view);
        }

        @Override
        public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
            Order order = orders.get(position);
            holder.tvOrderId.setText("Order #" + order.getId());
            double distance = (order.getDistance() != null) ? order.getDistance() : 0;
            holder.tvDistance.setText(String.format(Locale.getDefault(), "%.2f km", distance));
            double earned = (order.getDriverFee() != null) ? order.getDriverFee() : 0;
            holder.tvEarned.setText(String.format(Locale.getDefault(), "$%.2f", earned));

            // When an item is clicked, show the order details dialog.
            holder.itemView.setOnClickListener(v -> {
                if (listener != null) {
                    listener.onTransactionClick(order);
                }
            });
        }

        @Override
        public int getItemCount() {
            return (orders != null) ? orders.size() : 0;
        }

        static class TransactionViewHolder extends RecyclerView.ViewHolder {
            TextView tvOrderId, tvDistance, tvEarned;

            public TransactionViewHolder(@NonNull View itemView) {
                super(itemView);
                tvOrderId = itemView.findViewById(R.id.tvOrderId);
                tvDistance = itemView.findViewById(R.id.tvDistance);
                tvEarned = itemView.findViewById(R.id.tvEarned);
            }
        }
    }
