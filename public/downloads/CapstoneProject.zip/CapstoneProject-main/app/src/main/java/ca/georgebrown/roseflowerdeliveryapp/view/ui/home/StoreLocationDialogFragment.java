package ca.georgebrown.roseflowerdeliveryapp.view.ui.home;

import android.app.Dialog;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.net.Uri;
import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.Window;
import android.view.ViewGroup.LayoutParams;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.squareup.picasso.Picasso;
import ca.georgebrown.roseflowerdeliveryapp.R;

public class StoreLocationDialogFragment extends DialogFragment implements OnMapReadyCallback {

    private static final String ARG_STORE_NAME = "store_name";
    private static final String ARG_STORE_ADDRESS = "store_address";
    private static final String ARG_STORE_LOGO = "store_logo";
    private static final String ARG_LATITUDE = "latitude";
    private static final String ARG_LONGITUDE = "longitude";

    private String storeName;
    private String storeAddress;
    private String storeLogoUrl; // Optional store logo URL
    private double latitude;
    private double longitude;

    private MapView mapView;
    private GoogleMap googleMap;
    private ImageView ivClose;
    private ImageView ivStoreLogo;
    private TextView tvStoreName;
    private TextView tvStoreAddress;
    private Button btnGetDirections;

    /**
     * Create a new instance of the dialog.
     *
     * @param storeName    The store name.
     * @param storeAddress The store address.
     * @param storeLogoUrl The URL for the store profile image (or empty string if unavailable).
     * @param latitude     The store latitude.
     * @param longitude    The store longitude.
     */
    public static StoreLocationDialogFragment newInstance(String storeName, String storeAddress, String storeLogoUrl, double latitude, double longitude) {
        StoreLocationDialogFragment fragment = new StoreLocationDialogFragment();
        Bundle args = new Bundle();
        args.putString(ARG_STORE_NAME, storeName);
        args.putString(ARG_STORE_ADDRESS, storeAddress);
        args.putString(ARG_STORE_LOGO, storeLogoUrl);
        args.putDouble(ARG_LATITUDE, latitude);
        args.putDouble(ARG_LONGITUDE, longitude);
        fragment.setArguments(args);
        return fragment;
    }

    public StoreLocationDialogFragment() {
        // Empty constructor required for DialogFragment
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getArguments() != null){
            storeName = getArguments().getString(ARG_STORE_NAME);
            storeAddress = getArguments().getString(ARG_STORE_ADDRESS);
            storeLogoUrl = getArguments().getString(ARG_STORE_LOGO);
            latitude = getArguments().getDouble(ARG_LATITUDE);
            longitude = getArguments().getDouble(ARG_LONGITUDE);
        }
        // Use your custom theme; adjust as needed.
        setStyle(DialogFragment.STYLE_NORMAL, R.style.Theme_RoseFlowerDeliveryApp);
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        // Create the dialog and set its background to transparent.
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        if(dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        return dialog;
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_store_location, container, false);

        // Bind views from the layout.
        mapView = view.findViewById(R.id.mapView);
        ivClose = view.findViewById(R.id.ivClose);
        ivStoreLogo = view.findViewById(R.id.ivStoreLogo);
        tvStoreName = view.findViewById(R.id.tvStoreName);
        tvStoreAddress = view.findViewById(R.id.tvStoreAddress);
        btnGetDirections = view.findViewById(R.id.btnGetDirections);

        // Initialize the MapView.
        mapView.onCreate(savedInstanceState);
        mapView.getMapAsync(this);

        // Set store name and address.
        tvStoreName.setText(storeName.toUpperCase());
        tvStoreAddress.setText(storeAddress);

        // Load store logo if available; otherwise use a placeholder.
        if (storeLogoUrl != null && !storeLogoUrl.isEmpty()) {
            Picasso.get().load(storeLogoUrl).into(ivStoreLogo);
        } else {
            ivStoreLogo.setImageResource(R.drawable.pictureselect);
        }

        // Set up the "Get Directions" button.
        btnGetDirections.setOnClickListener(v -> {
            String uri = "google.navigation:q=" + latitude + "," + longitude;
            Intent intent = new Intent(Intent.ACTION_VIEW, Uri.parse(uri));
            intent.setPackage("com.google.android.apps.maps");
            if (intent.resolveActivity(getActivity().getPackageManager()) != null) {
                startActivity(intent);
            }
        });

        // Set up the close button.
        ivClose.setOnClickListener(v -> dismiss());

        return view;
    }

    @Override
    public void onMapReady(GoogleMap gMap) {
        googleMap = gMap;
        MapsInitializer.initialize(getContext());
        LatLng storeLatLng = new LatLng(latitude, longitude);
        googleMap.addMarker(new MarkerOptions().position(storeLatLng).title(storeName));
        googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(storeLatLng, 15));
    }

    @Override
    public void onStart() {
        super.onStart();
        // Set the dialog window to match parent width and wrap content height.
        if (getDialog() != null && getDialog().getWindow() != null) {
            getDialog().getWindow().setLayout(LayoutParams.MATCH_PARENT, LayoutParams.WRAP_CONTENT);
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        mapView.onResume();
    }
    @Override
    public void onPause() {
        super.onPause();
        mapView.onPause();
    }
    @Override
    public void onDestroy() {
        super.onDestroy();
        mapView.onDestroy();
    }
    @Override
    public void onLowMemory() {
        super.onLowMemory();
        mapView.onLowMemory();
    }
}
