package ca.georgebrown.roseflowerdeliveryapp.view.ui.home;

import android.app.Dialog;
import android.content.DialogInterface;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;

import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;

import com.squareup.picasso.Picasso;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;
import ca.georgebrown.roseflowerdeliveryapp.utils.CartManager;

public class ClientItemDetailDialogFragment extends DialogFragment {

    private static final String ARG_ITEM = "arg_item";
    private Item item;
    private int quantity = 1;  // Default quantity

    public static ClientItemDetailDialogFragment newInstance(Item item) {
        ClientItemDetailDialogFragment fragment = new ClientItemDetailDialogFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_ITEM, item);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getArguments() != null) {
            item = (Item) getArguments().getSerializable(ARG_ITEM);
        }
    }

    // Transparent background
    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        Dialog dialog = super.onCreateDialog(savedInstanceState);
        if(dialog.getWindow() != null) {
            dialog.getWindow().setBackgroundDrawable(new ColorDrawable(Color.TRANSPARENT));
        }
        return dialog;
    }

    // Force the dialog to fill horizontally
    @Override
    public void onStart() {
        super.onStart();
        Dialog dialog = getDialog();
        if(dialog != null && dialog.getWindow() != null) {
            dialog.getWindow().setLayout(ViewGroup.LayoutParams.MATCH_PARENT,
                    ViewGroup.LayoutParams.WRAP_CONTENT);
        }
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.dialog_client_item_detail, container, false);

        // References to UI elements
        ImageView ivItemDetailImage = view.findViewById(R.id.ivItemDetailImage);
        TextView tvItemDetailName = view.findViewById(R.id.tvItemDetailName);
        TextView tvItemDetailDescription = view.findViewById(R.id.tvItemDetailDescription);
        TextView tvItemDetailPrice = view.findViewById(R.id.tvItemDetailPrice);
        TextView tvItemDetailFlowerType = view.findViewById(R.id.tvItemDetailFlowerType);
        TextView tvItemDetailFlowerColor = view.findViewById(R.id.tvItemDetailFlowerColor);
        TextView tvItemDetailBouquetSize = view.findViewById(R.id.tvItemDetailBouquetSize);

        Button btnMinus = view.findViewById(R.id.btnMinus);
        Button btnPlus = view.findViewById(R.id.btnPlus);
        TextView tvQuantity = view.findViewById(R.id.tvQuantity);

        EditText etNote = view.findViewById(R.id.etNote);
        Button btnAddToCart = view.findViewById(R.id.btnAddToCart);
        ImageView ivClose = view.findViewById(R.id.ivClose);

        // Set the item data
        if(item != null) {
            tvItemDetailName.setText(item.getName());
            tvItemDetailDescription.setText(item.getDescription());
            tvItemDetailPrice.setText("Price: $" + item.getPrice());
            tvItemDetailFlowerType.setText("Flower Type: " + item.getFlowerType());
            tvItemDetailFlowerColor.setText("Flower Color: " + item.getFlowerColor());
            tvItemDetailBouquetSize.setText("Bouquet Size: " + item.getBouquetSize());

            if(item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
                Picasso.get().load(item.getImageUrl()).into(ivItemDetailImage);
            } else {
                ivItemDetailImage.setImageResource(R.drawable.pictureselect);
            }
        }

        // Initialize quantity display
        tvQuantity.setText(String.valueOf(quantity));

        // Counter buttons
        btnMinus.setOnClickListener(v -> {
            if(quantity > 1) {
                quantity--;
                tvQuantity.setText(String.valueOf(quantity));
            }
        });
        btnPlus.setOnClickListener(v -> {
            quantity++;
            tvQuantity.setText(String.valueOf(quantity));
        });

        // Close button
        ivClose.setOnClickListener(v -> dismiss());

        // Add to Cart logic
        btnAddToCart.setOnClickListener(v -> {
            // Make sure the item has a storeId
            if(item.getStoreId() == null) {
                Toast.makeText(getContext(),
                        "This item has no storeId set. Cannot add to cart.",
                        Toast.LENGTH_SHORT).show();
                return;
            }

            final CartItem newCartItem = new CartItem(
                    item,
                    quantity,
                    etNote.getText().toString().trim(),
                    null
            );

            CartManager cartManager = CartManager.getInstance(getContext());
            String cartStoreId = cartManager.getCartStoreId();
            String newItemStoreId = item.getStoreId();

            // 1) If the cart is empty (cartStoreId == null), set the storeId
            if (cartStoreId == null) {
                // Assign the store for the entire cart
                cartManager.setCartStoreId(newItemStoreId);
                addItemAndFinish(newCartItem);
            }
            // 2) If the cart already has a store but it's different from the new item
            else if (!cartStoreId.equals(newItemStoreId)) {
                new AlertDialog.Builder(getContext())
                        .setTitle("Different Store Detected")
                        .setMessage("Your cart has items from another store. Clear it and add this item?")
                        .setPositiveButton("Clear and Add", new DialogInterface.OnClickListener() {
                            @Override
                            public void onClick(DialogInterface dialog, int which) {
                                cartManager.clearCart();
                                // Assign cart to the new store
                                cartManager.setCartStoreId(newItemStoreId);
                                addItemAndFinish(newCartItem);
                            }
                        })
                        .setNegativeButton("Cancel", (dialog, which) -> dialog.dismiss())
                        .show();
            }
            // 3) If the cart store matches this new item’s store, just add it
            else {
                addItemAndFinish(newCartItem);
            }
        });

        return view;
    }

    // Helper to finalize adding item to cart
    private void addItemAndFinish(CartItem cartItem) {
        CartManager.getInstance(getContext()).addCartItem(cartItem);
        Toast.makeText(getContext(), "Item added to cart!", Toast.LENGTH_SHORT).show();

        // Notify the parent fragment that an item was added
        Bundle result = new Bundle();
        result.putBoolean("itemAdded", true);
        getParentFragmentManager().setFragmentResult("itemAddedKey", result);

        dismiss();
    }
}
