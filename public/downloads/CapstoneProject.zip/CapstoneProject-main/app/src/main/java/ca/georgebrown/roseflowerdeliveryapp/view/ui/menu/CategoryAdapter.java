package ca.georgebrown.roseflowerdeliveryapp.view.ui.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Category;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;

public class CategoryAdapter extends RecyclerView.Adapter<CategoryAdapter.CategoryViewHolder> {

    public interface OnCategoryActionListener {
        void onEditCategory(Category category);
        void onDeleteCategory(Category category);
        void onAddItem(Category category);
    }

    private List<Category> categories;
    private final OnCategoryActionListener categoryListener;
    // For forwarding item events.
    private final ItemAdapter.OnItemActionListener itemListener;

    public CategoryAdapter(OnCategoryActionListener categoryListener, ItemAdapter.OnItemActionListener itemListener) {
        this.categoryListener = categoryListener;
        this.itemListener = itemListener;
    }

    public void setCategories(List<Category> categories) {
        this.categories = categories;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public CategoryViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_category_with_items, parent, false);
        return new CategoryViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CategoryViewHolder holder, int position) {
        Category category = categories.get(position);
        holder.tvCategoryName.setText(category.getName().toUpperCase());

        if (category.getItems() == null || category.getItems().isEmpty()) {
            // No items in this category: hide RecyclerView and show the message.
            holder.rvItems.setVisibility(View.GONE);
            holder.tvNoItems.setVisibility(View.VISIBLE);
        } else {
            // Items available: show RecyclerView and hide the message.
            holder.rvItems.setVisibility(View.VISIBLE);
            holder.tvNoItems.setVisibility(View.GONE);
            ItemAdapter itemAdapter = new ItemAdapter(category, itemListener);
            holder.rvItems.setLayoutManager(new LinearLayoutManager(holder.itemView.getContext()));
            holder.rvItems.setAdapter(itemAdapter);
            itemAdapter.setItems(category.getItems());
        }

        holder.btnEditCategory.setOnClickListener(v -> {
            if (categoryListener != null) {
                categoryListener.onEditCategory(category);
            }
        });
        holder.btnDeleteCategory.setOnClickListener(v -> {
            if (categoryListener != null) {
                categoryListener.onDeleteCategory(category);
            }
        });
        holder.btnAddItem.setOnClickListener(v -> {
            if (categoryListener != null) {
                categoryListener.onAddItem(category);
            }
        });
    }


    @Override
    public int getItemCount() {
        return categories == null ? 0 : categories.size();
    }

    static class CategoryViewHolder extends RecyclerView.ViewHolder {
        TextView tvCategoryName;
        RecyclerView rvItems;
        TextView tvNoItems;
        ImageButton btnEditCategory, btnDeleteCategory, btnAddItem;

        public CategoryViewHolder(@NonNull View itemView) {
            super(itemView);
            tvCategoryName = itemView.findViewById(R.id.tvCategoryName);
            rvItems = itemView.findViewById(R.id.rvItems);
            tvNoItems = itemView.findViewById(R.id.tvNoItems);
            btnEditCategory = itemView.findViewById(R.id.btnEditCategory);
            btnDeleteCategory = itemView.findViewById(R.id.btnDeleteCategory);
            btnAddItem = itemView.findViewById(R.id.btnAddItem);
        }
    }
}
