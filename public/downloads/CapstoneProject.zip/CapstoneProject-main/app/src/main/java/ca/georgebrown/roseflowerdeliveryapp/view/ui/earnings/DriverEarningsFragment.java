package ca.georgebrown.roseflowerdeliveryapp.view.ui.earnings;

import android.app.DatePickerDialog;
import android.content.Context;
import android.content.SharedPreferences;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.DatePicker;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.data.Entry;
import com.github.mikephil.charting.formatter.ValueFormatter;
import com.github.mikephil.charting.highlight.Highlight;
import com.github.mikephil.charting.listener.OnChartValueSelectedListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.TreeMap;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.TransactionAdapter;
import ca.georgebrown.roseflowerdeliveryapp.dialog.TransactionDetailsDialog;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class DriverEarningsFragment extends Fragment {

    private static final String TAG = "DriverEarningsFragment";
    private static final String PREFS_NAME = "EarningsPrefs";
    private static final String KEY_FROM_DATE = "fromDate";
    private static final String KEY_TO_DATE = "toDate";

    private TextView tvFromDate, tvToDate, tvTotalEarnings, tvTotalDistance, tvOrdersCompleted, tvNoOrders;
    private BarChart earningsChart;
    private RecyclerView rvOrders;
    private Spinner spinnerPresets;

    // Date formats
    private SimpleDateFormat displayFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
    private SimpleDateFormat firestoreFormat1 = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
    private SimpleDateFormat firestoreFormat2 = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

    private Date selectedFromDate, selectedToDate;
    private List<Order> allOrders = new ArrayList<>();
    private List<Order> filteredOrders = new ArrayList<>();
    private TransactionAdapter orderAdapter;
    private FirebaseFirestore firestore;
    private String driverId;

    // List of preset options – index 0 is "Custom"
    private List<String> presetOptions;

    public DriverEarningsFragment() {
        // Required empty public constructor
    }

    public static DriverEarningsFragment newInstance() {
        return new DriverEarningsFragment();
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        firestore = FirebaseFirestore.getInstance();
        driverId = FirebaseAuth.getInstance().getUid();

        SharedPreferences prefs = getActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        String fromDateStr = prefs.getString(KEY_FROM_DATE, null);
        String toDateStr = prefs.getString(KEY_TO_DATE, null);
        Date today = new Date();
        if (fromDateStr != null && toDateStr != null) {
            try {
                selectedFromDate = displayFormat.parse(fromDateStr);
                selectedToDate = displayFormat.parse(toDateStr);
            } catch (ParseException e) {
                e.printStackTrace();
                selectedFromDate = today;
                selectedToDate = today;
            }
        } else {
            selectedFromDate = today;
            selectedToDate = today;
        }
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_driver_earnings, container, false);

        tvFromDate = view.findViewById(R.id.tvFromDate);
        tvToDate = view.findViewById(R.id.tvToDate);
        tvTotalEarnings = view.findViewById(R.id.tvTotalEarnings);
        tvTotalDistance = view.findViewById(R.id.tvTotalDistance);
        tvOrdersCompleted = view.findViewById(R.id.tvOrdersCompleted);
        tvNoOrders = view.findViewById(R.id.tvNoOrders);
        earningsChart = view.findViewById(R.id.earningsChart);
        rvOrders = view.findViewById(R.id.rvOrders);
        spinnerPresets = view.findViewById(R.id.spinnerPresets);

        tvFromDate.setText(displayFormat.format(selectedFromDate));
        tvToDate.setText(displayFormat.format(selectedToDate));

        rvOrders.setLayoutManager(new LinearLayoutManager(getContext()));
        orderAdapter = new TransactionAdapter(new ArrayList<>());
        rvOrders.setAdapter(orderAdapter);

        // Open order details dialog on item click.
        orderAdapter.setOnTransactionClickListener(order -> {
            TransactionDetailsDialog dialog = new TransactionDetailsDialog(getContext(), order);
            dialog.show();
        });

        // Date TextViews click listeners to show date pickers.
        tvFromDate.setOnClickListener(v -> {
            showDatePicker(selectedFromDate, date -> {
                selectedFromDate = date;
                if (selectedFromDate.after(selectedToDate)) {
                    selectedToDate = selectedFromDate;
                    tvToDate.setText(displayFormat.format(selectedToDate));
                }
                tvFromDate.setText(displayFormat.format(selectedFromDate));
                filterOrders();
                updateSpinnerSelection();
            });
        });

        tvToDate.setOnClickListener(v -> {
            showDatePicker(selectedToDate, date -> {
                selectedToDate = date;
                if (selectedToDate.before(selectedFromDate)) {
                    selectedFromDate = selectedToDate;
                    tvFromDate.setText(displayFormat.format(selectedFromDate));
                }
                tvToDate.setText(displayFormat.format(selectedToDate));
                filterOrders();
                updateSpinnerSelection();
            });
        });

        // Initialize preset options – index 0 will represent "Custom"
        presetOptions = new ArrayList<>();
        presetOptions.add("Custom");
        presetOptions.add("Today");
        presetOptions.add("Yesterday");
        presetOptions.add("Last 7 Days");
        presetOptions.add("Last 30 Days");
        presetOptions.add("This Month");
        presetOptions.add("Last Month");

        // Use our custom spinner_item layout to center the text.
        ArrayAdapter<String> adapter = new ArrayAdapter<>(getContext(),
                R.layout.spinner_item, presetOptions);
        adapter.setDropDownViewResource(R.layout.spinner_item);
        spinnerPresets.setAdapter(adapter);

        spinnerPresets.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            boolean firstCall = true;
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                // Skip initial call
                if(firstCall) {
                    firstCall = false;
                    return;
                }
                String preset = presetOptions.get(position);
                Date today = removeTime(new Date());
                Calendar cal = Calendar.getInstance();
                switch (preset) {
                    case "Today":
                        selectedFromDate = today;
                        selectedToDate = today;
                        break;
                    case "Yesterday":
                        selectedFromDate = addDays(today, -1);
                        selectedToDate = addDays(today, -1);
                        break;
                    case "Last 7 Days":
                        selectedToDate = today;
                        selectedFromDate = addDays(today, -6);
                        break;
                    case "Last 30 Days":
                        selectedToDate = today;
                        selectedFromDate = addDays(today, -29);
                        break;
                    case "This Month":
                        cal.setTime(today);
                        cal.set(Calendar.DAY_OF_MONTH, 1);
                        selectedFromDate = removeTime(cal.getTime());
                        selectedToDate = today;
                        break;
                    case "Last Month":
                        cal.setTime(today);
                        cal.add(Calendar.MONTH, -1);
                        cal.set(Calendar.DAY_OF_MONTH, 1);
                        selectedFromDate = removeTime(cal.getTime());
                        cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
                        selectedToDate = removeTime(cal.getTime());
                        break;
                    default:
                        // "Custom" or any unhandled option: do nothing.
                        return;
                }
                updateDateTextViews();
                filterOrders();
            }

            @Override
            public void onNothingSelected(AdapterView<?> parent) {
                // Do nothing.
            }
        });

        loadOrders();
        updateSpinnerSelection();
        return view;
    }

    private interface DatePickerCallback {
        void onDateSelected(Date date);
    }

    private void showDatePicker(Date initialDate, DatePickerCallback callback) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(initialDate);
        int year = cal.get(Calendar.YEAR);
        int month = cal.get(Calendar.MONTH);
        int day = cal.get(Calendar.DAY_OF_MONTH);
        DatePickerDialog dialog = new DatePickerDialog(getContext(), (DatePicker view, int selectedYear, int selectedMonth, int selectedDay) -> {
            Calendar selectedCal = Calendar.getInstance();
            selectedCal.set(selectedYear, selectedMonth, selectedDay);
            callback.onDateSelected(selectedCal.getTime());
        }, year, month, day);
        dialog.getDatePicker().setMaxDate(System.currentTimeMillis());
        dialog.show();
    }

    private Date parseOrderDate(String dateStr) {
        if (dateStr == null) return null;
        try {
            return firestoreFormat1.parse(dateStr);
        } catch (ParseException e) {
            try {
                return firestoreFormat2.parse(dateStr);
            } catch (ParseException ex) {
                Log.e(TAG, "Failed to parse orderPlacedDate: " + dateStr);
                return null;
            }
        }
    }

    private void loadOrders() {
        firestore.collection("drivers")
                .document(driverId)
                .collection("orders")
                .get()
                .addOnSuccessListener(queryDocumentSnapshots -> {
                    allOrders.clear();
                    for (DocumentSnapshot doc : queryDocumentSnapshots) {
                        Order order = doc.toObject(Order.class);
                        if (order != null) {
                            order.setId(doc.getId());
                            Log.d(TAG, "Order " + order.getId() + " orderPlacedDate: " + order.getOrderPlacedDate());
                            allOrders.add(order);
                        }
                    }
                    Log.d(TAG, "Number of orders fetched: " + allOrders.size());
                    filterOrders();
                })
                .addOnFailureListener(e -> Toast.makeText(getContext(), "Failed to load orders", Toast.LENGTH_SHORT).show());
    }

    private void filterOrders() {
        filteredOrders.clear();
        Calendar cal = Calendar.getInstance();
        cal.setTime(selectedFromDate);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        Date fromDayStart = cal.getTime();

        cal.setTime(selectedToDate);
        cal.set(Calendar.HOUR_OF_DAY, 23);
        cal.set(Calendar.MINUTE, 59);
        cal.set(Calendar.SECOND, 59);
        cal.set(Calendar.MILLISECOND, 999);
        Date toDayEnd = cal.getTime();

        for (Order order : allOrders) {
            if (order.getOrderPlacedDate() != null) {
                Date orderDate = parseOrderDate(order.getOrderPlacedDate());
                if (orderDate != null && !orderDate.before(fromDayStart) && !orderDate.after(toDayEnd)) {
                    filteredOrders.add(order);
                }
            }
        }
        Log.d(TAG, "Filtered orders count: " + filteredOrders.size());
        updateStatsAndChart();
        saveSelectedDates();

        if (filteredOrders.isEmpty()) {
            orderAdapter.updateList(filteredOrders);
            tvNoOrders.setVisibility(View.VISIBLE);
        } else {
            orderAdapter.updateList(filteredOrders);
        }
    }

    /**
     * Groups orders by day and sets up the bar chart with total earnings.
     */
    private void updateStatsAndChart() {
        Map<String, Double> earningsByDate = new TreeMap<>();
        SimpleDateFormat keyFormat = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        for (Order order : filteredOrders) {
            if (order.getStatus() == 10) {
                Date orderDate = parseOrderDate(order.getOrderPlacedDate());
                if (orderDate != null) {
                    String key = keyFormat.format(orderDate);
                    double earnings = (order.getDriverFee() != null) ? order.getDriverFee() : 0;
                    earningsByDate.put(key, earningsByDate.getOrDefault(key, 0.0) + earnings);
                }
            }
        }

        List<BarEntry> entries = new ArrayList<>();
        List<String> dateKeys = new ArrayList<>();
        int index = 0;
        for (Map.Entry<String, Double> entry : earningsByDate.entrySet()) {
            dateKeys.add(entry.getKey());
            entries.add(new BarEntry(index, entry.getValue().floatValue()));
            index++;
        }

        XAxis xAxis = earningsChart.getXAxis();
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1f);
        xAxis.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                int idx = (int) value;
                if (idx < dateKeys.size()) {
                    try {
                        Date date = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(dateKeys.get(idx));
                        return new SimpleDateFormat("dd MMM", Locale.getDefault()).format(date);
                    } catch (ParseException e) {
                        return "";
                    }
                }
                return "";
            }
        });

        BarDataSet dataSet = new BarDataSet(entries, "Earnings per Day");
        dataSet.setColor(Color.parseColor("#68b932"));
        dataSet.setHighLightColor(Color.parseColor("#006400"));
        // Make the earnings value text bigger and bold:
        dataSet.setValueTextSize(12f);
        dataSet.setValueTextColor(Color.parseColor("#006400"));
        dataSet.setValueTypeface(Typeface.DEFAULT_BOLD);
        dataSet.setValueFormatter(new ValueFormatter() {
            @Override
            public String getFormattedValue(float value) {
                return "$" + String.format(Locale.getDefault(), "%.2f", value);
            }
        });
        BarData barData = new BarData(dataSet);
        earningsChart.setData(barData);
        earningsChart.getDescription().setEnabled(false);
        earningsChart.invalidate();

        earningsChart.setOnChartValueSelectedListener(new OnChartValueSelectedListener() {
            @Override
            public void onValueSelected(Entry e, Highlight h) {
                int pos = (int) e.getX();
                if (pos < dateKeys.size()) {
                    String selectedKey = dateKeys.get(pos);
                    List<Order> ordersForDay = new ArrayList<>();
                    for (Order order : filteredOrders) {
                        Date orderDate = parseOrderDate(order.getOrderPlacedDate());
                        if (orderDate != null) {
                            String key = keyFormat.format(orderDate);
                            if (key.equals(selectedKey)) {
                                ordersForDay.add(order);
                            }
                        }
                    }
                    orderAdapter.updateList(ordersForDay);
                    updateStatsUI(ordersForDay);
                    tvNoOrders.setVisibility(ordersForDay.isEmpty() ? View.VISIBLE : View.GONE);
                }
            }

            @Override
            public void onNothingSelected() {
                orderAdapter.updateList(filteredOrders);
                updateStatsUI(filteredOrders);
                tvNoOrders.setVisibility(earningsByDate.isEmpty() ? View.VISIBLE : View.GONE);
            }
        });

        updateStatsUI(filteredOrders);
        // Display "No orders available" if there is no earnings data in the chart.
        tvNoOrders.setVisibility(earningsByDate.isEmpty() ? View.VISIBLE : View.GONE);
    }

    private void updateStatsUI(List<Order> orders) {
        double totalEarnings = 0;
        double totalDistance = 0;
        int ordersCompleted = 0;
        for (Order order : orders) {
            if (order.getStatus() == 10) {
                ordersCompleted++;
                double earned = (order.getDriverFee() != null) ? order.getDriverFee() : 0;
                totalEarnings += earned;
                double distance = (order.getDistance() != null) ? order.getDistance() : 0;
                totalDistance += distance;
            }
        }
        tvTotalEarnings.setText(String.format(Locale.getDefault(), "$%.2f", totalEarnings));
        tvTotalDistance.setText(String.format(Locale.getDefault(), "%.2f km", totalDistance));
        tvOrdersCompleted.setText(String.valueOf(ordersCompleted));
    }

    private void saveSelectedDates() {
        SharedPreferences prefs = getActivity().getSharedPreferences(PREFS_NAME, Context.MODE_PRIVATE);
        SharedPreferences.Editor editor = prefs.edit();
        editor.putString(KEY_FROM_DATE, displayFormat.format(selectedFromDate));
        editor.putString(KEY_TO_DATE, displayFormat.format(selectedToDate));
        editor.apply();
    }

    // Helper to remove time components from a Date.
    private Date removeTime(Date date) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.set(Calendar.HOUR_OF_DAY, 0);
        cal.set(Calendar.MINUTE, 0);
        cal.set(Calendar.SECOND, 0);
        cal.set(Calendar.MILLISECOND, 0);
        return cal.getTime();
    }

    // Helper to add days to a Date.
    private Date addDays(Date date, int days) {
        Calendar cal = Calendar.getInstance();
        cal.setTime(date);
        cal.add(Calendar.DAY_OF_MONTH, days);
        return cal.getTime();
    }

    private void updateDateTextViews() {
        tvFromDate.setText(displayFormat.format(selectedFromDate));
        tvToDate.setText(displayFormat.format(selectedToDate));
        saveSelectedDates();
        updateSpinnerSelection();
    }

    /**
     * Update the spinner selection based on the current date range.
     * If none of the preset ranges match, set the spinner to "Custom".
     */
    private void updateSpinnerSelection() {
        Date today = removeTime(new Date());
        if (selectedFromDate.equals(today) && selectedToDate.equals(today)) {
            spinnerPresets.setSelection(presetOptions.indexOf("Today"));
            return;
        } else if (selectedFromDate.equals(addDays(today, -1)) && selectedToDate.equals(addDays(today, -1))) {
            spinnerPresets.setSelection(presetOptions.indexOf("Yesterday"));
            return;
        } else if (selectedToDate.equals(today) && selectedFromDate.equals(addDays(today, -6))) {
            spinnerPresets.setSelection(presetOptions.indexOf("Last 7 Days"));
            return;
        } else if (selectedToDate.equals(today) && selectedFromDate.equals(addDays(today, -29))) {
            spinnerPresets.setSelection(presetOptions.indexOf("Last 30 Days"));
            return;
        } else {
            Calendar cal = Calendar.getInstance();
            cal.setTime(new Date());
            cal.set(Calendar.DAY_OF_MONTH, 1);
            Date firstDayThisMonth = removeTime(cal.getTime());
            if (selectedFromDate.equals(firstDayThisMonth) && selectedToDate.equals(today)) {
                spinnerPresets.setSelection(presetOptions.indexOf("This Month"));
                return;
            }
            cal.setTime(new Date());
            cal.add(Calendar.MONTH, -1);
            cal.set(Calendar.DAY_OF_MONTH, 1);
            Date firstDayLastMonth = removeTime(cal.getTime());
            cal.set(Calendar.DAY_OF_MONTH, cal.getActualMaximum(Calendar.DAY_OF_MONTH));
            Date lastDayLastMonth = removeTime(cal.getTime());
            if (selectedFromDate.equals(firstDayLastMonth) && selectedToDate.equals(lastDayLastMonth)) {
                spinnerPresets.setSelection(presetOptions.indexOf("Last Month"));
                return;
            }
        }
        // If none match, set to "Custom"
        spinnerPresets.setSelection(presetOptions.indexOf("Custom"));
    }
}
