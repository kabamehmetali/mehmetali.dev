package ca.georgebrown.roseflowerdeliveryapp.utils;

import android.app.Activity;
import android.app.Dialog;
import android.media.MediaPlayer;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.OrderItemsAdapter;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class OrderDialogManager {

    public interface OrderDialogActionListener {
        void onAccept(Order order);
        void onReject(Order order);
    }

    public static void showOrderPopup(Activity activity, Order order, OrderDialogActionListener listener) {
        // Start playing the ringtone
        MediaPlayer mediaPlayer = MediaPlayer.create(activity, R.raw.ringtone);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

        // Create and configure the dialog
        final Dialog dialog = new Dialog(activity);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_accept_reject);

        if (dialog.getWindow() != null) {
            WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
            params.width = WindowManager.LayoutParams.WRAP_CONTENT;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.gravity = Gravity.CENTER;
            dialog.getWindow().setAttributes(params);
        }

        // Set up dialog views
        TextView tvDialogTitle = dialog.findViewById(R.id.tvDialogTitle);
        TextView tvUserName = dialog.findViewById(R.id.tvUserName);
        RecyclerView recyclerDialogItems = dialog.findViewById(R.id.recyclerDialogItems);
        Button btnDialogAccept = dialog.findViewById(R.id.btnDialogAccept);
        Button btnDialogReject = dialog.findViewById(R.id.btnDialogReject);

        // Title: "Order <docId>"
        tvDialogTitle.setText("Order " + order.getId());

        // userName fallback to "Unknown" if null
        String userName = order.getUserName();
        if (userName == null || userName.trim().isEmpty()) {
            userName = "Unknown";
        }
        tvUserName.setText("Placed by: " + userName);

        // Nested RecyclerView for order items
        OrderItemsAdapter itemsAdapter = new OrderItemsAdapter(activity, order.getOrderItems());
        recyclerDialogItems.setLayoutManager(new LinearLayoutManager(activity));
        recyclerDialogItems.setAdapter(itemsAdapter);

        // ACCEPT
        btnDialogAccept.setOnClickListener(v -> {
            mediaPlayer.stop();
            mediaPlayer.release();
            dialog.dismiss();
            if (listener != null) listener.onAccept(order);
        });

        // REJECT
        btnDialogReject.setOnClickListener(v -> {
            mediaPlayer.stop();
            mediaPlayer.release();
            dialog.dismiss();
            if (listener != null) listener.onReject(order);
        });

        dialog.setCancelable(false);
        dialog.show();
    }
}
