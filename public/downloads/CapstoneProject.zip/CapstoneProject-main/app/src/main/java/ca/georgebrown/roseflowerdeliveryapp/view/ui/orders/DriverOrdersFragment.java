package ca.georgebrown.roseflowerdeliveryapp.view.ui.orders;

import android.app.DatePickerDialog;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.DatePicker;
import android.widget.ImageButton;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.DriverOrdersAdapter;
import ca.georgebrown.roseflowerdeliveryapp.model.Location;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class DriverOrdersFragment extends Fragment {

    private RecyclerView recyclerView;
    private DriverOrdersAdapter adapter;
    private List<Order> ordersList = new ArrayList<>(); // filtered orders for UI
    private List<Order> allOrders = new ArrayList<>();    // full list from Firestore
    private FirebaseFirestore firestore;
    private String driverId;
    private View layoutNoOrders;
    private TextView tvSelectedDate;
    private ImageButton btnPrevDate, btnNextDate;
    // selectedDateStr now uses "dd MMM yyyy" format.
    private String selectedDateStr;

    // Format for display and filtering
    private final SimpleDateFormat displayFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());
    // Format for parsing orderPlacedDate (assumed stored as "yyyy-MM-dd HH:mm:ss")
    private final SimpleDateFormat originalFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        View root = inflater.inflate(R.layout.fragment_driver_orders, container, false);
        recyclerView = root.findViewById(R.id.recyclerDriverOrders);
        layoutNoOrders = root.findViewById(R.id.layoutNoOrders);
        tvSelectedDate = root.findViewById(R.id.tvSelectedDate);
        btnPrevDate = root.findViewById(R.id.btnPrevDate);
        btnNextDate = root.findViewById(R.id.btnNextDate);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        adapter = new DriverOrdersAdapter(ordersList, getContext());
        recyclerView.setAdapter(adapter);

        firestore = FirebaseFirestore.getInstance();
        driverId = FirebaseAuth.getInstance().getUid();

        // Set default selected date as today (format: "dd MMM yyyy")
        Date today = new Date();
        selectedDateStr = displayFormat.format(today);
        tvSelectedDate.setText(selectedDateStr);

        // Set up the DatePickerDialog on clicking the date TextView.
        tvSelectedDate.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            try {
                Date currentDate = displayFormat.parse(selectedDateStr);
                cal.setTime(currentDate);
            } catch (ParseException e) {
                e.printStackTrace();
            }
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH);
            int day = cal.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(getContext(), new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int selYear, int selMonth, int selDay) {
                    Calendar selectedCal = Calendar.getInstance();
                    selectedCal.set(selYear, selMonth, selDay);
                    selectedDateStr = displayFormat.format(selectedCal.getTime());
                    tvSelectedDate.setText(selectedDateStr);
                    filterAndDisplayOrders();
                }
            }, year, month, day);
            // Disable future dates
            datePickerDialog.getDatePicker().setMaxDate(today.getTime());
            datePickerDialog.show();
        });

        // Set up left (previous) and right (next) buttons for date navigation.
        btnPrevDate.setOnClickListener(v -> {
            try {
                Date currentDate = displayFormat.parse(selectedDateStr);
                Calendar cal = Calendar.getInstance();
                cal.setTime(currentDate);
                cal.add(Calendar.DAY_OF_MONTH, -1);
                selectedDateStr = displayFormat.format(cal.getTime());
                tvSelectedDate.setText(selectedDateStr);
                filterAndDisplayOrders();
            } catch (ParseException e) {
                e.printStackTrace();
            }
        });

        btnNextDate.setOnClickListener(v -> {
            try {
                Date currentDate = displayFormat.parse(selectedDateStr);
                Calendar cal = Calendar.getInstance();
                cal.setTime(currentDate);
                cal.add(Calendar.DAY_OF_MONTH, 1);
                // Only update if the new date is not after today
                if (!cal.getTime().after(today)) {
                    selectedDateStr = displayFormat.format(cal.getTime());
                    tvSelectedDate.setText(selectedDateStr);
                    filterAndDisplayOrders();
                }
            } catch (ParseException e) {
                e.printStackTrace();
            }
        });

        listenToDriverOrders();
        return root;
    }

    /**
     * Listens to orders under "drivers/{driverId}/orders".
     */
    private void listenToDriverOrders() {
        firestore.collection("drivers")
                .document(driverId)
                .collection("orders")
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Log.e("DriverOrdersFragment", "Error listening to driver orders: " + e.getMessage());
                        return;
                    }

                    if (snapshots == null || snapshots.isEmpty()) {
                        allOrders.clear();
                        adapter.updateList(new ArrayList<>());
                        recyclerView.setVisibility(View.GONE);
                        layoutNoOrders.setVisibility(View.VISIBLE);
                        return;
                    }

                    List<DocumentSnapshot> driverOrderDocs = snapshots.getDocuments();
                    List<Order> tempOrders = new ArrayList<>();
                    final int totalDocs = driverOrderDocs.size();
                    final int[] processedCount = new int[1]; // to track how many have been processed

                    for (DocumentSnapshot driverDoc : driverOrderDocs) {
                        Order driverOrder = driverDoc.toObject(Order.class);
                        if (driverOrder == null) {
                            processedCount[0]++;
                            if (processedCount[0] == totalDocs) {
                                updateAllOrders(tempOrders);
                            }
                            continue;
                        }
                        driverOrder.setId(driverDoc.getId());

                        // If delivery location is missing but lat/long exists, create a Location object.
                        if (driverOrder.getDeliveryLocation() == null
                                && driverDoc.contains("deliveryLatitude")
                                && driverDoc.contains("deliveryLongitude")) {
                            ca.georgebrown.roseflowerdeliveryapp.model.Location delivery = new ca.georgebrown.roseflowerdeliveryapp.model.Location();
                            delivery.setLatitude(driverDoc.getDouble("deliveryLatitude"));
                            delivery.setLongitude(driverDoc.getDouble("deliveryLongitude"));
                            if (driverDoc.contains("deliveryAddress")) {
                                delivery.setFormattedAddress(driverDoc.getString("deliveryAddress"));
                            }
                            driverOrder.setDeliveryLocation(delivery);
                        }
                        if (driverDoc.contains("deliveryAddress")) {
                            driverOrder.setDeliveryAddress(driverDoc.getString("deliveryAddress"));
                        }

                        // Get store information if available
                        String storeId = driverOrder.getStoreId();
                        if (storeId == null || storeId.trim().isEmpty()) {
                            tempOrders.add(driverOrder);
                            processedCount[0]++;
                            if (processedCount[0] == totalDocs) {
                                updateAllOrders(tempOrders);
                            }
                            continue;
                        }

                        firestore.collection("users")
                                .document(storeId)
                                .get()
                                .addOnSuccessListener(storeDoc -> {
                                    if (storeDoc.exists()) {
                                        String storeName = storeDoc.getString("storeName");
                                        if (storeName == null || storeName.trim().isEmpty()) {
                                            storeName = "Unknown Store";
                                        }
                                        driverOrder.setStoreName(storeName);
                                    } else {
                                        driverOrder.setStoreName("Unknown Store");
                                    }
                                    tempOrders.add(driverOrder);
                                    processedCount[0]++;
                                    if (processedCount[0] == totalDocs) {
                                        updateAllOrders(tempOrders);
                                    }
                                })
                                .addOnFailureListener(err -> {
                                    Log.e("DriverOrdersFragment", "Error fetching store info: " + err.getMessage());
                                    driverOrder.setStoreName("Unknown Store");
                                    tempOrders.add(driverOrder);
                                    processedCount[0]++;
                                    if (processedCount[0] == totalDocs) {
                                        updateAllOrders(tempOrders);
                                    }
                                });
                    }
                });
    }

    /**
     * Updates the full list of orders and triggers filtering.
     */
    private void updateAllOrders(List<Order> newOrders) {
        allOrders.clear();
        allOrders.addAll(newOrders);
        filterAndDisplayOrders();
    }

    /**
     * Filters orders based on the selected date and sorts them by status.
     */
    private void filterAndDisplayOrders() {
        List<Order> filteredOrders = new ArrayList<>();
        for (Order order : allOrders) {
            if (order.getOrderPlacedDate() != null) {
                try {
                    // Parse the original orderPlacedDate and format it to display format.
                    Date orderDate = originalFormat.parse(order.getOrderPlacedDate());
                    String orderDateStr = displayFormat.format(orderDate);
                    if (orderDateStr.equals(selectedDateStr)) {
                        filteredOrders.add(order);
                    }
                } catch (ParseException e) {
                    e.printStackTrace();
                }
            }
        }
        sortOrders(filteredOrders);
        ordersList.clear();
        ordersList.addAll(filteredOrders);
        if (ordersList.isEmpty()) {
            recyclerView.setVisibility(View.GONE);
            layoutNoOrders.setVisibility(View.VISIBLE);
        } else {
            recyclerView.setVisibility(View.VISIBLE);
            layoutNoOrders.setVisibility(View.GONE);
        }
        adapter.updateList(ordersList);
    }

    /**
     * Sorts orders so that:
     *  - In Progress (status 5) comes first,
     *  - Picked Up (status 8) comes second,
     *  - Completed (status 10) comes third,
     *  - Canceled (status 7) appears last.
     */
    private void sortOrders(List<Order> orders) {
        Collections.sort(orders, (o1, o2) -> {
            int order1 = getStatusSortOrder(o1.getStatus());
            int order2 = getStatusSortOrder(o2.getStatus());
            return order1 - order2;
        });
    }

    /**
     * Returns an integer representing the sort order for each status.
     */
    private int getStatusSortOrder(int status) {
        switch (status) {
            case 5:  // In Progress
                return 1;
            case 8:  // Picked Up
                return 2;
            case 10: // Completed
                return 3;
            case 7:  // Canceled
                return 4;
            default:
                return 5;
        }
    }
}
