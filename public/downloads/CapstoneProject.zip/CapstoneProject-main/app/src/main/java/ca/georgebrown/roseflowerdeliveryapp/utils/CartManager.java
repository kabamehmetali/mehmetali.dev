package ca.georgebrown.roseflowerdeliveryapp.utils;

import android.content.Context;
import android.content.SharedPreferences;

import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;

public class CartManager {

    private static final String PREFS_CART = "cart_prefs";
    private static final String KEY_CART_ITEMS = "cart_items";

    // NEW: key for the storeId assigned to the cart
    private static final String KEY_CART_STORE_ID = "cart_store_id";

    private SharedPreferences sharedPreferences;
    private Gson gson;
    private static CartManager instance;

    private CartManager(Context context) {
        sharedPreferences = context.getSharedPreferences(PREFS_CART, Context.MODE_PRIVATE);
        gson = new Gson();
    }

    public static CartManager getInstance(Context context) {
        if (instance == null) {
            instance = new CartManager(context.getApplicationContext());
        }
        return instance;
    }

    /**
     * Returns the storeId currently assigned to the cart (or null if not set).
     */
    public String getCartStoreId() {
        return sharedPreferences.getString(KEY_CART_STORE_ID, null);
    }

    /**
     * Sets the storeId for this cart and saves it to SharedPreferences.
     */
    public void setCartStoreId(String storeId) {
        sharedPreferences.edit().putString(KEY_CART_STORE_ID, storeId).apply();
    }

    public List<CartItem> getCartItems() {
        String json = sharedPreferences.getString(KEY_CART_ITEMS, null);
        if (json != null) {
            Type type = new TypeToken<List<CartItem>>(){}.getType();
            return gson.fromJson(json, type);
        }
        return new ArrayList<>();
    }

    /**
     * If an item with same ID & note exists, update its quantity, else add it.
     */
    public void addCartItem(CartItem newCartItem) {
        List<CartItem> cartItems = getCartItems();
        boolean found = false;
        String newNote = newCartItem.getNote() != null ? newCartItem.getNote().trim() : "";
        for (CartItem existingItem : cartItems) {
            if (existingItem.getItem().getId().equals(newCartItem.getItem().getId())) {
                String existingNote = existingItem.getNote() != null ? existingItem.getNote().trim() : "";
                if (existingNote.equals(newNote)) {
                    // Same item + same note => just add quantities
                    existingItem.setQuantity(existingItem.getQuantity() + newCartItem.getQuantity());
                    found = true;
                    break;
                }
            }
        }
        if (!found) {
            cartItems.add(newCartItem);
        }
        saveCartItems(cartItems);
    }

    /**
     * Removes a specific cart item.
     */
    public void removeCartItem(CartItem cartItem) {
        List<CartItem> cartItems = getCartItems();
        cartItems.remove(cartItem);
        saveCartItems(cartItems);
    }

    /**
     * Clears the entire cart AND the assigned cartStoreId.
     */
    public void clearCart() {
        // Remove both cart items and the stored storeId
        sharedPreferences.edit()
                .remove(KEY_CART_ITEMS)
                .remove(KEY_CART_STORE_ID)
                .apply();
    }

    /**
     * Saves the current cart list as JSON in SharedPreferences.
     */
    public void saveCartItems(List<CartItem> cartItems) {
        String json = gson.toJson(cartItems);
        sharedPreferences.edit().putString(KEY_CART_ITEMS, json).apply();
    }

    /**
     * Sums the quantity of items in the cart.
     */
    public int getCartItemCount() {
        int count = 0;
        for (CartItem item : getCartItems()) {
            count += item.getQuantity();
        }
        return count;
    }
}
