package ca.georgebrown.roseflowerdeliveryapp.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class Item implements Serializable {

    private static final long serialVersionUID = 1L;

    @SerializedName("id")
    private String id;

    @SerializedName("categoryId")
    private String categoryId;

    @SerializedName("name")
    private String name;

    @SerializedName("description")
    private String description;

    @SerializedName("price")
    private double price;

    @SerializedName("available")
    private boolean available;

    @SerializedName("imageUrl")
    private String imageUrl;

    @SerializedName("priority")
    private int priority;

    @SerializedName("extras")
    private List<ExtraItem> extras;

    @SerializedName("flowerType")
    private String flowerType;

    @SerializedName("flowerColor")
    private String flowerColor;

    @SerializedName("bouquetSize")
    private String bouquetSize;

    @SerializedName("storeId")
    private String storeId;

    public Item() { }

    // Getters and Setters...
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getCategoryId() { return categoryId; }
    public void setCategoryId(String categoryId) { this.categoryId = categoryId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }

    public List<ExtraItem> getExtras() { return extras; }
    public void setExtras(List<ExtraItem> extras) { this.extras = extras; }

    public String getFlowerType() { return flowerType; }
    public void setFlowerType(String flowerType) { this.flowerType = flowerType; }

    public String getFlowerColor() { return flowerColor; }
    public void setFlowerColor(String flowerColor) { this.flowerColor = flowerColor; }

    public String getBouquetSize() { return bouquetSize; }
    public void setBouquetSize(String bouquetSize) { this.bouquetSize = bouquetSize; }

    public String getStoreId() { return storeId; }
    public void setStoreId(String storeId) { this.storeId = storeId; }
}
