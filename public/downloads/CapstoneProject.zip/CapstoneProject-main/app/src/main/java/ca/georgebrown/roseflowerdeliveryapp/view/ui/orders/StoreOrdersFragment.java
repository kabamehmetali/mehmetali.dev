package ca.georgebrown.roseflowerdeliveryapp.view.ui.orders;

import android.content.Context;
import android.graphics.Typeface;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.app.DatePickerDialog;
import android.widget.DatePicker;
import android.widget.ImageButton;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.GeoPoint;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.StoreOrdersAdapter;
import ca.georgebrown.roseflowerdeliveryapp.databinding.StoreFragmentOrdersBinding;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseOrderRepository;
import ca.georgebrown.roseflowerdeliveryapp.utils.DriverAssignmentManager;
import ca.georgebrown.roseflowerdeliveryapp.view.ui.orders.StoreOrdersViewModel;

public class StoreOrdersFragment extends Fragment {

    private StoreFragmentOrdersBinding binding;
    private StoreOrdersViewModel ordersViewModel;
    private StoreOrdersAdapter ordersAdapter;
    private String storeId;

    // In‑memory set to track orders that have already been prompted in this session.
    private static Set<String> promptedOrderIds = new HashSet<>();

    // Full list of orders fetched from Firebase (used for filtering).
    private List<Order> allOrders = new ArrayList<>();

    // Sample store location. Replace with your actual store location.
    private final GeoPoint storeLocation = new GeoPoint(43.6532, -79.3832);

    // For filtering orders by date.
    private String selectedDateStr;
    private final SimpleDateFormat displayFormat = new SimpleDateFormat("dd MMM yyyy", Locale.getDefault());

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ordersViewModel = new ViewModelProvider(this).get(StoreOrdersViewModel.class);
        binding = StoreFragmentOrdersBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        storeId = FirebaseAuth.getInstance().getUid();

        // Optionally, clear the prompted set when fragment is created.
        promptedOrderIds.clear();

        // Set up the orders adapter. Passing null initially.
        ordersAdapter = new StoreOrdersAdapter(null, new StoreOrdersAdapter.OnOrderActionListener() {
            @Override
            public void onPrint(Order order) {
                printOrder(order);
            }
            @Override
            public void onComplete(Order order) {
                Log.d("StoreOrdersFragment", "Initiating driver assignment for order: " + order.getId());
                new DriverAssignmentManager(requireContext()).assignDriver(storeId, order, storeLocation);
            }
            @Override
            public void onAccept(Order order) {
                ordersViewModel.updateOrderStatus(storeId, order.getId(), 2, newStatusCallback("ACCEPT"));
            }
            @Override
            public void onReject(Order order) {
                ordersViewModel.updateOrderStatus(storeId, order.getId(), 3, newStatusCallback("REJECT"));
            }
        });
        binding.ordersRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.ordersRecyclerView.setAdapter(ordersAdapter);

        // Set up the search box to filter orders as you type.
        binding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                // No action needed.
            }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                filterOrders(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) {
                // No action needed.
            }
        });

        // --- Set up the Calendar navigation line (with left and right buttons) ---
        // Initialize selected date with today's date.
        Date today = new Date();
        selectedDateStr = displayFormat.format(today);
        binding.tvSelectedDate.setText(selectedDateStr);

        // Set maximum date for DatePickerDialog to today.
        binding.tvSelectedDate.setOnClickListener(v -> {
            Calendar cal = Calendar.getInstance();
            try {
                Date currentDate = displayFormat.parse(selectedDateStr);
                cal.setTime(currentDate);
            } catch (Exception e) {
                e.printStackTrace();
            }
            int year = cal.get(Calendar.YEAR);
            int month = cal.get(Calendar.MONTH);
            int day = cal.get(Calendar.DAY_OF_MONTH);
            DatePickerDialog datePickerDialog = new DatePickerDialog(requireContext(), new DatePickerDialog.OnDateSetListener() {
                @Override
                public void onDateSet(DatePicker view, int selYear, int selMonth, int selDay) {
                    Calendar selectedCal = Calendar.getInstance();
                    selectedCal.set(selYear, selMonth, selDay);
                    selectedDateStr = displayFormat.format(selectedCal.getTime());
                    binding.tvSelectedDate.setText(selectedDateStr);
                    filterOrders(binding.etSearch.getText().toString());
                }
            }, year, month, day);
            // Disable future dates
            datePickerDialog.getDatePicker().setMaxDate(today.getTime());
            datePickerDialog.show();
        });

        // Set up left (previous) and right (next) buttons for date navigation.
        binding.btnPrevDate.setOnClickListener(v -> {
            try {
                Date currentDate = displayFormat.parse(selectedDateStr);
                Calendar cal = Calendar.getInstance();
                cal.setTime(currentDate);
                cal.add(Calendar.DAY_OF_MONTH, -1);
                selectedDateStr = displayFormat.format(cal.getTime());
                binding.tvSelectedDate.setText(selectedDateStr);
                filterOrders(binding.etSearch.getText().toString());
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        binding.btnNextDate.setOnClickListener(v -> {
            try {
                Date currentDate = displayFormat.parse(selectedDateStr);
                Calendar cal = Calendar.getInstance();
                cal.setTime(currentDate);
                // Add one day
                cal.add(Calendar.DAY_OF_MONTH, 1);
                // Only update if the new date is not after today
                if (!cal.getTime().after(today)) {
                    selectedDateStr = displayFormat.format(cal.getTime());
                    binding.tvSelectedDate.setText(selectedDateStr);
                    filterOrders(binding.etSearch.getText().toString());
                }
            } catch (Exception e) {
                e.printStackTrace();
            }
        });

        // Observe live data for orders.
        ordersViewModel.getOrdersLiveData().observe(getViewLifecycleOwner(), new Observer<List<Order>>() {
            @Override
            public void onChanged(List<Order> orders) {
                binding.ordersProgressBar.setVisibility(View.GONE);
                if (orders == null || orders.isEmpty()) {
                    Log.d("StoreOrdersFragment", "No orders available.");
                    // Hide search box and RecyclerView; show no orders layout.
                    binding.cardSearch.setVisibility(View.GONE);
                    binding.ordersRecyclerView.setVisibility(View.GONE);
                    binding.noOrdersLayout.setVisibility(View.VISIBLE);
                    return;
                } else {
                    // Show search box if orders exist.
                    binding.cardSearch.setVisibility(View.VISIBLE);
                }
                Log.d("StoreOrdersFragment", "Fetched " + orders.size() + " orders.");
                // Save the full orders list and apply current filter.
                allOrders = orders;
                filterOrders(binding.etSearch.getText().toString());
                checkForNewOrders(orders);
            }
        });

        ordersViewModel.listenToOrders(storeId);
        return root;
    }

    /**
     * Filters orders based on both the search query and the selected date.
     */
    private void filterOrders(String query) {
        String lowerQuery = query.toLowerCase().trim();
        List<Order> filteredList = new ArrayList<>();

        // First, filter orders that match the selected date and query.
        for (Order order : allOrders) {
            boolean matchesDate = false;
            if (order.getTimestamp() != null) {
                Date date = order.getTimestamp().toDate();
                String orderDateStr = displayFormat.format(date);
                matchesDate = orderDateStr.equals(selectedDateStr);
            }
            String orderId = order.getId() != null ? order.getId().toLowerCase() : "";
            String userName = order.getUserName() != null ? order.getUserName().toLowerCase() : "";
            boolean matchesQuery = orderId.contains(lowerQuery) || userName.contains(lowerQuery);
            if (matchesDate && matchesQuery) {
                filteredList.add(order);
            }
        }

        // If no orders match the current selected date and a query exists, try to find a matching order on another day.
        if (filteredList.isEmpty() && !lowerQuery.isEmpty()) {
            List<Order> fallbackList = new ArrayList<>();
            for (Order order : allOrders) {
                String orderId = order.getId() != null ? order.getId().toLowerCase() : "";
                String userName = order.getUserName() != null ? order.getUserName().toLowerCase() : "";
                if (orderId.contains(lowerQuery) || userName.contains(lowerQuery)) {
                    fallbackList.add(order);
                }
            }
            if (!fallbackList.isEmpty()) {
                // Update the selected date to that of the first matching order.
                Order first = fallbackList.get(0);
                if (first.getTimestamp() != null) {
                    Date date = first.getTimestamp().toDate();
                    selectedDateStr = displayFormat.format(date);
                    binding.tvSelectedDate.setText(selectedDateStr);
                }
                // Re-filter orders using the new selected date.
                filteredList.clear();
                for (Order order : allOrders) {
                    boolean matchesDate = false;
                    if (order.getTimestamp() != null) {
                        Date d = order.getTimestamp().toDate();
                        String orderDateStr = displayFormat.format(d);
                        matchesDate = orderDateStr.equals(selectedDateStr);
                    }
                    String orderId = order.getId() != null ? order.getId().toLowerCase() : "";
                    String userName = order.getUserName() != null ? order.getUserName().toLowerCase() : "";
                    boolean matchesQuery = orderId.contains(lowerQuery) || userName.contains(lowerQuery);
                    if (matchesDate && matchesQuery) {
                        filteredList.add(order);
                    }
                }
            }
        }

        ordersAdapter.updateList(filteredList);

        // Toggle between showing the RecyclerView and the "no orders" layout based on filter results.
        if (filteredList.isEmpty()) {
            binding.ordersRecyclerView.setVisibility(View.GONE);
            binding.noOrdersLayout.setVisibility(View.VISIBLE);
        } else {
            binding.ordersRecyclerView.setVisibility(View.VISIBLE);
            binding.noOrdersLayout.setVisibility(View.GONE);
        }
    }

    /**
     * Checks for new orders (status = 1) that haven't been prompted in this session.
     */
    private void checkForNewOrders(List<Order> orders) {
        for (Order order : orders) {
            if (order.getStatus() == 1 && !promptedOrderIds.contains(order.getId())) {
                promptedOrderIds.add(order.getId());
                Log.d("StoreOrdersFragment", "Prompting new order: " + order.getId());
                // Optionally, show a pop-up for new orders here.
            }
        }
    }

    /**
     * Prints the given order by generating an HTML summary and sending it to the printer.
     */
    private void printOrder(Order order) {
        double subtotal = 0.0;
        if (order.getOrderItems() != null) {
            for (CartItem cartItem : order.getOrderItems()) {
                subtotal += cartItem.getItem().getPrice() * cartItem.getQuantity();
            }
        }
        double tax = subtotal * 0.13;
        double total = subtotal + tax;

        StringBuilder html = new StringBuilder();
        html.append("<html><body style='font-family:sans-serif;'>");
        html.append("<h1>Order ").append(order.getId()).append("</h1>");

        String userName = (order.getUserName() == null || order.getUserName().trim().isEmpty())
                ? "Unknown" : order.getUserName();
        html.append("<p><strong>Placed by:</strong> ").append(userName).append("</p>");

        if (order.getTimestamp() != null) {
            Date date = order.getTimestamp().toDate();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String dateStr = sdf.format(date);
            html.append("<p><strong>Order Time:</strong> ").append(dateStr).append("</p>");
        } else {
            html.append("<p><strong>Order Time:</strong> Not available</p>");
        }

        html.append("<p><strong>Subtotal:</strong> $").append(String.format("%.2f", subtotal)).append("</p>");
        html.append("<p><strong>Tax (13%):</strong> $").append(String.format("%.2f", tax)).append("</p>");
        html.append("<p><strong>Total:</strong> $").append(String.format("%.2f", total)).append("</p>");
        html.append("<p><strong>Status:</strong> ").append(getStatusText(order.getStatus())).append("</p>");

        html.append("<table border='1' style='border-collapse:collapse; width:100%;'>");
        html.append("<tr><th>Item Name</th><th>Description</th><th>Note</th><th>Qty</th><th>Price</th><th>Total</th></tr>");
        if (order.getOrderItems() != null) {
            for (CartItem cartItem : order.getOrderItems()) {
                html.append("<tr>");
                html.append("<td>").append(cartItem.getItem().getName()).append("</td>");
                html.append("<td>").append(cartItem.getItem().getDescription()).append("</td>");
                String note = cartItem.getNote();
                html.append("<td>").append((note == null || note.isEmpty()) ? "None" : note).append("</td>");
                html.append("<td>").append(cartItem.getQuantity()).append("</td>");
                html.append("<td>$").append(String.format("%.2f", cartItem.getItem().getPrice())).append("</td>");
                double itemTotal = cartItem.getItem().getPrice() * cartItem.getQuantity();
                html.append("<td>$").append(String.format("%.2f", itemTotal)).append("</td>");
                html.append("</tr>");
            }
        }
        html.append("</table>");
        html.append("</body></html>");

        WebView webView = new WebView(requireContext());
        webView.loadDataWithBaseURL(null, html.toString(), "text/HTML", "UTF-8", null);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                PrintManager printManager = (PrintManager) requireContext().getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter printAdapter = view.createPrintDocumentAdapter("Order_" + order.getId());
                PrintAttributes printAttributes = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.NA_LETTER)
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build();
                printManager.print("Print Order " + order.getId(), printAdapter, printAttributes);
            }
        });
    }

    /**
     * Converts an order status code into a human-readable text.
     */
    private String getStatusText(int status) {
        switch (status) {
            case 1:
                return "New";
            case 2:
                return "Accepted";
            case 3:
                return "Rejected";
            case 4:
                return "Ready for Pickup";
            case 5:
                return "Driver Accepted";
            case 6:
                return "Driver Rejected";
            case 7:
                return "Cancelled";
            case 8:
                return "Picked Up";
            case 10:
                return "Completed";
            default:
                return "Unknown";
        }
    }

    /**
     * Creates a callback for status updates.
     */
    private FirebaseOrderRepository.StatusUpdateCallback newStatusCallback(String action) {
        return new FirebaseOrderRepository.StatusUpdateCallback() {
            @Override
            public void onStatusUpdated() {
                Log.d("StoreOrdersFragment", "Order " + action + " successful.");
            }
            @Override
            public void onError(Exception e) {
                Log.e("StoreOrdersFragment", "Error " + action + ": " + e.getMessage());
            }
        };
    }
}
