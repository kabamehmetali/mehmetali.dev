package ca.georgebrown.roseflowerdeliveryapp.adapter;

import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.text.Spannable;
import android.text.SpannableString;
import android.text.TextUtils;
import android.text.style.StyleSpan;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.firebase.firestore.FirebaseFirestore;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.HashSet;
import java.util.Set;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;
import ca.georgebrown.roseflowerdeliveryapp.utils.CircleTransform;

public class StoreOrdersAdapter extends RecyclerView.Adapter<StoreOrdersAdapter.OrderViewHolder> {

    private List<Order> orders = new ArrayList<>();
    private OnOrderActionListener listener;
    private final FirebaseFirestore firebaseFirestore;
    private static final String TAG = "StoreOrdersAdapter";

    public interface OnOrderActionListener {
        void onPrint(Order order);
        void onAccept(Order order);
        void onReject(Order order);
        void onComplete(Order order);
    }

    public StoreOrdersAdapter(List<Order> orders, OnOrderActionListener listener) {
        if (orders != null) {
            this.orders = orders;
        }
        this.listener = listener;
        this.firebaseFirestore = FirebaseFirestore.getInstance();
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order_card, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orders.get(position);

        // Set order ID
        holder.tvOrderId.setText("Order ID: " + order.getId());

        // Set user name with fallback
        String userName = !TextUtils.isEmpty(order.getUserName()) ? order.getUserName() : "Unknown";
        holder.tvOrderUserName.setText("Placed by: " + userName);

        // Set order time
        if (order.getTimestamp() != null) {
            Date date = order.getTimestamp().toDate();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            holder.tvOrderTime.setText("Order Time: " + sdf.format(date));
        } else {
            holder.tvOrderTime.setText("Order Time: Not available");
        }

        // Set order status and its text color based on status code
        String statusText = getStatusText(order.getStatus());
        holder.tvOrderStatus.setText("Status: " + statusText);
        holder.tvOrderStatus.setTextColor(getStatusColor(order.getStatus()));

        // Calculate order summary
        double subtotal = 0.0;
        if (order.getOrderItems() != null) {
            for (CartItem cartItem : order.getOrderItems()) {
                subtotal += cartItem.getItem().getPrice() * cartItem.getQuantity();
            }
        }
        double tax = subtotal * 0.13;
        double total = subtotal + tax;
        holder.tvOrderSubtotal.setText("Subtotal: $" + String.format("%.2f", subtotal));
        holder.tvOrderTax.setText("Tax: $" + String.format("%.2f", tax));
        holder.tvOrderTotal.setText("Total: $" + String.format("%.2f", total));

        // Set up nested RecyclerView for order items
        List<CartItem> cartItems = order.getOrderItems() != null ? order.getOrderItems() : new ArrayList<>();
        OrderItemsAdapter itemsAdapter = new OrderItemsAdapter(holder.itemView.getContext(), cartItems);
        holder.recyclerOrderItems.setLayoutManager(new LinearLayoutManager(holder.itemView.getContext()));
        holder.recyclerOrderItems.setAdapter(itemsAdapter);

        // Handle action buttons based on order status
        if (order.getStatus() == 1) {
            holder.btnAcceptOrder.setVisibility(View.VISIBLE);
            holder.btnRejectOrder.setVisibility(View.VISIBLE);
            holder.btnCompleteOrder.setVisibility(View.GONE);
        } else if (order.getStatus() == 2) {
            holder.btnAcceptOrder.setVisibility(View.GONE);
            holder.btnRejectOrder.setVisibility(View.GONE);
            holder.btnCompleteOrder.setVisibility(View.VISIBLE);
        } else {
            holder.btnAcceptOrder.setVisibility(View.GONE);
            holder.btnRejectOrder.setVisibility(View.GONE);
            holder.btnCompleteOrder.setVisibility(View.GONE);
        }

        // Set click listeners for action buttons and print icon
        holder.btnAcceptOrder.setOnClickListener(v -> {
            if (listener != null) {
                listener.onAccept(order);
            }
        });
        holder.btnRejectOrder.setOnClickListener(v -> {
            if (listener != null) {
                listener.onReject(order);
            }
        });
        holder.btnCompleteOrder.setOnClickListener(v -> {
            if (listener != null) {
                listener.onComplete(order);
            }
        });
        holder.ivPrint.setOnClickListener(v -> {
            if (listener != null) {
                listener.onPrint(order);
            }
        });

        // --- DRIVER INFORMATION ---
        if (order.getStatus() <= 3 || order.getStatus() == 10) {
            holder.dividerDriverInfo.setVisibility(View.GONE);
            holder.layoutDriverInfo.setVisibility(View.GONE);
        } else {
            if (TextUtils.isEmpty(order.getAssignedDriverId())
                    || order.getStatus() == 6
                    || order.getStatus() == 7) {

                holder.dividerDriverInfo.setVisibility(View.VISIBLE);
                holder.layoutDriverInfo.setVisibility(View.VISIBLE);
                holder.tvDriverName.setText("Searching for drivers...");
                holder.ivDriverPicture.setVisibility(View.GONE);
            } else {
                holder.dividerDriverInfo.setVisibility(View.VISIBLE);
                holder.layoutDriverInfo.setVisibility(View.VISIBLE);
                holder.ivDriverPicture.setVisibility(View.VISIBLE);
                Log.d(TAG, "Fetching driver info for id: " + order.getAssignedDriverId());
                firebaseFirestore.collection("users")
                        .document(order.getAssignedDriverId())
                        .get()
                        .addOnSuccessListener(documentSnapshot -> {
                            if (documentSnapshot.exists()) {
                                Users driverUser = documentSnapshot.toObject(Users.class);
                                if (driverUser != null) {
                                    Log.d(TAG, "Driver user fetched: " + driverUser.getFirstName() + " " + driverUser.getLastName());
                                    String fName = driverUser.getFirstName();
                                    if (!TextUtils.isEmpty(fName)) {
                                        String[] fParts = fName.split("\\s+");
                                        StringBuilder fBuilder = new StringBuilder();
                                        for (String part : fParts) {
                                            if (!TextUtils.isEmpty(part)) {
                                                fBuilder.append(part.substring(0, 1).toUpperCase())
                                                        .append(part.substring(1).toLowerCase())
                                                        .append(" ");
                                            }
                                        }
                                        fName = fBuilder.toString().trim();
                                    } else {
                                        fName = "";
                                    }
                                    String lName = !TextUtils.isEmpty(driverUser.getLastName()) ? driverUser.getLastName().toUpperCase() : "";
                                    String driverDisplayName = fName + " " + lName;

                                    String driverLabel = "Driver \n";
                                    SpannableString spannable = new SpannableString(driverLabel + driverDisplayName);
                                    spannable.setSpan(new StyleSpan(Typeface.BOLD),
                                            driverLabel.length(),
                                            driverLabel.length() + driverDisplayName.length(),
                                            Spannable.SPAN_EXCLUSIVE_EXCLUSIVE);
                                    holder.tvDriverName.setText(spannable);

                                    if (!TextUtils.isEmpty(driverUser.getImageUrl())) {
                                        Picasso.get()
                                                .load(driverUser.getImageUrl())
                                                .placeholder(R.drawable.pictureselect)
                                                .into(holder.ivDriverPicture);
                                        holder.ivDriverPicture.setOnClickListener(v -> {
                                            View dialogView = LayoutInflater.from(holder.itemView.getContext())
                                                    .inflate(R.layout.dialog_circle_image, null);
                                            ImageView ivCircleImage = dialogView.findViewById(R.id.ivCircleImage);
                                            Picasso.get()
                                                    .load(driverUser.getImageUrl())
                                                    .transform(new CircleTransform())
                                                    .into(ivCircleImage);
                                            ImageView btnCloseImage = dialogView.findViewById(R.id.btnCloseImage);
                                            AlertDialog dialog = new AlertDialog.Builder(holder.itemView.getContext())
                                                    .setView(dialogView)
                                                    .create();
                                            btnCloseImage.setOnClickListener(v1 -> dialog.dismiss());
                                            dialog.show();
                                        });
                                    } else {
                                        holder.ivDriverPicture.setImageResource(R.drawable.pictureselect);
                                    }
                                } else {
                                    holder.dividerDriverInfo.setVisibility(View.GONE);
                                    holder.layoutDriverInfo.setVisibility(View.GONE);
                                }
                            } else {
                                holder.dividerDriverInfo.setVisibility(View.GONE);
                                holder.layoutDriverInfo.setVisibility(View.GONE);
                            }
                        })
                        .addOnFailureListener(e -> {
                            holder.dividerDriverInfo.setVisibility(View.GONE);
                            holder.layoutDriverInfo.setVisibility(View.GONE);
                        });
            }
        }
    }

    @Override
    public int getItemCount() {
        return orders != null ? orders.size() : 0;
    }

    /**
     * Updates the adapter list and notifies changes.
     */
    public void updateList(List<Order> newOrders) {
        if (newOrders == null) {
            this.orders = new ArrayList<>();
        } else {
            this.orders = newOrders;
        }
        notifyDataSetChanged();
    }

    private String getStatusText(int status) {
        switch (status) {
            case 1:
                return "New";
            case 2:
                return "Accepted";
            case 3:
                return "Rejected";
            case 4:
                return "Ready for Pickup";
            case 5:
                return "Driver Accepted";
            case 6:
                return "Driver Rejected";
            case 7:
                return "Cancelled";
            case 8:
                return "Picked Up";
            case 10:
                return "Completed";
            default:
                return "Unknown";
        }
    }

    /**
     * Returns the color based on the order status.
     * Order Placed (status 1) => Purple
     * In Progress (statuses 2, 3, 4, 5, 6, 8) => Blue
     * Completed (status 10) => Green
     * Canceled (status 7) => Red
     */
    private int getStatusColor(int status) {
        switch (status) {
            case 1: // New - Order Placed
                return Color.parseColor("#9C27B0");  // Purple
            case 10: // Completed
                return Color.parseColor("#4CAF50");  // Green
            case 7: // Cancelled
                return Color.parseColor("#F44336");  // Red
            default:
                // For Accepted, Rejected, Ready for Pickup, Driver Accepted, Driver Rejected, Picked Up
                return Color.parseColor("#2196F3");  // Blue
        }
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvOrderUserName, tvOrderTime, tvOrderStatus;
        TextView tvOrderSubtotal, tvOrderTax, tvOrderTotal;
        RecyclerView recyclerOrderItems;
        CardView cardView;
        Button btnAcceptOrder, btnRejectOrder, btnCompleteOrder;
        ImageView ivPrint;
        // Driver info views
        LinearLayout layoutDriverInfo;
        ImageView ivDriverPicture;
        TextView tvDriverName;
        View dividerDriverInfo;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = itemView.findViewById(R.id.itemOrderCard);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvOrderUserName = itemView.findViewById(R.id.tvOrderUserName);
            tvOrderTime = itemView.findViewById(R.id.tvOrderTime);
            tvOrderStatus = itemView.findViewById(R.id.tvOrderStatus);
            tvOrderSubtotal = itemView.findViewById(R.id.tvOrderSubtotal);
            tvOrderTax = itemView.findViewById(R.id.tvOrderTax);
            tvOrderTotal = itemView.findViewById(R.id.tvOrderTotal);
            recyclerOrderItems = itemView.findViewById(R.id.recyclerOrderItems);
            btnAcceptOrder = itemView.findViewById(R.id.btnAcceptOrder);
            btnRejectOrder = itemView.findViewById(R.id.btnRejectOrder);
            btnCompleteOrder = itemView.findViewById(R.id.btnCompleteOrder);
            ivPrint = itemView.findViewById(R.id.ivPrint);
            layoutDriverInfo = itemView.findViewById(R.id.layoutDriverInfo);
            ivDriverPicture = itemView.findViewById(R.id.ivDriverPicture);
            tvDriverName = itemView.findViewById(R.id.tvDriverName);
            dividerDriverInfo = itemView.findViewById(R.id.dividerDriverInfo);
        }
    }
}
