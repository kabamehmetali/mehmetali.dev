package ca.georgebrown.roseflowerdeliveryapp.view.ui.orders;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class DriverOrdersViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public DriverOrdersViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is home fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}