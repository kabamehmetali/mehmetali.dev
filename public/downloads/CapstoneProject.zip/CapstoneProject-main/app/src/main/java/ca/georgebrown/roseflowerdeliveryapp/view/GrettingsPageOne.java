package ca.georgebrown.roseflowerdeliveryapp.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ca.georgebrown.roseflowerdeliveryapp.R;

public class GrettingsPageOne extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_grettings_page_one);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
        sharedPreferences = this.getSharedPreferences("grettings",MODE_PRIVATE);
    }

    public void nextOne(View view){
        sharedPreferences.edit().putBoolean("grettingsOne",false).apply();
        Intent intent = new Intent(GrettingsPageOne.this,GrettingsPageTwo.class);
        startActivity(intent);

    }
    public void skip(View view){
        sharedPreferences.edit().putBoolean("grettingsOne",false).apply();
        sharedPreferences.edit().putBoolean("grettingsTwo",false).apply();
        sharedPreferences.edit().putBoolean("grettingsThree",false).apply();
        Intent intent = new Intent(this,LoginPage.class);
        startActivity(intent);
    }
}
