package ca.georgebrown.roseflowerdeliveryapp.model;

import com.google.firebase.Timestamp;
import java.io.Serializable;
import java.util.List;

public class Order implements Serializable {

    private String id;               // Firestore document ID
    private String userId;           // ID of the user who placed the order
    private String userName;         // Customer's name
    private List<CartItem> orderItems;
    private int status;              // e.g., 5 = In Progress, 7 = Cancelled, 8 = Picked Up, 10 = Completed
    private Timestamp timestamp;     // When order was created

    // Driver assignment fields
    private String assignedDriverId;
    private Timestamp pickupTimestamp;

    // Delivery location
    private Location deliveryLocation;

    // Price fields
    private double subtotal;
    private double deliveryFee;
    private double tax;
    private double total;

    // Store fields
    private String storeName;
    private String storeAddress;
    private double storeLatitude;
    private double storeLongitude;
    private String storeLogoUrl;
    private String storeId;        // New field for store document ID

    // -------------------------------
    // New fields for driver orders display
    // -------------------------------
    private Double driverFee;         // Calculated driver fee (e.g., base fee + per km rate)
    private Double distance;          // Calculated route distance in km
    private String orderPlacedDate;   // Formatted order placed date/time string
    private String routePolyline;     // Encoded polyline representing the route
    private String deliveryAddress;   // Customer's delivery address (fallback if deliveryLocation is missing)

    // Constructors
    public Order() {
    }

    public Order(String userId, String userName, List<CartItem> orderItems, int status, Timestamp timestamp) {
        this.userId = userId;
        this.userName = userName;
        this.orderItems = orderItems;
        this.status = status;
        this.timestamp = timestamp;
    }

    // Getters and Setters

    // Basic fields
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public List<CartItem> getOrderItems() {
        return orderItems;
    }
    public void setOrderItems(List<CartItem> orderItems) {
        this.orderItems = orderItems;
    }
    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
    }
    public Timestamp getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    // Driver assignment fields
    public String getAssignedDriverId() {
        return assignedDriverId;
    }
    public void setAssignedDriverId(String assignedDriverId) {
        this.assignedDriverId = assignedDriverId;
    }
    public Timestamp getPickupTimestamp() {
        return pickupTimestamp;
    }
    public void setPickupTimestamp(Timestamp pickupTimestamp) {
        this.pickupTimestamp = pickupTimestamp;
    }

    // Delivery location
    public Location getDeliveryLocation() {
        return deliveryLocation;
    }
    public void setDeliveryLocation(Location deliveryLocation) {
        this.deliveryLocation = deliveryLocation;
    }

    // Price fields
    public double getSubtotal() {
        return subtotal;
    }
    public void setSubtotal(double subtotal) {
        this.subtotal = subtotal;
    }
    public double getDeliveryFee() {
        return deliveryFee;
    }
    public void setDeliveryFee(double deliveryFee) {
        this.deliveryFee = deliveryFee;
    }
    public double getTax() {
        return tax;
    }
    public void setTax(double tax) {
        this.tax = tax;
    }
    public double getTotal() {
        return total;
    }
    public void setTotal(double total) {
        this.total = total;
    }

    // Store fields
    public String getStoreName() {
        return storeName;
    }
    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }
    public String getStoreAddress() {
        return storeAddress;
    }
    public void setStoreAddress(String storeAddress) {
        this.storeAddress = storeAddress;
    }
    public double getStoreLatitude() {
        return storeLatitude;
    }
    public void setStoreLatitude(double storeLatitude) {
        this.storeLatitude = storeLatitude;
    }
    public double getStoreLongitude() {
        return storeLongitude;
    }
    public void setStoreLongitude(double storeLongitude) {
        this.storeLongitude = storeLongitude;
    }
    public String getStoreLogoUrl() {
        return storeLogoUrl;
    }
    public void setStoreLogoUrl(String storeLogoUrl) {
        this.storeLogoUrl = storeLogoUrl;
    }
    public String getStoreId() {
        return storeId;
    }
    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    // New fields for driver orders display
    public Double getDriverFee() {
        return driverFee;
    }
    public void setDriverFee(Double driverFee) {
        this.driverFee = driverFee;
    }
    public Double getDistance() {
        return distance;
    }
    public void setDistance(Double distance) {
        this.distance = distance;
    }
    public String getOrderPlacedDate() {
        return orderPlacedDate;
    }
    public void setOrderPlacedDate(String orderPlacedDate) {
        this.orderPlacedDate = orderPlacedDate;
    }
    public String getRoutePolyline() {
        return routePolyline;
    }
    public void setRoutePolyline(String routePolyline) {
        this.routePolyline = routePolyline;
    }
    public String getDeliveryAddress() {
        return deliveryAddress;
    }
    public void setDeliveryAddress(String deliveryAddress) {
        this.deliveryAddress = deliveryAddress;
    }
}
