package ca.georgebrown.roseflowerdeliveryapp.dialog;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import com.google.android.gms.maps.*;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.LatLngBounds;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.PolylineOptions;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class TransactionDetailsDialog extends Dialog implements OnMapReadyCallback {

    private Order order;
    private MapView mapView;
    private GoogleMap googleMap;

    public TransactionDetailsDialog(Context context, Order order) {
        super(context);
        this.order = order;
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.dialog_transaction_details);

        TextView tvOrderId = findViewById(R.id.tvOrderId);
        TextView tvCustomerName = findViewById(R.id.tvCustomerName);
        TextView tvStoreName = findViewById(R.id.tvStoreName);
        TextView tvPickedUpLocation = findViewById(R.id.tvPickedUpLocation);
        TextView tvDeliveredLocation = findViewById(R.id.tvDeliveredLocation);
        TextView tvDistance = findViewById(R.id.tvDistance);
        TextView tvEarned = findViewById(R.id.tvEarned);

        mapView = findViewById(R.id.mapView);
        Button btnClose = findViewById(R.id.btnClose);

        // Set header details.
        tvOrderId.setText("Order #" + order.getId());
        tvCustomerName.setText("Customer: " + order.getUserName());
        tvStoreName.setText("Store: " + order.getStoreName());
        tvPickedUpLocation.setText(order.getStoreAddress());
        String delivered = order.getDeliveryAddress() != null ? order.getDeliveryAddress() :
                (order.getDeliveryLocation() != null ? order.getDeliveryLocation().getFormattedAddress() : "N/A");
        tvDeliveredLocation.setText(delivered);

        double distance = (order.getDistance() != null) ? order.getDistance() : 0;
        tvDistance.setText(String.format(Locale.getDefault(), "Distance: %.2f km", distance));
        double earned = (order.getDriverFee() != null) ? order.getDriverFee() : 0;
        tvEarned.setText(String.format(Locale.getDefault(), "Earned: $%.2f", earned));


        // Initialize the map.
        mapView.onCreate(savedInstanceState);
        mapView.onResume();
        try {
            MapsInitializer.initialize(getContext());
        } catch (Exception e) {
            e.printStackTrace();
        }
        mapView.getMapAsync(this);

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                dismiss();
            }
        });
    }

    @Override
    public void onMapReady(GoogleMap map) {
        googleMap = map;

        LatLng storeLatLng = null;
        LatLng deliveryLatLng = null;

        // Add marker for picked-up location (store).
        if (order.getStoreLatitude() != 0 && order.getStoreLongitude() != 0) {
            storeLatLng = new LatLng(order.getStoreLatitude(), order.getStoreLongitude());
            googleMap.addMarker(new MarkerOptions().position(storeLatLng).title("Picked Up Location"));
        }

        // Add marker for delivered location.
        if (order.getDeliveryLocation() != null) {
            deliveryLatLng = new LatLng(order.getDeliveryLocation().getLatitude(), order.getDeliveryLocation().getLongitude());
            googleMap.addMarker(new MarkerOptions().position(deliveryLatLng).title("Delivered Location"));
        }

        // Set camera to show both markers with a nice zoom.
        if (storeLatLng != null && deliveryLatLng != null) {
            LatLngBounds.Builder builder = new LatLngBounds.Builder();
            builder.include(storeLatLng);
            builder.include(deliveryLatLng);
            LatLngBounds bounds = builder.build();
            int padding = 100; // pixels of padding around the bounds
            googleMap.moveCamera(CameraUpdateFactory.newLatLngBounds(bounds, padding));
        } else if (storeLatLng != null) {
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(storeLatLng, 14));
        } else if (deliveryLatLng != null) {
            googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(deliveryLatLng, 14));
        }

        // Draw route between store and destination if available.
        if (order.getRoutePolyline() != null && !order.getRoutePolyline().isEmpty()) {
            List<LatLng> routePoints = decodePoly(order.getRoutePolyline());
            if (!routePoints.isEmpty()) {
                googleMap.addPolyline(new PolylineOptions()
                        .addAll(routePoints)
                        .width(10)
                        .color(Color.BLUE));
            }
        }
    }

    /**
     * Decodes an encoded polyline string into a list of LatLng points.
     */
    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new ArrayList<>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;
        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;
            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;
            LatLng point = new LatLng(lat / 1E5, lng / 1E5);
            poly.add(point);
        }
        return poly;
    }

    @Override
    public void dismiss() {
        if (mapView != null) {
            mapView.onDestroy();
        }
        super.dismiss();
    }
}
