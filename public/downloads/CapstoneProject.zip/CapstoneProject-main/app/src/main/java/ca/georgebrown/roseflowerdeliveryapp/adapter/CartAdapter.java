package ca.georgebrown.roseflowerdeliveryapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.util.List;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;
import ca.georgebrown.roseflowerdeliveryapp.utils.CartManager;

public class CartAdapter extends RecyclerView.Adapter<CartAdapter.CartViewHolder> {

    private List<CartItem> cartItems;
    private Context context;
    private OnCartChangedListener cartChangedListener;

    public interface OnCartChangedListener {
        void onCartChanged(List<CartItem> updatedCartItems);
    }

    public void setOnCartChangedListener(OnCartChangedListener listener) {
        this.cartChangedListener = listener;
    }

    public CartAdapter(List<CartItem> cartItems, Context context) {
        this.cartItems = cartItems;
        this.context = context;
    }

    @NonNull
    @Override
    public CartViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_cart, parent, false);
        return new CartViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull CartViewHolder holder, int position) {
        CartItem cartItem = cartItems.get(position);
        Item item = cartItem.getItem();

        holder.tvItemName.setText(item.getName());
        holder.tvCartItemQuantity.setText(String.valueOf(cartItem.getQuantity()));
        if (cartItem.getNote() != null && !cartItem.getNote().isEmpty()) {
            holder.tvNote.setText("Note: " + cartItem.getNote());
        } else {
            holder.tvNote.setText("Note: None");
        }
        double totalPrice = item.getPrice() * cartItem.getQuantity();
        holder.tvCartItemPrice.setText(String.format("Total: $%.2f", totalPrice));

        if (item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
            Picasso.get().load(item.getImageUrl()).into(holder.ivItemImage);
        } else {
            holder.ivItemImage.setImageResource(R.drawable.pictureselect);
        }

        holder.btnMinus.setOnClickListener(v -> {
            int qty = cartItem.getQuantity();
            if (qty > 1) {
                qty--;
                cartItem.setQuantity(qty);
                holder.tvCartItemQuantity.setText(String.valueOf(qty));
                double updatedPrice = item.getPrice() * qty;
                holder.tvCartItemPrice.setText(String.format("Total: $%.2f", updatedPrice));
            } else {
                int pos = holder.getAdapterPosition();
                cartItems.remove(pos);
                notifyItemRemoved(pos);
                notifyItemRangeChanged(pos, cartItems.size());
            }
            CartManager.getInstance(context).saveCartItems(cartItems);
            if (cartChangedListener != null) {
                cartChangedListener.onCartChanged(cartItems);
            }
        });
        holder.btnPlus.setOnClickListener(v -> {
            int qty = cartItem.getQuantity();
            qty++;
            cartItem.setQuantity(qty);
            holder.tvCartItemQuantity.setText(String.valueOf(qty));
            double updatedPrice = item.getPrice() * qty;
            holder.tvCartItemPrice.setText(String.format("Total: $%.2f", updatedPrice));
            CartManager.getInstance(context).saveCartItems(cartItems);
            if (cartChangedListener != null) {
                cartChangedListener.onCartChanged(cartItems);
            }
        });
        holder.btnRemove.setOnClickListener(v -> {
            int pos = holder.getAdapterPosition();
            cartItems.remove(pos);
            notifyItemRemoved(pos);
            notifyItemRangeChanged(pos, cartItems.size());
            CartManager.getInstance(context).saveCartItems(cartItems);
            if (cartChangedListener != null) {
                cartChangedListener.onCartChanged(cartItems);
            }
        });
    }

    @Override
    public int getItemCount() {
        return cartItems.size();
    }

    public static class CartViewHolder extends RecyclerView.ViewHolder {
        TextView tvItemName;
        TextView tvCartItemQuantity;
        TextView tvNote;
        TextView tvCartItemPrice;
        ImageView ivItemImage;
        Button btnMinus, btnPlus, btnRemove;

        public CartViewHolder(@NonNull View itemView) {
            super(itemView);
            tvItemName = itemView.findViewById(R.id.tvCartItemName);
            tvCartItemQuantity = itemView.findViewById(R.id.tvCartItemQuantity);
            tvNote = itemView.findViewById(R.id.tvCartItemNote);
            tvCartItemPrice = itemView.findViewById(R.id.tvCartItemPrice);
            ivItemImage = itemView.findViewById(R.id.ivCartItemImage);
            btnMinus = itemView.findViewById(R.id.btnMinus);
            btnPlus = itemView.findViewById(R.id.btnPlus);
            btnRemove = itemView.findViewById(R.id.btnRemove);
        }
    }
}
