package ca.georgebrown.roseflowerdeliveryapp.model;

import com.google.gson.annotations.SerializedName;

public class ExtraItem {

    @SerializedName("id")
    private String id;

    /**
     * The itemId to which this extra belongs
     * (if storing extras in a top-level collection).
     */
    @SerializedName("itemId")
    private String itemId;

    @SerializedName("name")
    private String name;

    @SerializedName("price")
    private double price;

    @SerializedName("available")
    private boolean available;

    @SerializedName("imageUrl")
    private String imageUrl;

    // Empty constructor
    public ExtraItem() {
    }

    // Full constructor
    public ExtraItem(String id, String itemId, String name, double price, boolean available, String imageUrl) {
        this.id = id;
        this.itemId = itemId;
        this.name = name;
        this.price = price;
        this.available = available;
        this.imageUrl = imageUrl;
    }

    // Getters & Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getItemId() { return itemId; }
    public void setItemId(String itemId) { this.itemId = itemId; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public double getPrice() { return price; }
    public void setPrice(double price) { this.price = price; }

    public boolean isAvailable() { return available; }
    public void setAvailable(boolean available) { this.available = available; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }
}
