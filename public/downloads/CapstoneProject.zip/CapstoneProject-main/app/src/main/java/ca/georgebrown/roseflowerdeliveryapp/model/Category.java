package ca.georgebrown.roseflowerdeliveryapp.model;

import com.google.gson.annotations.SerializedName;
import java.util.List;

public class Category {

    @SerializedName("id")
    private String id;

    @SerializedName("name")
    private String name;

    @SerializedName("description")
    private String description;

    // Used to order categories
    @SerializedName("priority")
    private int priority;

    // New field to tie this category to a store/user
    @SerializedName("userId")
    private String userId;

    // Not stored directly in Firestore; items are retrieved as a subcollection.
    private List<Item> items;

    public Category() { }

    public Category(String id, String name, String description, int priority, List<Item> items) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.priority = priority;
        this.items = items;
    }

    // Getters and Setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getName() { return name; }
    public void setName(String name) { this.name = name; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public int getPriority() { return priority; }
    public void setPriority(int priority) { this.priority = priority; }

    public String getUserId() { return userId; }
    public void setUserId(String userId) { this.userId = userId; }

    public List<Item> getItems() { return items; }
    public void setItems(List<Item> items) { this.items = items; }
}
