package ca.georgebrown.roseflowerdeliveryapp.view.ui.profile;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.databinding.DriverFragmentProfileBinding;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;
import ca.georgebrown.roseflowerdeliveryapp.utils.CircleTransform;
import ca.georgebrown.roseflowerdeliveryapp.view.LoginPage;

public class DriverProfileFragment extends Fragment {

    private DriverFragmentProfileBinding binding;

    // Firebase
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private StorageReference storageRef;

    // Current user ID
    private String currentUserId;

    // Permission launcher for reading external storage or images
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(), isGranted -> {
                if (isGranted) {
                    pickImageFromGallery();
                } else {
                    Toast.makeText(requireContext(), "Permission denied.", Toast.LENGTH_SHORT).show();
                }
            });

    // ActivityResultLauncher for picking an image from the gallery
    private final ActivityResultLauncher<String> galleryLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(),
                    new ActivityResultCallback<Uri>() {
                        @Override
                        public void onActivityResult(Uri result) {
                            if (result != null) {
                                uploadImageToFirebase(result);
                            }
                        }
                    });

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {

        // ViewModel (not heavily used here, but available if needed)
        DriverProfileViewModel driverProfileViewModel =
                new ViewModelProvider(this).get(DriverProfileViewModel.class);

        // Inflate the layout using View Binding
        binding = DriverFragmentProfileBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Initialize Firebase
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storageRef = FirebaseStorage.getInstance().getReference();

        // Get current user ID if logged in
        if (auth.getCurrentUser() != null) {
            currentUserId = auth.getCurrentUser().getUid();
        }

        // Load driver data from Firestore
        loadDriverData();

        // When user taps on driver profile image, allow them to update
        binding.driverProfileImage.setOnClickListener(v -> {
            // Choose correct permission for Android 13+ or older
            String permission;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permission = Manifest.permission.READ_MEDIA_IMAGES;
            } else {
                permission = Manifest.permission.READ_EXTERNAL_STORAGE;
            }

            // Check if permission is granted
            if (ContextCompat.checkSelfPermission(requireContext(), permission)
                    == PackageManager.PERMISSION_GRANTED) {
                pickImageFromGallery();
            } else {
                // Request permission
                requestPermissionLauncher.launch(permission);
            }
        });

        // Logout button
        binding.storeLogoutBtn.setOnClickListener(this::logoutDriver);

        return root;
    }

    /**
     * Loads the driver's data (name, phone, address, image) from Firestore.
     */
    private void loadDriverData() {
        if (currentUserId == null) return;



        db.collection("users")
                .document(currentUserId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        Users user = documentSnapshot.toObject(Users.class);
                        if (user != null) {
                            // 1) Set driver full name (first + last)
                            String fullName = user.getFirstName() + " " + user.getLastName();
                            binding.driverNameView.setText(fullName);

                            // 2) Set driver address
                            if (user.getAddress() != null
                                    && user.getAddress().getFormattedAddress() != null) {
                                binding.driverHomeAdressView.setText(user.getAddress().getFormattedAddress());
                            } else {
                                binding.driverHomeAdressView.setText("No address found");
                            }


                            // 3) Set phone number
                            if (user.getPhoneNumber() != null) {
                                binding.DriverPhoneNumberView.setText(user.getPhoneNumber());
                            }

                            // 4) Load and round driver profile image
                            if (user.getImageUrl() != null && !user.getImageUrl().isEmpty()) {
                                Picasso.get()
                                        .load(user.getImageUrl())
                                        .placeholder(R.drawable.emptycircle) // Show while loading
                                        .error(R.drawable.emptycircle)       // Default if fails
                                        .transform(new CircleTransform())    // Apply circular transformation
                                        .into(binding.driverProfileImage);
                            } else {
                                binding.driverProfileImage.setImageResource(R.drawable.emptycircle);
                            }
                        }
                    }
                })

                .addOnFailureListener(e ->
                        Toast.makeText(requireContext(), "Failed to load driver data", Toast.LENGTH_SHORT).show()
                );

    }

    /**
     * Opens the gallery to select an image.
     */
    private void pickImageFromGallery() {
        // "image/*" ensures the user can only pick image files
        galleryLauncher.launch("image/*");
    }

    /**
     * Upload the selected image to Firebase Storage and update Firestore with the new URL.
     */
    private void uploadImageToFirebase(Uri imageUri) {
        if (currentUserId == null) return;

        // Reference: e.g., "driverImages/<UID>.jpg"
        StorageReference userImageRef = storageRef.child("driver_images/" + currentUserId + ".jpg");

        // Start the upload
        userImageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> {
                    // Once uploaded, get the download URL
                    userImageRef.getDownloadUrl().addOnSuccessListener(downloadUri -> {
                        // Update Firestore user document with new image URL
                        db.collection("users")
                                .document(currentUserId)
                                .update("imageUrl", downloadUri.toString())
                                .addOnSuccessListener(unused -> {
                                    // Refresh the UI with the new image
                                    Picasso.get().load(downloadUri).into(binding.driverProfileImage);
                                    Toast.makeText(requireContext(),
                                            "Profile image updated",
                                            Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e ->
                                        Toast.makeText(requireContext(),
                                                "Failed to update Firestore",
                                                Toast.LENGTH_SHORT).show()
                                );

                    });

                })
                .addOnFailureListener(e ->
                        Toast.makeText(requireContext(), "Image upload failed",
                                Toast.LENGTH_SHORT).show()
                );
                userImageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> {
                    userImageRef.getDownloadUrl().addOnSuccessListener(downloadUri -> {
                        // old file is overwritten automatically
                        // Update Firestore with the new imageUrl
                        db.collection("users")
                                .document(currentUserId)
                                .update("imageUrl", downloadUri.toString())
                                .addOnSuccessListener(unused -> {
                                    // Refresh your UI
                                });
                    });
                });

    }

    /**
     * Logs out the driver and returns to LoginPage.
     */
    private void logoutDriver(View view) {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(getContext(), LoginPage.class);
        // Clear activity stack if you want to prevent going back
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
