package ca.georgebrown.roseflowerdeliveryapp.adapter;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import java.util.List;
import java.util.Locale;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class StoreTransactionAdapter extends RecyclerView.Adapter<StoreTransactionAdapter.TransactionViewHolder> {

    private List<Order> orders;
    private OnTransactionClickListener listener;

    public interface OnTransactionClickListener {
        void onTransactionClick(Order order);
    }

    public StoreTransactionAdapter(List<Order> orders) {
        this.orders = orders;
    }

    public void updateList(List<Order> newOrders) {
        this.orders = newOrders;
        notifyDataSetChanged();
    }

    public void setOnTransactionClickListener(OnTransactionClickListener listener) {
        this.listener = listener;
    }

    @NonNull
    @Override
    public TransactionViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_store_order, parent, false);
        return new TransactionViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull TransactionViewHolder holder, int position) {
        Order order = orders.get(position);
        holder.tvOrderId.setText("Order #" + order.getId());

        // If the order is completed, display gross and total values.
        if (order.getStatus() == 10) {
            double subtotal = 0;
            if (order.getOrderItems() != null) {
                for (int i = 0; i < order.getOrderItems().size(); i++) {
                    double price = order.getOrderItems().get(i).getItem().getPrice();
                    int quantity = order.getOrderItems().get(i).getQuantity();
                    subtotal += price * quantity;
                }
            }
            double tax = subtotal * 0.13;
            double total = subtotal + tax;
            holder.tvGrossValue.setText(String.format(Locale.getDefault(), "$%.2f", subtotal));
            holder.tvTotalValue.setText(String.format(Locale.getDefault(), "$%.2f", total));
            // Show the earnings container and hide the in-progress message.
            holder.earningsContainer.setVisibility(View.VISIBLE);
            holder.tvInProgress.setVisibility(View.GONE);
        } else {
            // For orders not yet completed, show one in-progress message.
            holder.earningsContainer.setVisibility(View.GONE);
            holder.tvInProgress.setVisibility(View.VISIBLE);
        }

        holder.itemView.setOnClickListener(v -> {
            if (listener != null) {
                listener.onTransactionClick(order);
            }
        });
    }

    @Override
    public int getItemCount() {
        return (orders != null) ? orders.size() : 0;
    }

    static class TransactionViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvGrossValue, tvTotalValue, tvInProgress;
        LinearLayout earningsContainer;

        public TransactionViewHolder(@NonNull View itemView) {
            super(itemView);
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvGrossValue = itemView.findViewById(R.id.tvGrossValue);
            tvTotalValue = itemView.findViewById(R.id.tvTotalValue);
            tvInProgress = itemView.findViewById(R.id.tvInProgress);
            earningsContainer = itemView.findViewById(R.id.earningsContainer);
        }
    }
}
