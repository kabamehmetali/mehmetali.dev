package ca.georgebrown.roseflowerdeliveryapp.view.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.model.Category;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseMenuRepository;

public class ClientStoreViewModel extends ViewModel {

    private final MutableLiveData<List<Category>> categoriesLiveData = new MutableLiveData<>();
    private final FirebaseMenuRepository menuRepository;

    public ClientStoreViewModel() {
        menuRepository = new FirebaseMenuRepository();
    }

    public LiveData<List<Category>> getCategoriesLiveData() {
        return categoriesLiveData;
    }

    /**
     * Loads the menu for a given storeId.
     * Every Item loaded from Firestore is checked—if its storeId is missing, it is set to the provided storeId.
     */
    public void loadMenu(String storeId) {
        menuRepository.getMenu(storeId, new FirebaseMenuRepository.RepositoryCallback<List<Category>>() {
            @Override
            public void onSuccess(List<Category> result) {
                // Ensure every Item has its storeId set.
                for (Category cat : result) {
                    if (cat.getItems() != null) {
                        for (Item item : cat.getItems()) {
                            if (item.getStoreId() == null || item.getStoreId().isEmpty()) {
                                item.setStoreId(storeId);
                            }
                        }
                    }
                }
                categoriesLiveData.postValue(result);
            }
            @Override
            public void onFailure(Exception e) {
                categoriesLiveData.postValue(null);
            }
        });
    }
}
