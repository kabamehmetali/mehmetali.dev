package ca.georgebrown.roseflowerdeliveryapp.view.ui.dashboard;

import android.Manifest;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.CompoundButton;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;

import java.util.HashMap;
import java.util.Map;

import ca.georgebrown.roseflowerdeliveryapp.databinding.DriverFragmentDashboardBinding;
import ca.georgebrown.roseflowerdeliveryapp.utils.DriverLocationManager;

public class DriverDashboardFragment extends Fragment {

    private DriverFragmentDashboardBinding binding;
    private FirebaseFirestore firestore;
    private String driverId;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container, Bundle savedInstanceState) {
        binding = DriverFragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Initialize Firestore and driver ID.
        firestore = FirebaseFirestore.getInstance();
        driverId = FirebaseAuth.getInstance().getUid();

        // Set texts for title and description.
        binding.tvTitle.setText("Driver Dashboard");
        binding.tvDescription.setText("Toggle the switch below to indicate if you are accepting orders.");

        // Ensure the toggle is off when the fragment is created.
        binding.switchAcceptingOrders.setChecked(false);
        // Explicitly stop any running location updates.
        DriverLocationManager.getInstance(requireContext()).stopLocationUpdates();

        // Set the location update error listener.
        DriverLocationManager.getInstance(requireContext())
                .setLocationUpdateListener(errorMessage -> requireActivity().runOnUiThread(() -> {
                    binding.switchAcceptingOrders.setChecked(false);
                    Toast.makeText(getContext(), "Location update failed: " + errorMessage, Toast.LENGTH_LONG).show();
                }));

        // Listen to switch changes.
        binding.switchAcceptingOrders.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if (isChecked) {
                    if (!hasLocationPermissions()) {
                        Toast.makeText(getContext(), "Location permission is required.", Toast.LENGTH_SHORT).show();
                        binding.switchAcceptingOrders.setChecked(false);
                    } else {
                        // Update Firestore: acceptingOrders = 1.
                        updateAcceptingOrdersStatus(true);
                        // Start live location updates.
                        DriverLocationManager.getInstance(getContext()).startLocationUpdates();
                    }
                } else {
                    // Update Firestore: acceptingOrders = 0.
                    updateAcceptingOrdersStatus(false);
                    // Stop live location updates.
                    DriverLocationManager.getInstance(getContext()).stopLocationUpdates();
                }
            }
        });

        return root;
    }

    @Override
    public void onResume() {
        super.onResume();
        // On resume, if the toggle is off, ensure location updates are stopped.
        if (!binding.switchAcceptingOrders.isChecked()) {
            DriverLocationManager.getInstance(requireContext()).stopLocationUpdates();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        // Stop location updates when the fragment is paused.
        DriverLocationManager.getInstance(requireContext()).stopLocationUpdates();
    }

    /**
     * Checks if location permissions are granted.
     */
    private boolean hasLocationPermissions() {
        return ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_FINE_LOCATION)
                == PackageManager.PERMISSION_GRANTED ||
                ContextCompat.checkSelfPermission(requireContext(), Manifest.permission.ACCESS_COARSE_LOCATION)
                        == PackageManager.PERMISSION_GRANTED;
    }

    /**
     * Updates the driver's Firestore document with the accepting orders status.
     * Stores 1 if accepting, 0 if not.
     */
    private void updateAcceptingOrdersStatus(boolean accepting) {
        if (driverId == null) {
            Toast.makeText(getContext(), "Driver ID is null.", Toast.LENGTH_SHORT).show();
            return;
        }
        Map<String, Object> statusMap = new HashMap<>();
        statusMap.put("acceptingOrders", accepting ? 1 : 0);
        firestore.collection("drivers").document(driverId)
                .set(statusMap, SetOptions.merge())
                .addOnSuccessListener(aVoid ->
                        Toast.makeText(getContext(), "Status updated to " + (accepting ? "Accepting Orders" : "Not Accepting Orders"), Toast.LENGTH_SHORT).show()
                )
                .addOnFailureListener(e ->
                        Toast.makeText(getContext(), "Failed to update status: " + e.getMessage(), Toast.LENGTH_SHORT).show()
                );
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
