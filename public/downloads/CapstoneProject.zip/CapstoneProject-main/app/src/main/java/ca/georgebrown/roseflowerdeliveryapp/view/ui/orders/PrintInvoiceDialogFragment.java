package ca.georgebrown.roseflowerdeliveryapp.view.ui.orders;

import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;

import java.text.SimpleDateFormat;
import java.util.Locale;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class PrintInvoiceDialogFragment extends DialogFragment {

    private static final String ARG_ORDER = "arg_order";
    private Order order;

    public static PrintInvoiceDialogFragment newInstance(Order order) {
        PrintInvoiceDialogFragment fragment = new PrintInvoiceDialogFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_ORDER, order);
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            order = (Order) getArguments().getSerializable(ARG_ORDER);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(@Nullable Bundle savedInstanceState) {
        return super.onCreateDialog(savedInstanceState);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.print_invoice_dialog, container, false);

        TextView tvInvoiceTitle = view.findViewById(R.id.tvInvoiceTitle);
        TextView tvInvoiceOrderId = view.findViewById(R.id.tvInvoiceOrderId);
        TextView tvInvoiceOrderTime = view.findViewById(R.id.tvInvoiceOrderTime);
        TextView tvInvoiceStoreName = view.findViewById(R.id.tvInvoiceStoreName);
        TextView tvInvoiceStoreAddress = view.findViewById(R.id.tvInvoiceStoreAddress);
        TextView tvInvoiceStatus = view.findViewById(R.id.tvInvoiceStatus);
        TextView tvInvoiceItems = view.findViewById(R.id.tvInvoiceItems);
        TextView tvInvoiceSubtotal = view.findViewById(R.id.tvInvoiceSubtotal);
        TextView tvInvoiceDeliveryFee = view.findViewById(R.id.tvInvoiceDeliveryFee);
        TextView tvInvoiceTax = view.findViewById(R.id.tvInvoiceTax);
        TextView tvInvoiceTotal = view.findViewById(R.id.tvInvoiceTotal);
        ImageButton btnPrint = view.findViewById(R.id.btnPrintInvoice);
        ImageButton btnClose = view.findViewById(R.id.btnCloseInvoice);

        tvInvoiceTitle.setText("Invoice Details");

        if (order != null) {
            tvInvoiceOrderId.setText("Order ID: " + order.getId());
            if (order.getTimestamp() != null) {
                SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
                String timeStr = sdf.format(order.getTimestamp().toDate());
                tvInvoiceOrderTime.setText("Order Time: " + timeStr);
            } else {
                tvInvoiceOrderTime.setText("Order Time: N/A");
            }
            // Store details
            String storeName = (!TextUtils.isEmpty(order.getStoreName())) ? order.getStoreName() : "N/A";
            String storeAddress = (!TextUtils.isEmpty(order.getStoreAddress())) ? order.getStoreAddress() : "N/A";
            tvInvoiceStoreName.setText("Store: " + storeName);
            tvInvoiceStoreAddress.setText("Address: " + storeAddress);

            tvInvoiceStatus.setText("Status: " + getInvoiceStatus(order.getStatus()));

            // Build string for ordered items.
            if (order.getOrderItems() != null && !order.getOrderItems().isEmpty()) {
                StringBuilder itemsBuilder = new StringBuilder();
                for (CartItem item : order.getOrderItems()) {
                    itemsBuilder.append(item.getItem().getName())
                            .append(" x").append(item.getQuantity());
                    if (!TextUtils.isEmpty(item.getNote())) {
                        itemsBuilder.append(" (").append(item.getNote()).append(")");
                    }
                    itemsBuilder.append("\n");
                }
                tvInvoiceItems.setText(itemsBuilder.toString());
            } else {
                tvInvoiceItems.setText("No items.");
            }
            tvInvoiceSubtotal.setText(String.format(Locale.getDefault(), "Subtotal: $%.2f", order.getSubtotal()));
            tvInvoiceDeliveryFee.setText(String.format(Locale.getDefault(), "Delivery Fee: $%.2f", order.getDeliveryFee()));
            tvInvoiceTax.setText(String.format(Locale.getDefault(), "Tax: $%.2f", order.getTax()));
            tvInvoiceTotal.setText(String.format(Locale.getDefault(), "Total: $%.2f", order.getTotal()));
        }

        btnPrint.setOnClickListener(v -> {
            Toast.makeText(getContext(), "Printing invoice...", Toast.LENGTH_SHORT).show();
            // Add actual printing logic here.
        });

        btnClose.setOnClickListener(v -> dismiss());

        setCancelable(true);

        return view;
    }

    private String getInvoiceStatus(int status) {
        switch (status) {
            case 1:
            case 2:
            case 4:
            case 5:
            case 6:
                return "In Progress";
            case 3:
                return "Rejected by Store";
            case 7:
                return "Canceled by Driver";
            case 8:
                return "Completed";
            default:
                return "Unknown";
        }
    }
}
