package ca.georgebrown.roseflowerdeliveryapp.utils;

import android.content.Context;
import android.os.CountDownTimer;
import android.util.Log;
import android.widget.Toast;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FieldValue;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.ListenerRegistration;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class DriverAssignmentManager {

    private static final String TAG = "DriverAssignmentManager";

    // 1 minute for the driver to respond
    private static final long DRIVER_RESPONSE_TIME_MS = 60_000;
    // 20 seconds to wait before retrying if no drivers are available
    private static final long NO_DRIVER_RETRY_DELAY_MS = 20_000;

    private final FirebaseFirestore firestore;
    private final Context context;

    public DriverAssignmentManager(Context context) {
        this.context = context.getApplicationContext();
        this.firestore = FirebaseFirestore.getInstance();
    }

    /**
     * Public entry point: Attempts to assign a driver to the provided order.
     * It first checks the order document; if the order status is already 5 (accepted)
     * or 8 (picked up), no further assignment is done.
     *
     * @param storeId       The Firestore ID for the store.
     * @param order         The order needing a driver.
     * @param storeLocation The store’s GeoPoint location.
     */
    public void assignDriver(String storeId, Order order, GeoPoint storeLocation) {
        if (order == null || order.getId() == null) {
            Log.e(TAG, "Order is null or has no ID. Cannot assign driver.");
            return;
        }
        DocumentReference orderRef = firestore.collection("orders")
                .document(storeId)
                .collection("orderItems")
                .document(order.getId());
        // Check current order status from Firestore.
        orderRef.get().addOnSuccessListener(docSnap -> {
            if (docSnap.exists()) {
                Integer status = docSnap.getLong("status") != null ? docSnap.getLong("status").intValue() : null;
                // If order is already accepted (status 5) or picked up (status 8), stop assignment.
                if (status != null && (status == 5 || status == 8)) {
                    Log.d(TAG, "Order " + order.getId() + " already accepted or picked up. No reassignment.");
                    return;
                }
                // Start assignment with an empty list of tried drivers.
                assignDriver(storeId, order, storeLocation, new ArrayList<>());
            }
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Failed to get order document: " + e.getMessage());
            // Optionally, you may retry or handle the error.
        });
    }

    /**
     * Internal method that passes along the list of driver IDs already attempted.
     */
    private void assignDriver(String storeId, Order order, GeoPoint storeLocation, List<String> triedDrivers) {
        findClosestDrivers(storeLocation, new ClosestDriversCallback() {
            @Override
            public void onDriversFound(List<String> driverIds) {
                // Filter out drivers that have already been tried.
                List<String> availableDrivers = new ArrayList<>();
                for (String id : driverIds) {
                    if (!triedDrivers.contains(id)) {
                        availableDrivers.add(id);
                    }
                }
                if (availableDrivers.isEmpty()) {
                    Log.w(TAG, "No new drivers available for order " + order.getId() + ". Already tried: " + triedDrivers);
                    showNoDriversMessageAndRetry(storeId, order, storeLocation);
                } else {
                    attemptAssignDriver(storeId, order, availableDrivers, 0, triedDrivers);
                }
            }

            @Override
            public void onError(Exception e) {
                Log.e(TAG, "Error finding closest drivers: " + e.getMessage());
                showNoDriversMessageAndRetry(storeId, order, storeLocation);
            }
        });
    }

    /**
     * Recursively attempts to assign a driver from the candidate list.
     */
    private void attemptAssignDriver(String storeId, Order order, List<String> driverIds, int index, List<String> triedDrivers) {
        if (index >= driverIds.size()) {
            Log.w(TAG, "All candidate drivers have been tried for order " + order.getId());
            showNoDriversMessageAndRetry(storeId, order, order.getDeliveryLocation() != null
                    ? new GeoPoint(order.getDeliveryLocation().getLatitude(), order.getDeliveryLocation().getLongitude())
                    : null);
            return;
        }
        final String currentDriverId = driverIds.get(index);
        Log.d(TAG, "Attempting to assign driver " + currentDriverId + " for order " + order.getId());
        DocumentReference driverRef = firestore.collection("drivers").document(currentDriverId);
        driverRef.get().addOnSuccessListener(docSnap -> {
            if (!docSnap.exists()) {
                Log.w(TAG, "Driver doc does not exist: " + currentDriverId);
                triedDrivers.add(currentDriverId);
                attemptAssignDriver(storeId, order, driverIds, index + 1, triedDrivers);
                return;
            }
            String assignedOrderId = docSnap.getString("assignedOrderId");
            if (assignedOrderId != null && !assignedOrderId.isEmpty()) {
                Log.d(TAG, "Driver " + currentDriverId + " is busy with order " + assignedOrderId + ". Trying next driver...");
                triedDrivers.add(currentDriverId);
                attemptAssignDriver(storeId, order, driverIds, index + 1, triedDrivers);
            } else {
                triedDrivers.add(currentDriverId);
                doAssignDriver(storeId, order, currentDriverId, () -> {
                    startDriverResponseTimer(storeId, order, currentDriverId, driverIds, index, triedDrivers);
                });
            }
        }).addOnFailureListener(e -> {
            Log.e(TAG, "Failed to check driver " + currentDriverId + " status: " + e.getMessage());
            triedDrivers.add(currentDriverId);
            attemptAssignDriver(storeId, order, driverIds, index + 1, triedDrivers);
        });
    }

    /**
     * Sets the order’s assignedDriverId and marks the driver as busy by setting assignedOrderId.
     * The order status is updated to 4 ("Ready for Pickup") so that the driver's popup appears.
     */
    private void doAssignDriver(String storeId, Order order, String driverId, Runnable onSuccess) {
        DocumentReference orderRef = firestore.collection("orders")
                .document(storeId)
                .collection("orderItems")
                .document(order.getId());
        orderRef.update("assignedDriverId", driverId, "status", 4)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Order " + order.getId() + ": assignedDriverId=" + driverId + ", status=4");
                    DocumentReference driverRef = firestore.collection("drivers").document(driverId);
                    driverRef.update("assignedOrderId", order.getId())
                            .addOnSuccessListener(aVoid2 -> {
                                Log.d(TAG, "Driver " + driverId + " now assigned to order " + order.getId());
                                if (onSuccess != null) onSuccess.run();
                            })
                            .addOnFailureListener(e -> Log.e(TAG, "Failed to set assignedOrderId for driver " + driverId + ": " + e.getMessage()));
                })
                .addOnFailureListener(e -> Log.e(TAG, "Failed to set assignedDriverId on order: " + e.getMessage()));
    }

    /**
     * Starts a 1-minute countdown waiting for the driver's response.
     */
    private void startDriverResponseTimer(String storeId, Order order, String driverId,
                                          List<String> driverIds, int currentIndex, List<String> triedDrivers) {
        DocumentReference orderRef = firestore.collection("orders")
                .document(storeId)
                .collection("orderItems")
                .document(order.getId());

        final ListenerRegistration[] registrationHolder = new ListenerRegistration[1];

        EventListener<DocumentSnapshot> statusListener = (snapshot, e) -> {
            if (e != null) {
                Log.e(TAG, "Order status listener error: " + e.getMessage());
                return;
            }
            if (snapshot != null && snapshot.exists()) {
                Integer status = snapshot.getLong("status") != null ? snapshot.getLong("status").intValue() : null;
                if (status != null && status == 6) {
                    Log.d(TAG, "Driver " + driverId + " rejected order " + order.getId());
                    cleanupDriverAssignment(storeId, order.getId(), driverId, () -> {
                        registrationHolder[0].remove();
                        attemptAssignDriver(storeId, order, driverIds, currentIndex + 1, triedDrivers);
                    });
                } else if (status != null && status == 5) {
                    Log.d(TAG, "Driver " + driverId + " accepted order " + order.getId() + ". Assignment locked.");
                    registrationHolder[0].remove();
                }
            }
        };

        registrationHolder[0] = orderRef.addSnapshotListener(statusListener);

        new CountDownTimer(DRIVER_RESPONSE_TIME_MS, 1000) {
            public void onTick(long millisUntilFinished) {
                Log.d(TAG, "Driver response timer for order " + order.getId() + ": " + (millisUntilFinished / 1000) + "s left");
            }
            public void onFinish() {
                orderRef.get().addOnSuccessListener(docSnap -> {
                    if (docSnap.exists()) {
                        Integer status = docSnap.getLong("status") != null ? docSnap.getLong("status").intValue() : null;
                        if (status != null && status == 4) {
                            Log.d(TAG, "Driver " + driverId + " timed out for order " + order.getId());
                            cleanupDriverAssignment(storeId, order.getId(), driverId, () -> {
                                registrationHolder[0].remove();
                                attemptAssignDriver(storeId, order, driverIds, currentIndex + 1, triedDrivers);
                            });
                        } else {
                            registrationHolder[0].remove();
                        }
                    } else {
                        registrationHolder[0].remove();
                        Log.e(TAG, "Order document not found at timer finish.");
                    }
                }).addOnFailureListener(e -> {
                    Log.e(TAG, "Failed to get order doc at timer finish: " + e.getMessage());
                    registrationHolder[0].remove();
                });
            }
        }.start();
    }

    /**
     * Unassigns a driver from the order if they time out or reject.
     */
    private void cleanupDriverAssignment(String storeId, String orderId, String driverId, Runnable onComplete) {
        DocumentReference driverRef = firestore.collection("drivers").document(driverId);
        driverRef.update("assignedOrderId", FieldValue.delete())
                .addOnSuccessListener(aVoid -> Log.d(TAG, "Driver " + driverId + " unassigned."))
                .addOnFailureListener(e -> Log.e(TAG, "Failed to clear assignedOrderId: " + e.getMessage()));

        DocumentReference orderRef = firestore.collection("orders")
                .document(storeId)
                .collection("orderItems")
                .document(orderId);
        orderRef.update("assignedDriverId", FieldValue.delete(), "status", 2)
                .addOnSuccessListener(aVoid -> {
                    Log.d(TAG, "Order " + orderId + " unassigned from driver " + driverId);
                    if (onComplete != null) onComplete.run();
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Failed to update order during cleanup: " + e.getMessage());
                    if (onComplete != null) onComplete.run();
                });
    }

    /**
     * If no drivers are available, displays a toast and retries assignment after 20 seconds.
     */
    private void showNoDriversMessageAndRetry(String storeId, Order order, GeoPoint storeLocation) {
        Toast.makeText(context, "No drivers available. Will try again in 20 seconds.", Toast.LENGTH_SHORT).show();
        new CountDownTimer(NO_DRIVER_RETRY_DELAY_MS, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {
                Log.d(TAG, "Retry timer for order " + order.getId() + ": " + (millisUntilFinished / 1000) + "s left");
            }
            @Override
            public void onFinish() {
                assignDriver(storeId, order, storeLocation, new ArrayList<>());
            }
        }.start();
    }

    // -----------------------------------------------------------------------------------------
    // Helper methods for finding the closest drivers

    private interface ClosestDriversCallback {
        void onDriversFound(List<String> driverIds);
        void onError(Exception e);
    }

    /**
     * Finds up to 5 closest drivers by comparing their GeoPoint locations.
     */
    private void findClosestDrivers(GeoPoint storeLocation, ClosestDriversCallback callback) {
        if (storeLocation == null) {
            Log.e(TAG, "storeLocation is null. Cannot find closest drivers.");
            callback.onDriversFound(new ArrayList<>());
            return;
        }
        firestore.collection("drivers")
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    List<DocumentSnapshot> docs = querySnapshot.getDocuments();
                    if (docs.isEmpty()) {
                        callback.onDriversFound(new ArrayList<>());
                        return;
                    }
                    List<DriverDistance> driverDistances = new ArrayList<>();
                    for (DocumentSnapshot doc : docs) {
                        if (!doc.exists()) continue;
                        GeoPoint driverLoc = doc.getGeoPoint("location");
                        if (driverLoc == null) continue;
                        double distance = distanceBetween(
                                storeLocation.getLatitude(), storeLocation.getLongitude(),
                                driverLoc.getLatitude(), driverLoc.getLongitude()
                        );
                        driverDistances.add(new DriverDistance(doc.getId(), distance));
                    }
                    Collections.sort(driverDistances, Comparator.comparingDouble(dd -> dd.distance));
                    List<String> closestDriverIds = new ArrayList<>();
                    for (int i = 0; i < driverDistances.size() && i < 5; i++) {
                        closestDriverIds.add(driverDistances.get(i).driverId);
                    }
                    callback.onDriversFound(closestDriverIds);
                })
                .addOnFailureListener(callback::onError);
    }

    private static class DriverDistance {
        String driverId;
        double distance;
        DriverDistance(String driverId, double distance) {
            this.driverId = driverId;
            this.distance = distance;
        }
    }

    /**
     * Calculates the distance between two latitude/longitude pairs using the Haversine formula.
     */
    private double distanceBetween(double lat1, double lng1, double lat2, double lng2) {
        double earthRadius = 6371; // km
        double dLat = Math.toRadians(lat2 - lat1);
        double dLng = Math.toRadians(lng2 - lng1);
        double a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
                Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
                        Math.sin(dLng / 2) * Math.sin(dLng / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return earthRadius * c;
    }
}
