﻿
namespace GBC_Travel_Group_125.Enum
{
    public enum Roles 
    {
       SuperAdmin,
       Admin,
       Moderator,
       Basic
    }
}
