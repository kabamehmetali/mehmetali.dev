using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GBC_Travel_Group_125.Views.RoleManager
{
    public class IndexModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
