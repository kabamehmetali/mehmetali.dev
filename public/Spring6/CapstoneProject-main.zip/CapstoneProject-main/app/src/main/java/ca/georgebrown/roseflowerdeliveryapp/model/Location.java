package ca.georgebrown.roseflowerdeliveryapp.model;

public class Location {

    private String id;
    private String formattedAddress;
    private double latitude;
    private double longitude;
    private String placeId;
    private String postalCode;
    private String city;
    private String country;
    private String address;  // Additional field if Firestore sends an "address" field

    public Location() {
    }

    public Location(String id, String formattedAddress, double latitude, double longitude,
                    String placeId, String postalCode, String city, String country, String address) {
        this.id = id;
        this.formattedAddress = formattedAddress;
        this.latitude = latitude;
        this.longitude = longitude;
        this.placeId = placeId;
        this.postalCode = postalCode;
        this.city = city;
        this.country = country;
        this.address = address;
    }

    // Getters and setters
    public String getId() { return id; }
    public void setId(String id) { this.id = id; }

    public String getFormattedAddress() { return formattedAddress; }
    public void setFormattedAddress(String formattedAddress) { this.formattedAddress = formattedAddress; }

    public double getLatitude() { return latitude; }
    public void setLatitude(double latitude) { this.latitude = latitude; }

    public double getLongitude() { return longitude; }
    public void setLongitude(double longitude) { this.longitude = longitude; }

    public String getPlaceId() { return placeId; }
    public void setPlaceId(String placeId) { this.placeId = placeId; }

    public String getPostalCode() { return postalCode; }
    public void setPostalCode(String postalCode) { this.postalCode = postalCode; }

    public String getCity() { return city; }
    public void setCity(String city) { this.city = city; }

    public String getCountry() { return country; }
    public void setCountry(String country) { this.country = country; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
}
