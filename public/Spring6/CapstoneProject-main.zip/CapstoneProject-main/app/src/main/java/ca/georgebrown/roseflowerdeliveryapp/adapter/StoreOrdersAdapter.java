package ca.georgebrown.roseflowerdeliveryapp.adapter;

import android.graphics.Typeface;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class StoreOrdersAdapter extends RecyclerView.Adapter<StoreOrdersAdapter.OrderViewHolder> {

    private List<Order> orders = new ArrayList<>();
    private OnOrderActionListener listener;

    public interface OnOrderActionListener {
        void onPrint(Order order);
        void onAccept(Order order);
        void onReject(Order order);
        void onComplete(Order order);
    }

    public StoreOrdersAdapter(List<Order> orders, OnOrderActionListener listener) {
        if (orders != null) {
            this.orders = orders;
        }
        this.listener = listener;
    }

    @NonNull
    @Override
    public OrderViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.item_order_card, parent, false);
        return new OrderViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull OrderViewHolder holder, int position) {
        Order order = orders.get(position);

        // Set order ID
        holder.tvOrderId.setText("Order ID: " + order.getId());

        // Set user name with fallback
        String userName = (order.getUserName() == null || order.getUserName().trim().isEmpty())
                ? "Unknown" : order.getUserName();
        holder.tvOrderUserName.setText("Placed by: " + userName);

        // Set order time (if available)
        if (order.getTimestamp() != null) {
            Date date = order.getTimestamp().toDate();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            holder.tvOrderTime.setText("Order Time: " + sdf.format(date));
        } else {
            holder.tvOrderTime.setText("Order Time: Not available");
        }

        // Set order status
        String statusText = getStatusText(order.getStatus());
        holder.tvOrderStatus.setText("Status: " + statusText);
        if (order.getStatus() == 2) { // Accepted
            holder.tvOrderStatus.setTextColor(holder.itemView.getResources().getColor(android.R.color.holo_green_dark));
            holder.tvOrderStatus.setTypeface(null, Typeface.BOLD);
        } else if (order.getStatus() == 3) { // Rejected
            holder.tvOrderStatus.setTextColor(holder.itemView.getResources().getColor(android.R.color.holo_red_dark));
            holder.tvOrderStatus.setTypeface(null, Typeface.BOLD);
        } else {
            holder.tvOrderStatus.setTextColor(holder.itemView.getResources().getColor(android.R.color.black));
            holder.tvOrderStatus.setTypeface(null, Typeface.NORMAL);
        }

        // Calculate order summary: subtotal, tax, total
        double subtotal = 0.0;
        if (order.getOrderItems() != null) {
            for (CartItem cartItem : order.getOrderItems()) {
                subtotal += cartItem.getItem().getPrice() * cartItem.getQuantity();
            }
        }
        double tax = subtotal * 0.13;
        double total = subtotal + tax;
        holder.tvOrderSubtotal.setText("Subtotal: $" + String.format("%.2f", subtotal));
        holder.tvOrderTax.setText("Tax: $" + String.format("%.2f", tax));
        holder.tvOrderTotal.setText("Total: $" + String.format("%.2f", total));

        // Set up nested RecyclerView for order items
        List<CartItem> cartItems = order.getOrderItems() != null ? order.getOrderItems() : new ArrayList<>();
        OrderItemsAdapter itemsAdapter = new OrderItemsAdapter(holder.itemView.getContext(), cartItems);
        holder.recyclerOrderItems.setLayoutManager(new LinearLayoutManager(holder.itemView.getContext()));
        holder.recyclerOrderItems.setAdapter(itemsAdapter);

        // Display action buttons based on order status:
        if (order.getStatus() == 1) {
            // New order: show Accept and Reject buttons
            holder.btnAcceptOrder.setVisibility(View.VISIBLE);
            holder.btnRejectOrder.setVisibility(View.VISIBLE);
            holder.btnCompleteOrder.setVisibility(View.GONE);
        } else if (order.getStatus() == 2) {
            // Accepted order: show Complete button
            holder.btnAcceptOrder.setVisibility(View.GONE);
            holder.btnRejectOrder.setVisibility(View.GONE);
            holder.btnCompleteOrder.setVisibility(View.VISIBLE);
        } else {
            // For other statuses, hide all action buttons
            holder.btnAcceptOrder.setVisibility(View.GONE);
            holder.btnRejectOrder.setVisibility(View.GONE);
            holder.btnCompleteOrder.setVisibility(View.GONE);
        }

        // Set click listeners for action buttons
        holder.btnAcceptOrder.setOnClickListener(v -> {
            if (listener != null) {
                listener.onAccept(order);
            }
        });
        holder.btnRejectOrder.setOnClickListener(v -> {
            if (listener != null) {
                listener.onReject(order);
            }
        });
        holder.btnCompleteOrder.setOnClickListener(v -> {
            if (listener != null) {
                listener.onComplete(order);
            }
        });

        // Set print icon click listener
        holder.ivPrint.setOnClickListener(v -> {
            if (listener != null) {
                listener.onPrint(order);
            }
        });
    }

    private String getStatusText(int status) {
        switch (status) {
            case 1:
                return "New";
            case 2:
                return "Accepted";
            case 3:
                return "Rejected";
            case 4:
                return "Ready for Pickup"; // Updated: status 4 now means Ready for Pickup
            case 5:
                return "Driver Accepted";
            case 6:
                return "Driver Rejected";
            case 7:
                return "Cancelled";
            case 8:
                return "Picked Up";
            case 10:
                return "Completed"; // New status 10 means Completed
            default:
                return "Unknown";
        }
    }

    @Override
    public int getItemCount() {
        return orders != null ? orders.size() : 0;
    }

    public void updateList(List<Order> newOrders) {
        if (newOrders == null) {
            this.orders = new ArrayList<>();
        } else {
            this.orders = newOrders;
        }
        notifyDataSetChanged();
    }

    static class OrderViewHolder extends RecyclerView.ViewHolder {
        TextView tvOrderId, tvOrderUserName, tvOrderTime, tvOrderStatus;
        TextView tvOrderSubtotal, tvOrderTax, tvOrderTotal;
        RecyclerView recyclerOrderItems;
        CardView cardView;
        Button btnAcceptOrder, btnRejectOrder, btnCompleteOrder;
        ImageView ivPrint;

        public OrderViewHolder(@NonNull View itemView) {
            super(itemView);
            cardView = (CardView) itemView;
            tvOrderId = itemView.findViewById(R.id.tvOrderId);
            tvOrderUserName = itemView.findViewById(R.id.tvOrderUserName);
            tvOrderTime = itemView.findViewById(R.id.tvOrderTime);
            tvOrderStatus = itemView.findViewById(R.id.tvOrderStatus);
            tvOrderSubtotal = itemView.findViewById(R.id.tvOrderSubtotal);
            tvOrderTax = itemView.findViewById(R.id.tvOrderTax);
            tvOrderTotal = itemView.findViewById(R.id.tvOrderTotal);
            recyclerOrderItems = itemView.findViewById(R.id.recyclerOrderItems);
            btnAcceptOrder = itemView.findViewById(R.id.btnAcceptOrder);
            btnRejectOrder = itemView.findViewById(R.id.btnRejectOrder);
            btnCompleteOrder = itemView.findViewById(R.id.btnCompleteOrder);
            ivPrint = itemView.findViewById(R.id.ivPrint);
        }
    }
}
