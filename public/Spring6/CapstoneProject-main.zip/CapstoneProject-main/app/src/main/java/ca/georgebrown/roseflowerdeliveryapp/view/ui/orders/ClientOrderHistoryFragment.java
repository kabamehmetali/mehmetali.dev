package ca.georgebrown.roseflowerdeliveryapp.view.ui.orders;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import ca.georgebrown.roseflowerdeliveryapp.databinding.ClientFragmentOrderHistoryBinding;

public class ClientOrderHistoryFragment extends Fragment {

    private ClientFragmentOrderHistoryBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ClientOrderHistoryViewModel clientOrderHistoryViewModel =
                new ViewModelProvider(this).get(ClientOrderHistoryViewModel.class);

        binding = ClientFragmentOrderHistoryBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textDashboard;
        clientOrderHistoryViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}