package ca.georgebrown.roseflowerdeliveryapp.repository;

import androidx.annotation.Nullable;
import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import java.util.HashMap;
import java.util.Map;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class FirebaseOrderRepository {

    public interface OrdersCallback {
        void onOrdersFetched(java.util.List<Order> orders);
        void onError(Exception e);
    }

    public interface StatusUpdateCallback {
        void onStatusUpdated();
        void onError(Exception e);
    }

    private final FirebaseFirestore db;

    public FirebaseOrderRepository() {
        db = FirebaseFirestore.getInstance();
    }

    /**
     * Listens to store orders ordered by timestamp (descending).
     */
    public void listenToStoreOrders(String storeId, final OrdersCallback callback) {
        db.collection("orders")
                .document(storeId)
                .collection("orderItems")
                .orderBy("timestamp", com.google.firebase.firestore.Query.Direction.DESCENDING)
                .addSnapshotListener((@Nullable com.google.firebase.firestore.QuerySnapshot snapshots,
                                      @Nullable com.google.firebase.firestore.FirebaseFirestoreException e) -> {
                    if (e != null) {
                        callback.onError(e);
                        return;
                    }
                    java.util.List<Order> orders = new java.util.ArrayList<>();
                    if (snapshots != null) {
                        for (com.google.firebase.firestore.DocumentSnapshot doc : snapshots.getDocuments()) {
                            if (doc.exists()) {
                                Order order = doc.toObject(Order.class);
                                if (order != null) {
                                    order.setId(doc.getId());
                                    String userName = doc.getString("userName");
                                    order.setUserName(userName);
                                    orders.add(order);
                                }
                            }
                        }
                    }
                    callback.onOrdersFetched(orders);
                });
    }

    /**
     * Updates the order's status.
     * Uses set() with merge to avoid errors if the document doesn't exist.
     */
    public void updateOrderStatus(String storeId, String orderId, int newStatus, final StatusUpdateCallback callback) {
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("status", newStatus);
        db.collection("orders")
                .document(storeId)
                .collection("orderItems")
                .document(orderId)
                .set(updateMap, SetOptions.merge())
                .addOnSuccessListener(aVoid -> {
                    if (callback != null) callback.onStatusUpdated();
                })
                .addOnFailureListener(callback::onError);
    }

    /**
     * Updates the order with the assigned driver's ID.
     * To “clear” the assignment, pass null for driverId.
     */
    public void updateOrderAssignedDriver(String storeId, String orderId, String driverId, final StatusUpdateCallback callback) {
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("assignedDriverId", driverId);
        db.collection("orders")
                .document(storeId)
                .collection("orderItems")
                .document(orderId)
                .set(updateMap, SetOptions.merge())
                .addOnSuccessListener(aVoid -> {
                    if (callback != null) callback.onStatusUpdated();
                })
                .addOnFailureListener(callback::onError);
    }

    /**
     * Updates the order when the driver picks it up by setting the pickup timestamp
     * and updating the status to 8 (Picked Up).
     */
    public void updateOrderPickup(String storeId, String orderId, Timestamp pickupTimestamp, final StatusUpdateCallback callback) {
        Map<String, Object> updateMap = new HashMap<>();
        updateMap.put("pickupTimestamp", pickupTimestamp);
        updateMap.put("status", 8);
        db.collection("orders")
                .document(storeId)
                .collection("orderItems")
                .document(orderId)
                .set(updateMap, SetOptions.merge())
                .addOnSuccessListener(aVoid -> {
                    if (callback != null) callback.onStatusUpdated();
                })
                .addOnFailureListener(callback::onError);
    }
}
