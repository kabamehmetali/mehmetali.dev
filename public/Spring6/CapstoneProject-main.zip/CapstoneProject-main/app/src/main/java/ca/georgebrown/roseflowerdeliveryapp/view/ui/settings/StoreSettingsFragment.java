package ca.georgebrown.roseflowerdeliveryapp.view.ui.settings;

import android.Manifest;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.activity.result.ActivityResultCallback;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;


import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.squareup.picasso.Picasso;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.databinding.StoreFragmentSettingsBinding;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;
import ca.georgebrown.roseflowerdeliveryapp.utils.CircleTransform;
import ca.georgebrown.roseflowerdeliveryapp.view.LoginPage;

public class StoreSettingsFragment extends Fragment {

    private StoreFragmentSettingsBinding binding;
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private StorageReference storageRef;
    private String currentUserId;

    // Launcher to request permission.
    private final ActivityResultLauncher<String> requestPermissionLauncher =
            registerForActivityResult(new ActivityResultContracts.RequestPermission(),
                    isGranted -> {
                        if (isGranted) {
                            // Permission granted, open gallery
                            pickImageFromGallery();
                        } else {
                            Toast.makeText(requireContext(), "Permission denied.", Toast.LENGTH_SHORT).show();
                        }
                    });

    // Launcher to pick an image from the gallery.
    private final ActivityResultLauncher<String> galleryLauncher =
            registerForActivityResult(new ActivityResultContracts.GetContent(),
                    new ActivityResultCallback<Uri>() {
                        @Override
                        public void onActivityResult(Uri result) {
                            if (result != null) {
                                uploadImageToFirebase(result);
                            }
                        }
                    });

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        StoreSettingsViewModel viewModel =
                new ViewModelProvider(this).get(StoreSettingsViewModel.class);

        binding = StoreFragmentSettingsBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storageRef = FirebaseStorage.getInstance().getReference();

        if (auth.getCurrentUser() != null) {
            currentUserId = auth.getCurrentUser().getUid();
        }

        // Load store data from Firestore
        loadStoreData();

        // Set up click listener for the profile image.
        binding.storeProfileImage.setOnClickListener(v -> {
            // Choose the correct permission based on the Android version.
            String permission;
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
                permission = Manifest.permission.READ_MEDIA_IMAGES;
            } else {
                permission = Manifest.permission.READ_EXTERNAL_STORAGE;
            }

            // Check for permission.
            if (ContextCompat.checkSelfPermission(requireContext(), permission) == PackageManager.PERMISSION_GRANTED) {
                pickImageFromGallery();
            } else {
                // Request the appropriate permission.
                requestPermissionLauncher.launch(permission);
            }
        });

        // Set up logout button.
        binding.storeLogoutBtn.setOnClickListener(this::storeLogoutBtn);

        return root;
    }

    /**
     * Loads the store data (store name, phone, address, image) from Firestore.
     */
    private void loadStoreData() {
        if (currentUserId == null) return;

        db.collection("users")
                .document(currentUserId)
                .get()
                .addOnSuccessListener(documentSnapshot -> {
                    if (documentSnapshot.exists()) {
                        Users user = documentSnapshot.toObject(Users.class);
                        if (user != null) {
                            // Set store name.
                            binding.storeNameView.setText(user.getStoreName());

                            // Set phone number.
                            binding.textView7.setText(user.getPhoneNumber());

                            // Set address. Adjust based on your Location model.
                            if (user.getStoreLocation() != null) {
                                // If Location object has a proper address field, use it
                                String fullAddress = user.getStoreLocation().getFormattedAddress(); // Adjust this to match your Location model
                                if (fullAddress != null && !fullAddress.isEmpty()) {
                                    binding.textView6.setText(fullAddress);
                                } else {
                                    binding.textView6.setText("No address available");
                                }
                            } else {
                                binding.textView6.setText("No address found");
                            }


                            // Load profile image via Picasso.
                            if (user.getImageUrl() != null && !user.getImageUrl().isEmpty()) {
                                Picasso.get()
                                        .load(user.getImageUrl())
                                        .placeholder(R.drawable.emptycircle)
                                        .transform(new CircleTransform())  // Apply circle transformation
                                        .into(binding.storeProfileImage);
                            }
                        }
                    }
                })
                .addOnFailureListener(e ->
                        Toast.makeText(requireContext(), "Failed to load store data", Toast.LENGTH_SHORT).show()
                );
    }

    /**
     * Opens the gallery for image selection.
     */
    private void pickImageFromGallery() {
        galleryLauncher.launch("image/*");
    }

    /**
     * Uploads the selected image to Firebase Storage and updates Firestore.
     */
    private void uploadImageToFirebase(Uri imageUri) {
        if (currentUserId == null) return;

        // Define a storage reference (e.g., "storeImages/<uid>.jpg").
        StorageReference userImageRef = storageRef.child("store_images/" + currentUserId + ".jpg");

        userImageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> {
                    userImageRef.getDownloadUrl().addOnSuccessListener(downloadUri -> {
                        // Update the Firestore document with the new image URL.
                        db.collection("users")
                                .document(currentUserId)
                                .update("imageUrl", downloadUri.toString())
                                .addOnSuccessListener(unused -> {
                                    // Refresh the ImageView.
                                    Picasso.get().load(downloadUri).into(binding.storeProfileImage);
                                    Toast.makeText(requireContext(), "Profile image updated", Toast.LENGTH_SHORT).show();
                                })
                                .addOnFailureListener(e ->
                                        Toast.makeText(requireContext(), "Failed to update Firestore", Toast.LENGTH_SHORT).show()
                                );
                    });
                })
                .addOnFailureListener(e ->
                        Toast.makeText(requireContext(), "Image upload failed", Toast.LENGTH_SHORT).show()
                );
        userImageRef.putFile(imageUri)
                .addOnSuccessListener(taskSnapshot -> {
                    userImageRef.getDownloadUrl().addOnSuccessListener(downloadUri -> {
                        // old file is overwritten automatically
                        // Update Firestore with the new imageUrl
                        db.collection("users")
                                .document(currentUserId)
                                .update("imageUrl", downloadUri.toString())
                                .addOnSuccessListener(unused -> {
                                    // Refresh your UI
                                });
                    });
                });
    }

    /**
     * Logs out the current user.
     */
    public void storeLogoutBtn(View view) {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(getContext(), LoginPage.class);
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TASK);
        startActivity(intent);
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
