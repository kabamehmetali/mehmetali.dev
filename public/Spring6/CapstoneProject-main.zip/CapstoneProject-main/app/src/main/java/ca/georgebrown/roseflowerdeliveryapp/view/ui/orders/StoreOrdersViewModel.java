package ca.georgebrown.roseflowerdeliveryapp.view.ui.orders;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import java.util.List;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseOrderRepository;

public class StoreOrdersViewModel extends ViewModel {

    private final MutableLiveData<List<Order>> ordersLiveData = new MutableLiveData<>();
    private final FirebaseOrderRepository repository;

    public StoreOrdersViewModel() {
        repository = new FirebaseOrderRepository();
    }

    public LiveData<List<Order>> getOrdersLiveData() {
        return ordersLiveData;
    }

    public void listenToOrders(String storeId) {
        repository.listenToStoreOrders(storeId, new FirebaseOrderRepository.OrdersCallback() {
            @Override
            public void onOrdersFetched(List<Order> orders) {
                ordersLiveData.postValue(orders);
            }
            @Override
            public void onError(Exception e) {
                ordersLiveData.postValue(null);
            }
        });
    }

    public void updateOrderStatus(String storeId, String orderId, int newStatus,
                                  FirebaseOrderRepository.StatusUpdateCallback callback) {
        repository.updateOrderStatus(storeId, orderId, newStatus, callback);
    }
}
