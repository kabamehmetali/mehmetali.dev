package ca.georgebrown.roseflowerdeliveryapp.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import androidx.core.graphics.Insets;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;

public class LoginPage extends AppCompatActivity {

    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private EditText emailInput;
    private EditText passwordInput;
    private Button loginButton;
    // Separate registration buttons for client, driver, and store
    private Button registerClientButton;
    private Button registerDriverButton;
    private Button registerStoreButton;

    // Key used to save the email in SharedPreferences
    private static final String PREFS_NAME = "loginPrefs";
    private static final String KEY_EMAIL = "saved_email";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login_page);

        // Apply window insets for edge-to-edge display
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        emailInput = findViewById(R.id.emailInput);
        passwordInput = findViewById(R.id.passwordInput);
        loginButton = findViewById(R.id.loginBtn);
        registerClientButton = findViewById(R.id.registerBtn);
        registerDriverButton = findViewById(R.id.registerDriverBtn);
        registerStoreButton = findViewById(R.id.registerStoreBtn);

        // Load saved email if available
        SharedPreferences preferences = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        String savedEmail = preferences.getString(KEY_EMAIL, "");
        if (!savedEmail.isEmpty()) {
            emailInput.setText(savedEmail);
        }

        // Check if a user is already logged in (auto login)
        FirebaseUser currentUser = auth.getCurrentUser();
        if (currentUser != null) {
            // Fetch user profile from Firestore and route accordingly
            db.collection("users").document(currentUser.getUid()).get()
                    .addOnSuccessListener(documentSnapshot -> {
                        if (documentSnapshot.exists()) {
                            Users user = documentSnapshot.toObject(Users.class);
                            if (user != null) {
                                Toast.makeText(LoginPage.this, "Welcome back", Toast.LENGTH_SHORT).show();
                                redirectUser(user.getRole());
                            }
                        } else {
                            // No user document exists – sign out to allow a clean login attempt.
                            auth.signOut();
                        }
                    })
                    .addOnFailureListener(e -> {
                        Log.e("LoginPage", "Error fetching user data", e);
                    });
        }

        // Manual login button listener
        loginButton.setOnClickListener(view -> loginUser());

        // Registration buttons for each user type
        registerClientButton.setOnClickListener(view -> {
            Intent intent = new Intent(LoginPage.this, ClientRegisterPage.class);
            startActivity(intent);
        });
        registerDriverButton.setOnClickListener(view -> {
            Intent intent = new Intent(LoginPage.this, DriverRegisterPage.class);
            startActivity(intent);
        });
        registerStoreButton.setOnClickListener(view -> {
            Intent intent = new Intent(LoginPage.this, StoreRegisterPage.class);
            startActivity(intent);
        });
    }

    /**
     * Logs in a user with the provided email and password.
     */
    private void loginUser() {
        String email = emailInput.getText().toString().trim();
        String password = passwordInput.getText().toString().trim();

        if (email.isEmpty() || password.isEmpty()) {
            Toast.makeText(LoginPage.this, "Please enter email and password", Toast.LENGTH_SHORT).show();
            return;
        }

        loginButton.setEnabled(false);
        auth.signInWithEmailAndPassword(email, password)
                .addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser firebaseUser = auth.getCurrentUser();
                        if (firebaseUser != null) {
                            // Save the email in SharedPreferences so it is auto-filled next time
                            SharedPreferences.Editor editor = getSharedPreferences(PREFS_NAME, MODE_PRIVATE).edit();
                            editor.putString(KEY_EMAIL, email);
                            editor.apply();

                            // Fetch user data from Firestore to determine role
                            db.collection("users").document(firebaseUser.getUid()).get()
                                    .addOnSuccessListener(documentSnapshot -> {
                                        if (documentSnapshot.exists()) {
                                            Users user = documentSnapshot.toObject(Users.class);
                                            if (user != null) {
                                                Toast.makeText(LoginPage.this, "Welcome", Toast.LENGTH_SHORT).show();
                                                redirectUser(user.getRole());
                                            } else {
                                                Toast.makeText(LoginPage.this, "User data not found", Toast.LENGTH_SHORT).show();
                                                loginButton.setEnabled(true);
                                            }
                                        } else {
                                            Toast.makeText(LoginPage.this, "No user record found", Toast.LENGTH_SHORT).show();
                                            loginButton.setEnabled(true);
                                        }
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(LoginPage.this, "Failed to fetch user data", Toast.LENGTH_SHORT).show();
                                        loginButton.setEnabled(true);
                                    });
                        }
                    } else {
                        Toast.makeText(LoginPage.this, "Login failed: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        loginButton.setEnabled(true);
                    }
                });
    }

    /**
     * Redirects the user to the correct activity based on their role.
     * Role values: 1 = Client, 2 = Driver, 3 = Store.
     *
     * @param role the role number from the user profile.
     */
    private void redirectUser(int role) {
        Intent intent;
        switch (role) {
            case 1:
                intent = new Intent(LoginPage.this, ClientPage.class);
                break;
            case 2:
                intent = new Intent(LoginPage.this, DriverPage.class);
                break;
            case 3:
                intent = new Intent(LoginPage.this, StorePage.class);
                break;
            default:
                Toast.makeText(LoginPage.this, "Unknown role", Toast.LENGTH_SHORT).show();
                return;
        }
        startActivity(intent);
        finish();
    }

}
