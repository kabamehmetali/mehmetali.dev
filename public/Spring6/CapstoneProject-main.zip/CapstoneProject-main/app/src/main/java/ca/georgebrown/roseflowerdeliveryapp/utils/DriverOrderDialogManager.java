package ca.georgebrown.roseflowerdeliveryapp.utils;

import android.app.Dialog;
import android.content.Context;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.TextView;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapView;
import com.google.android.gms.maps.MapsInitializer;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.firebase.firestore.GeoPoint;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Location;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;

public class DriverOrderDialogManager {

    public interface DriverOrderDialogListener {
        void onAccept(Order order);
        void onReject(Order order);
    }

    /**
     * Displays the driver order popup with a 20-second timer, a map showing store and delivery locations,
     * and a looping ringtone. The ringtone is stopped when the dialog is dismissed.
     *
     * @param context          the context
     * @param order            the order
     * @param driverId         the driver id (for reference)
     * @param storeLocation    the store location as a GeoPoint
     * @param storeAddress     the store address (readable)
     * @param deliveryLocation the delivery destination as a custom Location
     * @param deliveryAddress  the delivery address (readable)
     * @param listener         callback listener for accept/reject
     */
    public static void showDriverOrderPopup(Context context, Order order, String driverId,
                                            GeoPoint storeLocation, String storeAddress,
                                            Location deliveryLocation, String deliveryAddress,
                                            DriverOrderDialogListener listener) {
        // Start playing the ringtone
        final MediaPlayer mediaPlayer = MediaPlayer.create(context, R.raw.ringtone);
        mediaPlayer.setLooping(true);
        mediaPlayer.start();

        // Create and configure the dialog
        final Dialog dialog = new Dialog(context);
        dialog.requestWindowFeature(Window.FEATURE_NO_TITLE);
        dialog.setContentView(R.layout.dialog_driver_order);

        if (dialog.getWindow() != null) {
            WindowManager.LayoutParams params = dialog.getWindow().getAttributes();
            params.width = WindowManager.LayoutParams.WRAP_CONTENT;
            params.height = WindowManager.LayoutParams.WRAP_CONTENT;
            params.gravity = Gravity.CENTER;
            dialog.getWindow().setAttributes(params);
        }

        // Set up dialog views
        TextView tvOrderId = dialog.findViewById(R.id.tvOrderId);
        TextView tvDriverMessage = dialog.findViewById(R.id.tvDriverMessage);
        TextView tvStoreAddress = dialog.findViewById(R.id.tvStoreAddress);
        TextView tvDeliveryAddress = dialog.findViewById(R.id.tvDeliveryAddress);
        TextView tvTimer = dialog.findViewById(R.id.tvTimer);
        Button btnAccept = dialog.findViewById(R.id.btnAccept);
        Button btnReject = dialog.findViewById(R.id.btnReject);
        MapView mapView = dialog.findViewById(R.id.mapViewOrder);

        tvOrderId.setText("Order " + order.getId());
        tvDriverMessage.setText("New order assigned. Do you accept?");
        tvStoreAddress.setText("Store: " + storeAddress);
        tvDeliveryAddress.setText("Delivery: " + deliveryAddress);

        // Initialize MapView
        Bundle mapViewBundle = new Bundle();
        mapView.onCreate(mapViewBundle);
        mapView.onResume();
        MapsInitializer.initialize(context);
        mapView.getMapAsync(new OnMapReadyCallback() {
            @Override
            public void onMapReady(GoogleMap googleMap) {
                // Add marker for store location
                LatLng storeLatLng = new LatLng(storeLocation.getLatitude(), storeLocation.getLongitude());
                googleMap.addMarker(new MarkerOptions().position(storeLatLng).title("Store Location"));

                // Add marker for delivery destination
                LatLng deliveryLatLng = new LatLng(deliveryLocation.getLatitude(), deliveryLocation.getLongitude());
                googleMap.addMarker(new MarkerOptions().position(deliveryLatLng).title("Delivery Destination"));

                // Center the map between the two markers
                double centerLat = (storeLocation.getLatitude() + deliveryLocation.getLatitude()) / 2;
                double centerLng = (storeLocation.getLongitude() + deliveryLocation.getLongitude()) / 2;
                googleMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(centerLat, centerLng), 12));
            }
        });

        // Create a CountDownTimer that will auto-reject if time runs out.
        CountDownTimer timer = new CountDownTimer(20000, 1000) {
            public void onTick(long millisUntilFinished) {
                tvTimer.setText("Time remaining: " + millisUntilFinished / 1000 + "s");
            }
            public void onFinish() {
                tvTimer.setText("Time's up!");
                mediaPlayer.stop();
                mediaPlayer.release();
                dialog.dismiss();
                if (listener != null) {
                    listener.onReject(order);
                }
            }
        };
        timer.start();

        btnAccept.setOnClickListener(v -> {
            timer.cancel();  // Cancel the timer to prevent auto-rejection
            mediaPlayer.stop();
            mediaPlayer.release();
            dialog.dismiss();
            if (listener != null) {
                listener.onAccept(order);
            }
        });

        btnReject.setOnClickListener(v -> {
            timer.cancel();
            mediaPlayer.stop();
            mediaPlayer.release();
            dialog.dismiss();
            if (listener != null) {
                listener.onReject(order);
            }
        });

        dialog.setCancelable(false);
        dialog.show();
    }
}
