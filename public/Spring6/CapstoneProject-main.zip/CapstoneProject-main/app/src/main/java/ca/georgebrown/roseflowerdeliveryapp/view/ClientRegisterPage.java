package ca.georgebrown.roseflowerdeliveryapp.view;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AddressComponent;
import com.google.android.libraries.places.api.model.AddressComponents;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Locale;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.PlaceAutoSuggestAdapter;
import ca.georgebrown.roseflowerdeliveryapp.model.Location;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;

public class ClientRegisterPage extends AppCompatActivity {

    private static final int LOCATION_PERMISSION_REQUEST_CODE = 1001;
    private static final String TAG = "ClientRegisterPage";

    // UI Elements
    private EditText nameRegisterInput, lastNameRegisterInput, emailRegisterInput,
            passwordRegisterInput, phoneNumberInput, dateOfBirthInput;
    private AutoCompleteTextView autoCompleteAddress;
    private CheckBox termsCheckBox;
    private Button clientSignUpBtn;

    // Firebase instances
    private FirebaseAuth auth;
    private FirebaseFirestore db;

    // Google Places API
    private PlacesClient placesClient;
    private PlaceAutoSuggestAdapter autoSuggestAdapter;

    // Selected location
    private Location selectedLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_client_register_page);

        // Apply window insets if available
        View mainView = findViewById(R.id.main);
        if (mainView != null) {
            ViewCompat.setOnApplyWindowInsetsListener(mainView, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        // Check location permissions
        checkLocationPermissions();

        // Initialize Firebase Authentication & Firestore
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();

        // Initialize Google Places API
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), getString(R.string.google_maps_key), Locale.getDefault());
        }
        placesClient = Places.createClient(this);

        // Bind UI Elements
        nameRegisterInput = findViewById(R.id.nameRegisterInput);
        lastNameRegisterInput = findViewById(R.id.lastNameRegisterInput);
        emailRegisterInput = findViewById(R.id.emailRegisterInput);
        passwordRegisterInput = findViewById(R.id.editTextTextPassword);
        phoneNumberInput = findViewById(R.id.phoneNumberInput);
        dateOfBirthInput = findViewById(R.id.editTextDate);
        autoCompleteAddress = findViewById(R.id.autoCompleteAddress);
        termsCheckBox = findViewById(R.id.termsCheckBox);
        clientSignUpBtn = findViewById(R.id.clientSignUpBtn);

        // Setup DatePicker for Date of Birth with minimum age of 18:
        // Default date and max selectable date is today minus 18 years.
        Calendar maxDate = Calendar.getInstance();
        maxDate.add(Calendar.YEAR, -18);
        SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
        dateOfBirthInput.setText(format.format(maxDate.getTime()));
        dateOfBirthInput.setFocusable(false);
        dateOfBirthInput.setClickable(true);
        dateOfBirthInput.setOnClickListener(view -> showDatePickerDialog());

        // Setup Google Places Autocomplete for Address Input
        autoSuggestAdapter = new PlaceAutoSuggestAdapter(this, android.R.layout.simple_dropdown_item_1line, placesClient);
        autoCompleteAddress.setAdapter(autoSuggestAdapter);
        autoCompleteAddress.setThreshold(1);
        autoCompleteAddress.setOnItemClickListener((parent, view, position, id) -> {
            String selectedPlaceId = autoSuggestAdapter.getPlaceId(position);
            fetchPlaceDetails(selectedPlaceId);
        });

        // Set sign-up button click listener
        clientSignUpBtn.setOnClickListener(view -> clientSignUpBtn(view));
    }

    // Sign-up method
    public void clientSignUpBtn(View view) {
        String firstName = nameRegisterInput.getText().toString().trim();
        String lastName = lastNameRegisterInput.getText().toString().trim();
        String email = emailRegisterInput.getText().toString().trim();
        String password = passwordRegisterInput.getText().toString().trim();
        String phone = phoneNumberInput.getText().toString().trim();
        String dob = dateOfBirthInput.getText().toString().trim();
        boolean termsAccepted = termsCheckBox.isChecked();

        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() ||
                password.isEmpty() || phone.isEmpty() || dob.isEmpty() || selectedLocation == null) {
            Toast.makeText(this, "Please fill in all fields and select an address.", Toast.LENGTH_SHORT).show();
            return;
        }

        if (!termsAccepted) {
            Toast.makeText(this, "You must agree to the Terms and Conditions.", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser firebaseUser = auth.getCurrentUser();
                        if (firebaseUser != null) {
                            Users client = new Users();
                            client.setRole(1);
                            client.setFirstName(firstName);
                            client.setLastName(lastName);
                            client.setEmail(email);
                            client.setPassword(password);
                            client.setPhoneNumber(phone);
                            client.setDateOfBirth(dob);
                            client.setAcceptedTerms(true);
                            client.setAddress(selectedLocation);

                            db.collection("users").document(firebaseUser.getUid())
                                    .set(client)
                                    .addOnSuccessListener(aVoid -> {
                                        Toast.makeText(ClientRegisterPage.this, "Registration successful!", Toast.LENGTH_SHORT).show();
                                        Intent intent = new Intent(ClientRegisterPage.this, ClientPage.class);
                                        startActivity(intent);
                                        finish();
                                    })
                                    .addOnFailureListener(e -> {
                                        Toast.makeText(ClientRegisterPage.this, "Registration failed: " + e.getMessage(), Toast.LENGTH_LONG).show();
                                        Log.e(TAG, "Error adding document", e);
                                    });
                        }
                    } else {
                        Toast.makeText(ClientRegisterPage.this, "Authentication failed: " + task.getException().getMessage(), Toast.LENGTH_LONG).show();
                    }
                });
    }

    // Request location permissions
    private void checkLocationPermissions() {
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.ACCESS_FINE_LOCATION)
                != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this,
                    new String[]{Manifest.permission.ACCESS_FINE_LOCATION}, LOCATION_PERMISSION_REQUEST_CODE);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        if (requestCode == LOCATION_PERMISSION_REQUEST_CODE) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Log.d(TAG, "Location permission granted.");
            } else {
                Toast.makeText(this, "Location permission denied.", Toast.LENGTH_SHORT).show();
            }
        }
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
    }

    // Fetch full place details from Google Places API
    private void fetchPlaceDetails(String placeId) {
        FetchPlaceRequest request = FetchPlaceRequest.newInstance(placeId, Arrays.asList(
                Place.Field.ID, Place.Field.NAME, Place.Field.ADDRESS,
                Place.Field.LAT_LNG, Place.Field.ADDRESS_COMPONENTS
        ));

        placesClient.fetchPlace(request).addOnSuccessListener(response -> {
            Place place = response.getPlace();
            if (place.getLatLng() != null) {
                selectedLocation = new Location();
                selectedLocation.setPlaceId(placeId);
                selectedLocation.setFormattedAddress(place.getAddress());
                selectedLocation.setLatitude(place.getLatLng().latitude);
                selectedLocation.setLongitude(place.getLatLng().longitude);

                AddressComponents components = place.getAddressComponents();
                if (components != null) {
                    for (AddressComponent component : components.asList()) {
                        if (component.getTypes().contains("postal_code")) {
                            selectedLocation.setPostalCode(component.getName());
                        } else if (component.getTypes().contains("locality")) {
                            selectedLocation.setCity(component.getName());
                        } else if (component.getTypes().contains("country")) {
                            selectedLocation.setCountry(component.getName());
                        }
                    }
                }
            }
        }).addOnFailureListener(e -> Log.e(TAG, "Place details fetch failed", e));
    }

    // Updated DatePickerDialog to mimic Store registration behavior with age verification
    private void showDatePickerDialog() {
        // Set maximum date to today minus 18 years.
        Calendar maxDate = Calendar.getInstance();
        maxDate.add(Calendar.YEAR, -18);
        int defaultYear = maxDate.get(Calendar.YEAR);
        int defaultMonth = maxDate.get(Calendar.MONTH);
        int defaultDay = maxDate.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                ClientRegisterPage.this,
                (DatePicker view, int selectedYear, int selectedMonth, int selectedDay) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(selectedYear, selectedMonth, selectedDay);
                    // Create calendar for 18 years ago from today
                    Calendar eighteenYearsAgo = Calendar.getInstance();
                    eighteenYearsAgo.add(Calendar.YEAR, -18);
                    if (selectedDate.after(eighteenYearsAgo)) {
                        Toast.makeText(ClientRegisterPage.this, "You must be at least 18 years old.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    dateOfBirthInput.setText(format.format(selectedDate.getTime()));
                },
                defaultYear, defaultMonth, defaultDay);
        // Prevent selection of a date that would make the user younger than 18
        datePickerDialog.getDatePicker().setMaxDate(maxDate.getTimeInMillis());
        datePickerDialog.show();
    }

    // Back button click handler
    public void backBtn(View view) {
        Intent intent = new Intent(ClientRegisterPage.this, LoginPage.class);
        startActivity(intent);
        finish();
    }
}
