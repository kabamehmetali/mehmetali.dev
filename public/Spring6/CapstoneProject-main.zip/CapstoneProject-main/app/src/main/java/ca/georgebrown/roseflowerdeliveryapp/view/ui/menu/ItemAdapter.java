package ca.georgebrown.roseflowerdeliveryapp.view.ui.menu;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.FragmentActivity;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.util.List;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Category;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;

public class ItemAdapter extends RecyclerView.Adapter<ItemAdapter.ItemViewHolder> {

    public interface OnItemActionListener {
        void onEditItem(Category category, Item item);
        void onDeleteItem(Category category, Item item);
        void onItemClicked(Category category, Item item);
    }

    private List<Item> items;
    private final Category parentCategory;
    private final OnItemActionListener itemListener;

    public ItemAdapter(Category category, OnItemActionListener listener) {
        this.parentCategory = category;
        this.itemListener = listener;
    }

    public void setItems(List<Item> items) {
        this.items = items;
        notifyDataSetChanged();
    }

    @NonNull
    @Override
    public ItemViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View v = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_menu, parent, false);
        return new ItemViewHolder(v);
    }

    @Override
    public void onBindViewHolder(@NonNull ItemViewHolder holder, int position) {
        if (items == null) return;
        Item item = items.get(position);
        holder.tvItemName.setText(item.getName());
        holder.tvItemDescription.setText(item.getDescription());
        holder.tvItemPrice.setText("$" + String.format("%.2f", item.getPrice()));
        if (item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
            Picasso.get().load(item.getImageUrl()).placeholder(R.drawable.pictureselect).into(holder.ivItemImage);
        } else {
            holder.ivItemImage.setImageResource(R.drawable.pictureselect);
        }
        holder.btnEditItem.setOnClickListener(v -> {
            if (itemListener != null) {
                itemListener.onEditItem(parentCategory, item);
            }
        });
        holder.btnDeleteItem.setOnClickListener(v -> {
            if (itemListener != null) {
                itemListener.onDeleteItem(parentCategory, item);
            }
        });
        holder.itemView.setOnClickListener(v -> {
            if (itemListener != null) {
                itemListener.onItemClicked(parentCategory, item);
            }
        });
    }

    @Override
    public int getItemCount() {
        return items != null ? items.size() : 0;
    }

    static class ItemViewHolder extends RecyclerView.ViewHolder {
        ImageView ivItemImage;
        TextView tvItemName, tvItemDescription, tvItemPrice;
        ImageButton btnEditItem, btnDeleteItem;

        public ItemViewHolder(@NonNull View itemView) {
            super(itemView);
            ivItemImage = itemView.findViewById(R.id.ivItemImage);
            tvItemName = itemView.findViewById(R.id.tvItemName);
            tvItemDescription = itemView.findViewById(R.id.tvItemDescription);
            tvItemPrice = itemView.findViewById(R.id.tvItemPrice);
            btnEditItem = itemView.findViewById(R.id.ivEdit);
            btnDeleteItem = itemView.findViewById(R.id.ivDelete);
        }
    }
}
