package ca.georgebrown.roseflowerdeliveryapp.view;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AddressComponent;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Locale;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.PlaceAutoSuggestAdapter;
import ca.georgebrown.roseflowerdeliveryapp.model.Location;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;

public class DriverRegisterPage extends AppCompatActivity {

    private static final String TAG = "DriverRegisterPage";
    private static final int READ_EXTERNAL_STORAGE_REQUEST = 100;

    // UI Elements
    private ImageView driverImagePreview;
    private EditText firstNameInput, lastNameInput, emailRegisterInput, passwordRegisterInput;
    private EditText sinNumberInput, editTextDate, phoneNumberInput;
    private AutoCompleteTextView addressInput;
    private CheckBox termsCheckBox;
    private Button driverRegisterBtn;

    // Google Places API objects
    private PlacesClient placesClient;
    private PlaceAutoSuggestAdapter autoSuggestAdapter;
    private Location selectedLocation;

    // Firebase instances
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private StorageReference storageReference;

    // ActivityResultLauncher for image picking
    private final ActivityResultLauncher<Intent> documentLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri imageData = result.getData().getData();
                    try {
                        getContentResolver().takePersistableUriPermission(
                                imageData,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                        );
                        Bitmap selectedImage;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), imageData);
                            selectedImage = ImageDecoder.decodeBitmap(source);
                        } else {
                            selectedImage = MediaStore.Images.Media.getBitmap(getContentResolver(), imageData);
                        }
                        Picasso.get().load(imageData).into(driverImagePreview);
                        driverImagePreview.setTag(imageData);
                        Log.d(TAG, "Driver image selected: " + imageData.toString());
                    } catch (Exception e) {
                        showError("Error loading image: " + e.getMessage());
                        Log.e(TAG, "Error loading driver image", e);
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_driver_register_page);

        // Set window insets if needed
        View main = findViewById(R.id.main);
        if (main != null) {
            ViewCompat.setOnApplyWindowInsetsListener(main, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        // Initialize Firebase & Storage
        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference();

        
        // Initialize Google Places if not already initialized
        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), getString(R.string.google_maps_key), Locale.getDefault());
        }
        placesClient = Places.createClient(this);

        // Bind UI Elements
        driverImagePreview = findViewById(R.id.driverImagePreview);
        firstNameInput = findViewById(R.id.firstNameInput);
        lastNameInput = findViewById(R.id.lastNameInput);
        emailRegisterInput = findViewById(R.id.emailRegisterInput);
        passwordRegisterInput = findViewById(R.id.passwordRegisterInput);
        sinNumberInput = findViewById(R.id.sinNumberInput);
        editTextDate = findViewById(R.id.editTextDate);
        phoneNumberInput = findViewById(R.id.phoneNumberInput);
        addressInput = findViewById(R.id.addressInput);
        termsCheckBox = findViewById(R.id.termsCheckBox);
        driverRegisterBtn = findViewById(R.id.driverRegisterBtn);

        // Setup DatePicker for Date of Birth with minimum age of 18.
        // Set default date to exactly 18 years ago.
        Calendar defaultCalendar = Calendar.getInstance();
        defaultCalendar.add(Calendar.YEAR, -18);
        int defYear = defaultCalendar.get(Calendar.YEAR);
        int defMonth = defaultCalendar.get(Calendar.MONTH);
        int defDay = defaultCalendar.get(Calendar.DAY_OF_MONTH);
        editTextDate.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(defaultCalendar.getTime()));
        editTextDate.setFocusable(false);
        editTextDate.setClickable(true);
        editTextDate.setOnClickListener(v -> showDatePickerDialog());

        // Setup image selection listener
        driverImagePreview.setOnClickListener(this::selectImage);

        // Set register button click
        driverRegisterBtn.setOnClickListener(this::registerDriver);

        // Setup Google Places autocomplete for address
        autoSuggestAdapter = new PlaceAutoSuggestAdapter(this, android.R.layout.simple_dropdown_item_1line, placesClient);
        addressInput.setAdapter(autoSuggestAdapter);
        addressInput.setThreshold(1);
        addressInput.setOnItemClickListener((parent, view, position, id) -> {
            String selectedPlaceId = autoSuggestAdapter.getPlaceId(position);
            fetchPlaceDetails(selectedPlaceId);
        });
    }

    /**
     * Displays a DatePickerDialog configured so that the maximum selectable date is
     * (today - 18 years). Also, if the user selects a date that is less than 18 years
     * before today (should not happen due to maxDate), a Toast notifies them.
     */
    private void showDatePickerDialog() {
        // Set up a calendar for 18 years ago to be used as default and max date.
        Calendar maxDate = Calendar.getInstance();
        maxDate.add(Calendar.YEAR, -18);
        int year = maxDate.get(Calendar.YEAR);
        int month = maxDate.get(Calendar.MONTH);
        int day = maxDate.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                DriverRegisterPage.this,
                (DatePicker view, int selectedYear, int selectedMonth, int selectedDay) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(selectedYear, selectedMonth, selectedDay);
                    Calendar eighteenYearsAgo = Calendar.getInstance();
                    eighteenYearsAgo.add(Calendar.YEAR, -18);
                    if (selectedDate.after(eighteenYearsAgo)) {
                        Toast.makeText(DriverRegisterPage.this, "You must be at least 18 years old.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    editTextDate.setText(format.format(selectedDate.getTime()));
                },
                year, month, day);

        // Ensure the user cannot pick a date later than (today - 18 years)
        datePickerDialog.getDatePicker().setMaxDate(maxDate.getTimeInMillis());
        datePickerDialog.show();
    }

    /**
     * Checks and requests the proper permission for image selection.
     */
    public void selectImage(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_IMAGES},
                        READ_EXTERNAL_STORAGE_REQUEST);
                return;
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        READ_EXTERNAL_STORAGE_REQUEST);
                return;
            }
        }
        launchImagePicker();
    }

    private void launchImagePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        documentLauncher.launch(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == READ_EXTERNAL_STORAGE_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                launchImagePicker();
            } else {
                Toast.makeText(this, "Permission required to select an image.", Toast.LENGTH_SHORT).show();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    /**
     * Fetches place details from Google Places based on the selected place ID.
     */
    private void fetchPlaceDetails(String placeId) {
        FetchPlaceRequest request = FetchPlaceRequest.newInstance(placeId, Arrays.asList(
                Place.Field.ID, Place.Field.NAME, Place.Field.ADDRESS,
                Place.Field.LAT_LNG, Place.Field.ADDRESS_COMPONENTS
        ));
        placesClient.fetchPlace(request)
                .addOnSuccessListener(response -> {
                    Place place = response.getPlace();
                    if (place.getLatLng() != null) {
                        selectedLocation = new Location();
                        selectedLocation.setPlaceId(placeId);
                        selectedLocation.setFormattedAddress(place.getAddress());
                        selectedLocation.setLatitude(place.getLatLng().latitude);
                        selectedLocation.setLongitude(place.getLatLng().longitude);
                        if (place.getAddressComponents() != null) {
                            for (AddressComponent component : place.getAddressComponents().asList()) {
                                if (component.getTypes().contains("postal_code")) {
                                    selectedLocation.setPostalCode(component.getName());
                                } else if (component.getTypes().contains("locality")) {
                                    selectedLocation.setCity(component.getName());
                                } else if (component.getTypes().contains("country")) {
                                    selectedLocation.setCountry(component.getName());
                                }
                            }
                        }
                        Log.d(TAG, "Selected location: " + selectedLocation.getFormattedAddress());
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(DriverRegisterPage.this, "Failed to fetch address details.", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Failed to fetch address details", e);
                });
    }

    /**
     * Registers the driver by validating fields, creating a Firebase user,
     * uploading the driver image, and saving driver data to Firestore.
     */
    public void registerDriver(View view) {
        driverRegisterBtn.setEnabled(false);
        String firstName = firstNameInput.getText().toString().trim();
        String lastName = lastNameInput.getText().toString().trim();
        String email = emailRegisterInput.getText().toString().trim();
        String password = passwordRegisterInput.getText().toString().trim();
        String sinNumber = sinNumberInput.getText().toString().trim();
        String dateOfBirth = editTextDate.getText().toString().trim();
        String phoneNumber = phoneNumberInput.getText().toString().trim();
        String addressText = addressInput.getText().toString().trim();
        boolean termsAccepted = termsCheckBox.isChecked();

        if (firstName.isEmpty() || lastName.isEmpty() || email.isEmpty() || password.isEmpty() ||
                sinNumber.isEmpty() || dateOfBirth.isEmpty() || phoneNumber.isEmpty() ||
                addressText.isEmpty() || selectedLocation == null) {
            driverRegisterBtn.setEnabled(true);
            Toast.makeText(this, "Please fill in all required fields.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!termsAccepted) {
            driverRegisterBtn.setEnabled(true);
            Toast.makeText(this, "You must agree to the Terms and Conditions.", Toast.LENGTH_SHORT).show();
            return;
        }
        // Ensure driver image is selected
        if (driverImagePreview.getTag() == null) {
            driverRegisterBtn.setEnabled(true);
            Toast.makeText(this, "Driver image is required.", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser firebaseUser = auth.getCurrentUser();
                        if (firebaseUser != null) {
                            // Build driver user model (role = 2)
                            Users driverUser = new Users();
                            driverUser.setRole(2);
                            driverUser.setFirstName(firstName);
                            driverUser.setLastName(lastName);
                            driverUser.setEmail(email);
                            driverUser.setPassword(password);
                            driverUser.setDateOfBirth(dateOfBirth);
                            driverUser.setPhoneNumber(phoneNumber);
                            driverUser.setAddress(selectedLocation);
                            driverUser.setSinNumber(sinNumber);
                            driverUser.setAcceptedTerms(termsAccepted);

                            // Upload driver image first
                            Uri imageUri = (Uri) driverImagePreview.getTag();
                            uploadDriverImage(imageUri, firebaseUser.getUid(), driverUser);
                        } else {
                            Log.e(TAG, "FirebaseUser is null after account creation.");
                            driverRegisterBtn.setEnabled(true);
                        }
                    } else {
                        Toast.makeText(DriverRegisterPage.this, "Authentication failed: " +
                                task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        Log.e(TAG, "Authentication failed", task.getException());
                        driverRegisterBtn.setEnabled(true);
                    }
                });
    }

    private void uploadDriverImage(Uri imageUri, String uid, Users driverUser) {
        StorageReference imageRef = storageReference.child("driver_images/" + uid + ".jpg");
        UploadTask uploadTask = imageRef.putFile(imageUri);

        uploadTask.continueWithTask((Continuation<UploadTask.TaskSnapshot, Task<Uri>>) task -> {
            if (!task.isSuccessful()) {
                Log.e(TAG, "Driver image upload failed", task.getException());
                throw task.getException();
            }
            return imageRef.getDownloadUrl();
        }).addOnSuccessListener(uri -> {
            String downloadUrl = uri.toString();
            driverUser.setImageUrl(downloadUrl);
            Log.d(TAG, "Driver image uploaded. URL: " + downloadUrl);
            saveDriverToFirestore(uid, driverUser);
        }).addOnFailureListener(e -> {
            showError("Driver image upload failed: " + e.getMessage());
            Log.e(TAG, "Driver image upload failed", e);
        });
    }

    private void saveDriverToFirestore(String uid, Users driverUser) {
        db.collection("users").document(uid)
                .set(driverUser)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(DriverRegisterPage.this, "Driver registration successful!", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "Driver data saved to Firestore.");
                    Intent intent = new Intent(DriverRegisterPage.this, DriverPage.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    showError("Registration failed: " + e.getMessage());
                    Log.e(TAG, "Failed to save driver data", e);
                });
    }

    public void backBtn(View view) {
        Intent intent = new Intent(DriverRegisterPage.this, LoginPage.class);
        startActivity(intent);
        finish();
    }

    private void showError(String message) {
        Snackbar.make(findViewById(R.id.main), message, Snackbar.LENGTH_LONG).show();
    }
}
