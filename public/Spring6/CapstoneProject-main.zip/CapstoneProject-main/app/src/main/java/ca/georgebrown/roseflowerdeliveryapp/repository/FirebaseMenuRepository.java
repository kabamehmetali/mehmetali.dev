package ca.georgebrown.roseflowerdeliveryapp.repository;

import android.net.Uri;
import androidx.annotation.NonNull;
import com.google.android.gms.tasks.Task;
import com.google.android.gms.tasks.Tasks;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.WriteBatch;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import ca.georgebrown.roseflowerdeliveryapp.model.Category;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;

public class FirebaseMenuRepository {

    private final FirebaseFirestore db;
    private final StorageReference storageReference;

    public FirebaseMenuRepository() {
        // Initialize Firestore without changing its settings here.
        db = FirebaseFirestore.getInstance();
        // Initialize Storage reference.
        storageReference = FirebaseStorage.getInstance().getReference();
    }

    public interface RepositoryCallback<T> {
        void onSuccess(T result);
        void onFailure(Exception e);
    }

    // Retrieves all categories (and their items) for a given store.
    public void getMenu(String storeId, RepositoryCallback<List<Category>> callback) {
        CollectionReference categoriesRef = db.collection("stores").document(storeId).collection("categories");
        categoriesRef.get().addOnCompleteListener(task -> {
            if (task.isSuccessful()) {
                List<DocumentSnapshot> docs = task.getResult().getDocuments();
                List<Category> categories = new ArrayList<>();
                if (docs.isEmpty()) {
                    callback.onSuccess(categories);
                    return;
                }
                List<Task<QuerySnapshot>> itemsTasks = new ArrayList<>();
                for (DocumentSnapshot doc : docs) {
                    Category category = doc.toObject(Category.class);
                    if (category != null) {
                        category.setId(doc.getId());
                    }
                    categories.add(category);
                    // Get the "items" subcollection for this category.
                    Task<QuerySnapshot> itemsTask = doc.getReference().collection("items").get()
                            .addOnCompleteListener(itemTask -> {
                                if (itemTask.isSuccessful() && itemTask.getResult() != null) {
                                    List<Item> items = new ArrayList<>();
                                    for (DocumentSnapshot itemDoc : itemTask.getResult().getDocuments()) {
                                        Item item = itemDoc.toObject(Item.class);
                                        if (item != null) {
                                            item.setId(itemDoc.getId());
                                            // Record the parent category ID.
                                            item.setCategoryId(category.getId());
                                        }
                                        items.add(item);
                                    }
                                    category.setItems(items);
                                }
                            });
                    itemsTasks.add(itemsTask);
                }
                Tasks.whenAllComplete(itemsTasks)
                        .addOnCompleteListener(allTasks -> callback.onSuccess(categories));
            } else {
                callback.onFailure(task.getException());
            }
        });
    }

    public void addCategory(String storeId, Category category, RepositoryCallback<Void> callback) {
        db.collection("stores").document(storeId)
                .collection("categories")
                .add(category)
                .addOnSuccessListener(documentReference -> {
                    category.setId(documentReference.getId());
                    callback.onSuccess(null);
                })
                .addOnFailureListener(callback::onFailure);
    }

    public void updateCategory(String storeId, Category category, RepositoryCallback<Void> callback) {
        if (category.getId() == null) {
            callback.onFailure(new Exception("Category ID is null"));
            return;
        }
        db.collection("stores").document(storeId)
                .collection("categories")
                .document(category.getId())
                .set(category)
                .addOnSuccessListener(aVoid -> callback.onSuccess(null))
                .addOnFailureListener(callback::onFailure);
    }

    public void deleteCategory(String storeId, String categoryId, RepositoryCallback<Void> callback) {
        DocumentReference categoryRef = db.collection("stores").document(storeId)
                .collection("categories").document(categoryId);
        categoryRef.collection("items").get().addOnCompleteListener(task -> {
            if (task.isSuccessful() && task.getResult() != null) {
                WriteBatch batch = db.batch();
                for (DocumentSnapshot doc : task.getResult().getDocuments()) {
                    batch.delete(doc.getReference());
                }
                batch.delete(categoryRef);
                batch.commit()
                        .addOnSuccessListener(aVoid -> callback.onSuccess(null))
                        .addOnFailureListener(callback::onFailure);
            } else {
                callback.onFailure(task.getException());
            }
        });
    }

    // Standard addItem method (without image upload)
    public void addItem(String storeId, String categoryId, Item item, RepositoryCallback<Void> callback) {
        if (categoryId == null || categoryId.isEmpty()) {
            callback.onFailure(new Exception("Category ID is null or empty"));
            return;
        }
        db.collection("stores").document(storeId)
                .collection("categories").document(categoryId)
                .collection("items")
                .add(item)
                .addOnSuccessListener(documentReference -> {
                    item.setId(documentReference.getId());
                    callback.onSuccess(null);
                })
                .addOnFailureListener(callback::onFailure);
    }

    // Adds an item along with uploading its image.
    public void addItemWithImage(String storeId, String categoryId, Item item, @NonNull Uri imageUri, RepositoryCallback<Void> callback) {
        if (categoryId == null || categoryId.isEmpty()) {
            callback.onFailure(new Exception("Category ID is null or empty"));
            return;
        }
        // Create a new document reference to generate an item ID.
        DocumentReference docRef = db.collection("stores").document(storeId)
                .collection("categories").document(categoryId)
                .collection("items").document();
        String itemId = docRef.getId();
        item.setId(itemId);
        // Upload the image to Firebase Storage.
        StorageReference imageRef = storageReference.child("item_images/" + itemId + ".jpg");
        UploadTask uploadTask = imageRef.putFile(imageUri);
        uploadTask.continueWithTask(task -> {
            if (!task.isSuccessful()) {
                throw Objects.requireNonNull(task.getException());
            }
            return imageRef.getDownloadUrl();
        }).addOnSuccessListener(uri -> {
            String downloadUrl = uri.toString();
            item.setImageUrl(downloadUrl);
            // Save the item document with the image URL.
            docRef.set(item)
                    .addOnSuccessListener(aVoid -> callback.onSuccess(null))
                    .addOnFailureListener(callback::onFailure);
        }).addOnFailureListener(callback::onFailure);
    }

    // Updates an existing item (without changing its image).
    public void updateItem(String storeId, String categoryId, Item item, RepositoryCallback<Void> callback) {
        if (item.getId() == null) {
            callback.onFailure(new Exception("Item ID is null"));
            return;
        }
        // Overwrite the entire document (preserving existing imageUrl if not modified).
        db.collection("stores").document(storeId)
                .collection("categories").document(categoryId)
                .collection("items")
                .document(item.getId())
                .set(item)
                .addOnSuccessListener(aVoid -> callback.onSuccess(null))
                .addOnFailureListener(callback::onFailure);
    }

    // Updates an existing item and uploads a new image.
    public void updateItemWithImage(String storeId, String categoryId, Item item, @NonNull Uri imageUri, RepositoryCallback<Void> callback) {
        // If no new image is provided, update item without image change.
        if (imageUri == null) {
            updateItem(storeId, categoryId, item, callback);
            return;
        }
        if (item.getId() == null) {
            callback.onFailure(new Exception("Item ID is null"));
            return;
        }
        // Get document reference for the existing item.
        DocumentReference docRef = db.collection("stores").document(storeId)
                .collection("categories").document(categoryId)
                .collection("items")
                .document(item.getId());
        // Upload new image to Firebase Storage (this will overwrite the old image).
        StorageReference imageRef = storageReference.child("item_images/" + item.getId() + ".jpg");
        UploadTask uploadTask = imageRef.putFile(imageUri);
        uploadTask.continueWithTask(task -> {
            if (!task.isSuccessful()) {
                throw task.getException();
            }
            return imageRef.getDownloadUrl();
        }).addOnSuccessListener(uri -> {
            String downloadUrl = uri.toString();
            item.setImageUrl(downloadUrl);
            // Update the item document with the new image URL and other fields.
            docRef.set(item)
                    .addOnSuccessListener(aVoid -> callback.onSuccess(null))
                    .addOnFailureListener(callback::onFailure);
        }).addOnFailureListener(callback::onFailure);
    }

    // Deletes an item and its associated image from Firebase Storage.
    public void deleteItem(String storeId, String categoryId, String itemId, RepositoryCallback<Void> callback) {
        // Reference to the Firestore document.
        DocumentReference docRef = db.collection("stores").document(storeId)
                .collection("categories").document(categoryId)
                .collection("items")
                .document(itemId);
        // Reference to the image in Firebase Storage.
        StorageReference imageRef = storageReference.child("item_images/" + itemId + ".jpg");
        // Delete both the image and the document.
        Task<Void> deleteImageTask = imageRef.delete();
        Task<Void> deleteDocTask = docRef.delete();
        Tasks.whenAll(deleteImageTask, deleteDocTask)
                .addOnSuccessListener(aVoid -> callback.onSuccess(null))
                .addOnFailureListener(callback::onFailure);
    }
}
