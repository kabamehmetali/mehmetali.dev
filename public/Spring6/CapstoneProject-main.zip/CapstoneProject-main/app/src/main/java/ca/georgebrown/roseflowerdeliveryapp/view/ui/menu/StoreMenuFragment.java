package ca.georgebrown.roseflowerdeliveryapp.view.ui.menu;

import android.net.Uri;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import ca.georgebrown.roseflowerdeliveryapp.databinding.StoreFragmentMenuBinding;
import ca.georgebrown.roseflowerdeliveryapp.model.Category;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;

public class StoreMenuFragment extends Fragment implements
        CategoryAdapter.OnCategoryActionListener,
        AddEditCategoryDialog.CategoryDialogListener,
        AddEditItemDialog.ItemDialogListener,
        ItemAdapter.OnItemActionListener {

    private StoreMenuViewModel viewModel;
    private StoreFragmentMenuBinding binding;
    private CategoryAdapter categoryAdapter;
    // Backup list for filtering.
    private final List<Category> originalCategories = new ArrayList<>();

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        binding = StoreFragmentMenuBinding.inflate(inflater, container, false);
        View view = binding.getRoot();

        binding.rvMenu.setLayoutManager(new LinearLayoutManager(getContext()));
        categoryAdapter = new CategoryAdapter(this, this);
        binding.rvMenu.setAdapter(categoryAdapter);

        binding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                applyFiltersAndSearch();
            }
            @Override
            public void afterTextChanged(Editable s) { }
        });

        binding.spinnerAvailability.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyFiltersAndSearch();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        binding.spinnerSort.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                applyFiltersAndSearch();
            }
            @Override
            public void onNothingSelected(AdapterView<?> parent) { }
        });

        // FloatingActionButton to add a new category.
        binding.fabAddItem.setOnClickListener(v -> {
            AddEditCategoryDialog dialog = AddEditCategoryDialog.newInstance(null);
            dialog.setTargetFragment(StoreMenuFragment.this, 0);
            dialog.show(getParentFragmentManager(), "AddCategoryDialog");
        });

        return view;
    }

    @Override
    public void onViewCreated(@NonNull View view, @Nullable Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(this).get(StoreMenuViewModel.class);
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            viewModel.setStoreId(currentUser.getUid());
        }
        viewModel.getCategories().observe(getViewLifecycleOwner(), categories -> {
            originalCategories.clear();
            originalCategories.addAll(categories);
            if (categories == null || categories.isEmpty()) {
                binding.rvMenu.setVisibility(View.GONE);
                binding.tvNoCategories.setVisibility(View.VISIBLE);
            } else {
                binding.rvMenu.setVisibility(View.VISIBLE);
                binding.tvNoCategories.setVisibility(View.GONE);
            }
            applyFiltersAndSearch();
        });


        // Setup filter spinners.
        String[] availabilityOptions = {"All", "Available", "Not Available"};
        ArrayAdapter<String> availabilityAdapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, availabilityOptions);
        availabilityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerAvailability.setAdapter(availabilityAdapter);

        String[] sortOptions = {"A–Z", "Z–A", "Priority 0–9", "Priority 9–0"};
        ArrayAdapter<String> sortAdapter = new ArrayAdapter<>(getContext(),
                android.R.layout.simple_spinner_item, sortOptions);
        sortAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        binding.spinnerSort.setAdapter(sortAdapter);
    }

    private void applyFiltersAndSearch() {
        String searchQuery = binding.etSearch.getText().toString().toLowerCase().trim();
        String availabilityFilter = binding.spinnerAvailability.getSelectedItem().toString();
        String sortOption = binding.spinnerSort.getSelectedItem().toString();

        List<Category> filteredCategories = new ArrayList<>();
        for (Category category : originalCategories) {
            boolean categoryMatch = category.getName().toLowerCase().contains(searchQuery);
            List<Item> filteredItems = new ArrayList<>();
            if (category.getItems() != null) {
                for (Item item : category.getItems()) {
                    boolean itemMatch = item.getName().toLowerCase().contains(searchQuery)
                            || item.getDescription().toLowerCase().contains(searchQuery);
                    boolean availabilityMatch = availabilityFilter.equals("All") ||
                            (availabilityFilter.equals("Available") && item.isAvailable()) ||
                            (availabilityFilter.equals("Not Available") && !item.isAvailable());
                    if ((categoryMatch || itemMatch) && availabilityMatch) {
                        filteredItems.add(item);
                    }
                }
            }
            if (!filteredItems.isEmpty() || categoryMatch) {
                Category newCategory = new Category();
                newCategory.setId(category.getId());
                newCategory.setName(category.getName());
                newCategory.setDescription(category.getDescription());
                newCategory.setPriority(category.getPriority());
                newCategory.setUserId(category.getUserId());
                newCategory.setItems(filteredItems);
                filteredCategories.add(newCategory);
            }
        }
        if (sortOption.equals("A–Z")) {
            Collections.sort(filteredCategories, (a, b) -> a.getName().compareToIgnoreCase(b.getName()));
        } else if (sortOption.equals("Z–A")) {
            Collections.sort(filteredCategories, (a, b) -> b.getName().compareToIgnoreCase(a.getName()));
        } else if (sortOption.equals("Priority 0–9")) {
            Collections.sort(filteredCategories, (a, b) -> Integer.compare(a.getPriority(), b.getPriority()));
        } else if (sortOption.equals("Priority 9–0")) {
            Collections.sort(filteredCategories, (a, b) -> Integer.compare(b.getPriority(), a.getPriority()));
        }
        categoryAdapter.setCategories(filteredCategories);
    }

    @Override
    public void onEditCategory(Category category) {
        AddEditCategoryDialog dialog = AddEditCategoryDialog.newInstance(category);
        dialog.setTargetFragment(StoreMenuFragment.this, 0);
        dialog.show(getParentFragmentManager(), "EditCategoryDialog");
    }

    @Override
    public void onDeleteCategory(Category category) {
        viewModel.deleteCategory(category.getId());
    }

    @Override
    public void onAddItem(Category category) {
        AddEditItemDialog dialog = AddEditItemDialog.newInstance(null, category.getId());
        dialog.setTargetFragment(StoreMenuFragment.this, 0);
        dialog.show(getParentFragmentManager(), "AddItemDialog");
    }

    @Override
    public void onEditItem(Category category, ca.georgebrown.roseflowerdeliveryapp.model.Item item) {
        AddEditItemDialog dialog = AddEditItemDialog.newInstance(item, category.getId());
        dialog.setTargetFragment(StoreMenuFragment.this, 0);
        dialog.show(getParentFragmentManager(), "EditItemDialog");
    }

    @Override
    public void onDeleteItem(Category category, ca.georgebrown.roseflowerdeliveryapp.model.Item item) {
        viewModel.deleteItem(category.getId(), item.getId());
    }

    @Override
    public void onItemClicked(Category category, ca.georgebrown.roseflowerdeliveryapp.model.Item item) {
        ItemDetailDialog dialog = ItemDetailDialog.newInstance(item);
        dialog.show(getParentFragmentManager(), "ItemDetailDialog");
    }

    @Override
    public void onCategorySaved(Category category) {
        if (category != null) {
            if (category.getId() != null) {
                viewModel.updateCategory(category);
            } else {
                viewModel.addCategory(category);
            }
        }
    }


    @Override
    public void onItemSaved(String categoryId, Item item, Uri localImageUri) {
        if (item != null) {
            if (item.getId() != null) { // Updating an existing item
                if (localImageUri != null) {
                    viewModel.updateItem(categoryId, item, localImageUri);
                } else {
                    viewModel.updateItem(categoryId, item, null);
                }
            } else { // Adding a new item
                if (localImageUri != null) {
                    viewModel.addItem(categoryId, item, localImageUri);
                } else {
                    viewModel.addItem(categoryId, item);
                }
            }
        }
    }


}
