package ca.georgebrown.roseflowerdeliveryapp.view.ui.profile;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import ca.georgebrown.roseflowerdeliveryapp.databinding.ClientFragmentProfileBinding;

public class ClientProfileFragment extends Fragment {

    private ClientFragmentProfileBinding binding;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ClientProfileViewModel clientProfileViewModel =
                new ViewModelProvider(this).get(ClientProfileViewModel.class);

        binding = ClientFragmentProfileBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        final TextView textView = binding.textNotifications;
        clientProfileViewModel.getText().observe(getViewLifecycleOwner(), textView::setText);
        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}