package ca.georgebrown.roseflowerdeliveryapp.adapter;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.squareup.picasso.Picasso;
import java.util.List;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;
import de.hdodenhof.circleimageview.CircleImageView;

public class ClientStoreAdapter extends RecyclerView.Adapter<ClientStoreAdapter.StoreViewHolder> {

    private Context context;
    private List<Users> storeList;
    private OnStoreClickListener onStoreClickListener;

    public interface OnStoreClickListener {
        void onStoreClick(Users store);
    }

    public void setOnStoreClickListener(OnStoreClickListener listener) {
        this.onStoreClickListener = listener;
    }

    public ClientStoreAdapter(Context context, List<Users> storeList) {
        this.context = context;
        this.storeList = storeList;
    }

    @NonNull
    @Override
    public StoreViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(context).inflate(R.layout.client_item_store, parent, false);
        return new StoreViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull StoreViewHolder holder, int position) {
        Users store = storeList.get(position);
        holder.storeName.setText(store.getStoreName());
        if (store.getImageUrl() != null && !store.getImageUrl().isEmpty()) {
            Picasso.get().load(store.getImageUrl()).into(holder.storeImage);
        }
        // Set click listener on the entire store item.
        holder.itemView.setOnClickListener(v -> {
            if (onStoreClickListener != null) {
                onStoreClickListener.onStoreClick(store);
            }
        });
    }

    @Override
    public int getItemCount() {
        return storeList.size();
    }

    public static class StoreViewHolder extends RecyclerView.ViewHolder {
        TextView storeName;
        CircleImageView storeImage;

        public StoreViewHolder(@NonNull View itemView) {
            super(itemView);
            storeName = itemView.findViewById(R.id.client_store_name);
            storeImage = itemView.findViewById(R.id.client_store_image);
        }
    }
}
