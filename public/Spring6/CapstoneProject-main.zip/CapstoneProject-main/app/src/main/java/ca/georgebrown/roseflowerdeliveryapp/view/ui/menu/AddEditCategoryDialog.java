package ca.georgebrown.roseflowerdeliveryapp.view.ui.menu;

import android.app.Dialog;
import android.content.Context;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Category;

public class AddEditCategoryDialog extends DialogFragment {

    public interface CategoryDialogListener {
        void onCategorySaved(Category category);
    }

    private Category category;
    private CategoryDialogListener listener;

    public static AddEditCategoryDialog newInstance(Category category) {
        AddEditCategoryDialog dialog = new AddEditCategoryDialog();
        dialog.category = category;
        dialog.setCancelable(true);
        return dialog;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (getTargetFragment() instanceof CategoryDialogListener) {
            listener = (CategoryDialogListener) getTargetFragment();
        } else if (context instanceof CategoryDialogListener) {
            listener = (CategoryDialogListener) context;
        } else {
            throw new RuntimeException("Must implement CategoryDialogListener");
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_add_edit_category, null);
        EditText etCategoryName = view.findViewById(R.id.etCategoryName);
        EditText etCategoryDescription = view.findViewById(R.id.etCategoryDescription);
        EditText etCategoryPriority = view.findViewById(R.id.etCategoryPriority);
        Button btnSave = view.findViewById(R.id.btnSaveCategory);
        Button btnCancel = view.findViewById(R.id.btnCancelCategory);

        if (category != null) {
            etCategoryName.setText(category.getName());
            etCategoryDescription.setText(category.getDescription());
            etCategoryPriority.setText(String.valueOf(category.getPriority()));
        }

        btnSave.setOnClickListener(v -> {
            String name = etCategoryName.getText().toString().trim();
            String description = etCategoryDescription.getText().toString().trim();
            String priorityStr = etCategoryPriority.getText().toString().trim();

            if (TextUtils.isEmpty(name)) {
                Toast.makeText(getContext(), "Please enter a category name", Toast.LENGTH_SHORT).show();
                return;
            }
            if (TextUtils.isEmpty(priorityStr)) {
                Toast.makeText(getContext(), "Please enter a priority number", Toast.LENGTH_SHORT).show();
                return;
            }
            int priority;
            try {
                priority = Integer.parseInt(priorityStr);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Invalid priority number", Toast.LENGTH_SHORT).show();
                return;
            }
            if (category == null) {
                category = new Category();
            }
            category.setName(name);
            category.setDescription(description);
            category.setPriority(priority);

            if (listener != null) {
                listener.onCategorySaved(category);
            }
            dismiss();
        });

        btnCancel.setOnClickListener(v -> dismiss());
        builder.setView(view);
        return builder.create();
    }
}
