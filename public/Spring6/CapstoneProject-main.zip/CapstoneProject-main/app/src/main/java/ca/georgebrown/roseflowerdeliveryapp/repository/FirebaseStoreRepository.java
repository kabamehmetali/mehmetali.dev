package ca.georgebrown.roseflowerdeliveryapp.repository;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.SetOptions;
import java.util.HashMap;
import java.util.Map;

public class FirebaseStoreRepository {

    private final FirebaseFirestore db;

    public FirebaseStoreRepository() {
        db = FirebaseFirestore.getInstance();
    }

    public interface RepositoryCallback<T> {
        void onSuccess(T result);
        void onFailure(Exception e);
    }

    /**
     * Updates the store document under "stores/{storeId}" with the given status.
     *
     * @param storeId         The store's unique ID.
     * @param acceptingOrders True if the store is accepting orders.
     * @param lastUpdated     The current timestamp.
     * @param callback        Callback to handle success or failure.
     */
    public void updateStoreStatus(String storeId, boolean acceptingOrders, Timestamp lastUpdated, RepositoryCallback<Void> callback) {
        Map<String, Object> updates = new HashMap<>();
        updates.put("acceptingOrders", acceptingOrders);
        updates.put("lastUpdated", lastUpdated);

        db.collection("stores").document(storeId)
                .set(updates, SetOptions.merge())
                .addOnSuccessListener(aVoid -> callback.onSuccess(null))
                .addOnFailureListener(callback::onFailure);
    }
}
