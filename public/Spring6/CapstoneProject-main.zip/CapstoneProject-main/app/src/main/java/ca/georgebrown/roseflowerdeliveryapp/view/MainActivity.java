package ca.georgebrown.roseflowerdeliveryapp.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import ca.georgebrown.roseflowerdeliveryapp.R;

public class MainActivity extends AppCompatActivity {
    SharedPreferences sharedPreferences;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        sharedPreferences = this.getSharedPreferences("grettings",MODE_PRIVATE);
        boolean grettingsOne = sharedPreferences.getBoolean("grettingsOne",true);
        boolean grettingsTwo =sharedPreferences.getBoolean("grettingsTwo",true);
        boolean grettingsThree =sharedPreferences.getBoolean("grettingsThree",true);


        if(grettingsOne){
            Intent intent = new Intent(this,GrettingsPageOne.class);
            startActivity(intent);
        } else if (grettingsTwo){
            Intent intent = new Intent(this,GrettingsPageTwo.class);
            startActivity(intent);
        } else if(grettingsThree) {
            Intent intent = new Intent(this,GrettingsPageThree.class);
            startActivity(intent);
        } else {
            Intent intent = new Intent(this, LoginPage.class);
            startActivity(intent);
        }
    }
}