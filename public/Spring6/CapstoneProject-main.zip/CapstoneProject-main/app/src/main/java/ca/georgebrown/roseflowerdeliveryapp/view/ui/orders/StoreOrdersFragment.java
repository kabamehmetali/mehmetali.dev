package ca.georgebrown.roseflowerdeliveryapp.view.ui.orders;

import android.content.Context;
import android.content.Intent;
import android.graphics.Typeface;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.print.PrintAttributes;
import android.print.PrintDocumentAdapter;
import android.print.PrintManager;
import android.text.format.DateFormat;
import android.util.Log;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.LinearLayoutManager;

import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.GeoPoint;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.OrderItemsAdapter;
import ca.georgebrown.roseflowerdeliveryapp.adapter.StoreOrdersAdapter;
import ca.georgebrown.roseflowerdeliveryapp.databinding.StoreFragmentOrdersBinding;
import ca.georgebrown.roseflowerdeliveryapp.utils.DriverAssignmentManager;
import ca.georgebrown.roseflowerdeliveryapp.model.CartItem;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseOrderRepository;
import ca.georgebrown.roseflowerdeliveryapp.view.ui.orders.StoreOrdersViewModel;

public class StoreOrdersFragment extends Fragment {

    private StoreFragmentOrdersBinding binding;
    private StoreOrdersViewModel ordersViewModel;
    private StoreOrdersAdapter ordersAdapter;
    private String storeId;

    // In‑memory set to track orders that have already been prompted in this session.
    private static Set<String> promptedOrderIds = new HashSet<>();

    // Sample store location. Replace with your actual store location.
    private final GeoPoint storeLocation = new GeoPoint(43.6532, -79.3832);

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        ordersViewModel = new ViewModelProvider(this).get(StoreOrdersViewModel.class);
        binding = StoreFragmentOrdersBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        storeId = FirebaseAuth.getInstance().getUid();

        // Optionally, clear the prompted set when fragment is created.
        promptedOrderIds.clear();

        ordersAdapter = new StoreOrdersAdapter(null, new StoreOrdersAdapter.OnOrderActionListener() {
            @Override
            public void onPrint(Order order) {
                printOrder(order);
            }
            @Override
            public void onComplete(Order order) {
                // Instead of marking order complete immediately,
                // initiate driver assignment (which now sets status to 4).
                Log.d("StoreOrdersFragment", "Initiating driver assignment for order: " + order.getId());
                new DriverAssignmentManager(requireContext()).assignDriver(storeId, order, storeLocation);
            }
            @Override
            public void onAccept(Order order) {
                ordersViewModel.updateOrderStatus(storeId, order.getId(), 2, newStatusCallback("ACCEPT"));
            }
            @Override
            public void onReject(Order order) {
                ordersViewModel.updateOrderStatus(storeId, order.getId(), 3, newStatusCallback("REJECT"));
            }
        });
        binding.ordersRecyclerView.setLayoutManager(new LinearLayoutManager(requireContext()));
        binding.ordersRecyclerView.setAdapter(ordersAdapter);

        ordersViewModel.getOrdersLiveData().observe(getViewLifecycleOwner(), new Observer<List<Order>>() {
            @Override
            public void onChanged(List<Order> orders) {
                binding.ordersProgressBar.setVisibility(View.GONE);
                if (orders == null) {
                    Log.d("StoreOrdersFragment", "No orders or error occurred.");
                    return;
                }
                Log.d("StoreOrdersFragment", "Fetched " + orders.size() + " orders.");
                ordersAdapter.updateList(orders);
                checkForNewOrders(orders);
            }
        });

        ordersViewModel.listenToOrders(storeId);
        return root;
    }

    /**
     * Checks for new orders (status = 1) that haven't been prompted in this session.
     */
    private void checkForNewOrders(List<Order> orders) {
        for (Order order : orders) {
            if (order.getStatus() == 1 && !promptedOrderIds.contains(order.getId())) {
                promptedOrderIds.add(order.getId());
                Log.d("StoreOrdersFragment", "Prompting new order: " + order.getId());
                // Optionally, show a pop-up for new orders here.
            }
        }
    }

    /**
     * Prints the given order.
     */
    private void printOrder(Order order) {
        double subtotal = 0.0;
        if (order.getOrderItems() != null) {
            for (CartItem cartItem : order.getOrderItems()) {
                subtotal += cartItem.getItem().getPrice() * cartItem.getQuantity();
            }
        }
        double tax = subtotal * 0.13;
        double total = subtotal + tax;

        StringBuilder html = new StringBuilder();
        html.append("<html><body style='font-family:sans-serif;'>");
        html.append("<h1>Order ").append(order.getId()).append("</h1>");

        String userName = (order.getUserName() == null || order.getUserName().trim().isEmpty())
                ? "Unknown" : order.getUserName();
        html.append("<p><strong>Placed by:</strong> ").append(userName).append("</p>");

        if (order.getTimestamp() != null) {
            Date date = order.getTimestamp().toDate();
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault());
            String dateStr = sdf.format(date);
            html.append("<p><strong>Order Time:</strong> ").append(dateStr).append("</p>");
        } else {
            html.append("<p><strong>Order Time:</strong> Not available</p>");
        }

        html.append("<p><strong>Subtotal:</strong> $").append(String.format("%.2f", subtotal)).append("</p>");
        html.append("<p><strong>Tax (13%):</strong> $").append(String.format("%.2f", tax)).append("</p>");
        html.append("<p><strong>Total:</strong> $").append(String.format("%.2f", total)).append("</p>");
        html.append("<p><strong>Status:</strong> ").append(getStatusText(order.getStatus())).append("</p>");

        html.append("<table border='1' style='border-collapse:collapse; width:100%;'>");
        html.append("<tr><th>Item Name</th><th>Description</th><th>Note</th><th>Qty</th><th>Price</th><th>Total</th></tr>");
        if (order.getOrderItems() != null) {
            for (CartItem cartItem : order.getOrderItems()) {
                html.append("<tr>");
                html.append("<td>").append(cartItem.getItem().getName()).append("</td>");
                html.append("<td>").append(cartItem.getItem().getDescription()).append("</td>");
                String note = cartItem.getNote();
                html.append("<td>").append((note == null || note.isEmpty()) ? "None" : note).append("</td>");
                html.append("<td>").append(cartItem.getQuantity()).append("</td>");
                html.append("<td>$").append(String.format("%.2f", cartItem.getItem().getPrice())).append("</td>");
                double itemTotal = cartItem.getItem().getPrice() * cartItem.getQuantity();
                html.append("<td>$").append(String.format("%.2f", itemTotal)).append("</td>");
                html.append("</tr>");
            }
        }
        html.append("</table>");
        html.append("</body></html>");

        WebView webView = new WebView(requireContext());
        webView.loadDataWithBaseURL(null, html.toString(), "text/HTML", "UTF-8", null);
        webView.setWebViewClient(new WebViewClient() {
            @Override
            public void onPageFinished(WebView view, String url) {
                PrintManager printManager = (PrintManager) requireContext().getSystemService(Context.PRINT_SERVICE);
                PrintDocumentAdapter printAdapter = view.createPrintDocumentAdapter("Order_" + order.getId());
                PrintAttributes printAttributes = new PrintAttributes.Builder()
                        .setMediaSize(PrintAttributes.MediaSize.NA_LETTER)
                        .setMinMargins(PrintAttributes.Margins.NO_MARGINS)
                        .build();
                printManager.print("Print Order " + order.getId(), printAdapter, printAttributes);
            }
        });
    }

    private String getStatusText(int status) {
        switch (status) {
            case 1:
                return "New";
            case 2:
                return "Accepted";
            case 3:
                return "Rejected";
            case 4:
                return "Ready for Pickup";
            case 5:
                return "Driver Accepted";
            case 6:
                return "Driver Rejected";
            case 7:
                return "Cancelled";
            case 8:
                return "Picked Up";
            case 10:
                return "Completed";
            default:
                return "Unknown";
        }
    }

    private FirebaseOrderRepository.StatusUpdateCallback newStatusCallback(String action) {
        return new FirebaseOrderRepository.StatusUpdateCallback() {
            @Override
            public void onStatusUpdated() {
                Log.d("StoreOrdersFragment", "Order " + action + " successful.");
            }
            @Override
            public void onError(Exception e) {
                Log.e("StoreOrdersFragment", "Error " + action + ": " + e.getMessage());
            }
        };
    }
}
