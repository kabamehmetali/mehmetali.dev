package ca.georgebrown.roseflowerdeliveryapp.view.ui.menu;

import android.app.Dialog;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.fragment.app.DialogFragment;
import com.squareup.picasso.Picasso;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;

public class ItemDetailDialog extends DialogFragment {

    private static final String ARG_ITEM = "arg_item";
    private Item item;

    public static ItemDetailDialog newInstance(Item item) {
        ItemDetailDialog dialog = new ItemDetailDialog();
        Bundle args = new Bundle();
        args.putSerializable(ARG_ITEM, item);
        dialog.setArguments(args);
        return dialog;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if(getArguments() != null) {
            item = (Item) getArguments().getSerializable(ARG_ITEM);
        }
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        View view = LayoutInflater.from(getContext()).inflate(R.layout.dialog_item_detail, null);

        ImageView ivImage = view.findViewById(R.id.ivItemDetailImage);
        TextView tvName = view.findViewById(R.id.tvItemDetailName);
        TextView tvDescription = view.findViewById(R.id.tvItemDetailDescription);
        TextView tvPrice = view.findViewById(R.id.tvItemDetailPrice);
        TextView tvPriority = view.findViewById(R.id.tvItemDetailPriority);
        TextView tvAvailability = view.findViewById(R.id.tvItemDetailAvailability);
        TextView tvFlowerType = view.findViewById(R.id.tvItemDetailFlowerType);
        TextView tvFlowerColor = view.findViewById(R.id.tvItemDetailFlowerColor);
        TextView tvBouquetSize = view.findViewById(R.id.tvItemDetailBouquetSize);
        Button btnClose = view.findViewById(R.id.btnCloseItemDetail);

        if (item != null) {
            tvName.setText(item.getName());
            tvDescription.setText(item.getDescription());
            tvPrice.setText("Price: $" + String.format("%.2f", item.getPrice()));
            tvPriority.setText("Priority: " + item.getPriority());
            tvAvailability.setText("Availability: " + (item.isAvailable() ? "Available" : "Not Available"));
            tvFlowerType.setText("Flower Type: " + item.getFlowerType());
            tvFlowerColor.setText("Flower Color: " + item.getFlowerColor());
            tvBouquetSize.setText("Bouquet Size: " + item.getBouquetSize());
            if (!TextUtils.isEmpty(item.getImageUrl())) {
                Picasso.get().load(item.getImageUrl()).placeholder(R.drawable.pictureselect).into(ivImage);
            }
        }

        btnClose.setOnClickListener(v -> dismiss());
        builder.setView(view);
        return builder.create();
    }
}
