package ca.georgebrown.roseflowerdeliveryapp.view.ui.home;

import android.location.Location;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import androidx.annotation.NonNull;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.Navigation;
import androidx.recyclerview.widget.LinearLayoutManager;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import java.util.ArrayList;
import java.util.Calendar;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.ClientItemAdapter;
import ca.georgebrown.roseflowerdeliveryapp.adapter.ClientStoreAdapter;
import ca.georgebrown.roseflowerdeliveryapp.databinding.ClientFragmentHomeBinding;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;
import ca.georgebrown.roseflowerdeliveryapp.utils.CartManager;
import ca.georgebrown.roseflowerdeliveryapp.utils.ClientLocationManager;

public class ClientHomeFragment extends Fragment {

    private ClientFragmentHomeBinding binding;
    private ClientHomeViewModel viewModel;
    private ClientStoreAdapter closestStoreAdapter;
    private ClientItemAdapter closestItemAdapter;
    private ClientStoreAdapter randomStoreAdapter;
    private ClientItemAdapter randomItemAdapter;
    private ClientLocationManager locationManager;
    private TextView tvCartBadge;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        viewModel = new ViewModelProvider(this).get(ClientHomeViewModel.class);
        binding = ClientFragmentHomeBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        tvCartBadge = root.findViewById(R.id.tvCartBadge);

        // Listen for item added and cart update events.
        getChildFragmentManager().setFragmentResultListener("itemAddedKey", this, (requestKey, bundle) -> {
            if (bundle.getBoolean("itemAdded", false)) {
                updateCartCounter();
            }
        });
        getChildFragmentManager().setFragmentResultListener("cartUpdatedKey", this, (requestKey, bundle) -> {
            if (bundle.getBoolean("cartUpdated", false)) {
                updateCartCounter();
            }
        });

        // --- Greeting Section Setup ---
        ImageView ivGreetingIcon = root.findViewById(R.id.ivGreetingIcon);
        TextView tvGreetingMessage = root.findViewById(R.id.tvGreetingMessage);
        final String defaultName = "User";
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        if (currentUser != null) {
            FirebaseFirestore.getInstance()
                    .collection("users")
                    .document(currentUser.getUid())
                    .get()
                    .addOnSuccessListener(documentSnapshot -> {
                        String userName = defaultName;
                        if (documentSnapshot.exists()) {
                            Users user = documentSnapshot.toObject(Users.class);
                            if (user != null && user.getFirstName() != null) {
                                userName = user.getFirstName() + (user.getLastName() != null ? " " : "");
                            }
                        }
                        updateGreeting(tvGreetingMessage, ivGreetingIcon, userName);
                    })
                    .addOnFailureListener(e -> updateGreeting(tvGreetingMessage, ivGreetingIcon, defaultName));
        } else {
            updateGreeting(tvGreetingMessage, ivGreetingIcon, defaultName);
        }

        // --- RecyclerViews Setup ---
        binding.rvClosestStores.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        binding.rvClosestItems.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        binding.rvRandomStores.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));
        binding.rvRandomItems.setLayoutManager(new LinearLayoutManager(getContext(), LinearLayoutManager.HORIZONTAL, false));

        // Initialize adapters with empty lists.
        closestStoreAdapter = new ClientStoreAdapter(getContext(), new ArrayList<>());
        closestItemAdapter = new ClientItemAdapter(getContext(), new ArrayList<>());
        randomStoreAdapter = new ClientStoreAdapter(getContext(), new ArrayList<>());
        randomItemAdapter = new ClientItemAdapter(getContext(), new ArrayList<>());

        binding.rvClosestStores.setAdapter(closestStoreAdapter);
        binding.rvClosestItems.setAdapter(closestItemAdapter);
        binding.rvRandomStores.setAdapter(randomStoreAdapter);
        binding.rvRandomItems.setAdapter(randomItemAdapter);

        // --- Set Store Item Click Listeners ---
        // Use the action defined on the home destination (client_navigation_home) to navigate.
        closestStoreAdapter.setOnStoreClickListener(store -> {
            Bundle args = new Bundle();
            // Force-convert the value to String to ensure correct type.
            String storeId = String.valueOf(store.getId());
            args.putString("storeId", storeId);
            Navigation.findNavController(root)
                    .navigate(R.id.action_client_navigation_home_to_clientStoreFragment, args);
        });
        randomStoreAdapter.setOnStoreClickListener(store -> {
            Bundle args = new Bundle();
            String storeId = String.valueOf(store.getId());
            args.putString("storeId", storeId);
            Navigation.findNavController(root)
                    .navigate(R.id.action_client_navigation_home_to_clientStoreFragment, args);
        });

        // --- Search Bar Listener ---
        binding.etSearch.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) { /* No action needed */ }
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                viewModel.search(s.toString());
            }
            @Override
            public void afterTextChanged(Editable s) { /* No action needed */ }
        });

        // --- Location Manager and Load Closest Stores ---
        locationManager = new ClientLocationManager(getActivity());
        if (locationManager.hasLocationPermission()) {
            locationManager.getLastLocation((Location location) -> viewModel.loadClosestStores(location));
        } else {
            locationManager.requestLocationPermission();
        }

        // --- Load Default Random Stores and Items ---
        viewModel.loadRandomStores();
        viewModel.loadRandomItems();

        // --- Observe LiveData Changes ---
        viewModel.getClosestStores().observe(getViewLifecycleOwner(), stores -> {
            closestStoreAdapter = new ClientStoreAdapter(getContext(), stores);
            closestStoreAdapter.setOnStoreClickListener(store -> {
                Bundle args = new Bundle();
                String storeId = String.valueOf(store.getId());
                args.putString("storeId", storeId);
                Navigation.findNavController(root)
                        .navigate(R.id.action_client_navigation_home_to_clientStoreFragment, args);
            });
            binding.rvClosestStores.setAdapter(closestStoreAdapter);
        });

        viewModel.getClosestItems().observe(getViewLifecycleOwner(), items -> {
            closestItemAdapter = new ClientItemAdapter(getContext(), items);
            closestItemAdapter.setOnItemClickListener(item -> {
                ClientItemDetailDialogFragment detailDialog = ClientItemDetailDialogFragment.newInstance(item);
                detailDialog.show(getChildFragmentManager(), "ItemDetailDialog");
            });
            binding.rvClosestItems.setAdapter(closestItemAdapter);
        });

        viewModel.getRandomStores().observe(getViewLifecycleOwner(), stores -> {
            randomStoreAdapter = new ClientStoreAdapter(getContext(), stores);
            randomStoreAdapter.setOnStoreClickListener(store -> {
                Bundle args = new Bundle();
                String storeId = String.valueOf(store.getId());
                args.putString("storeId", storeId);
                Navigation.findNavController(root)
                        .navigate(R.id.action_client_navigation_home_to_clientStoreFragment, args);
            });
            binding.rvRandomStores.setAdapter(randomStoreAdapter);
        });

        viewModel.getRandomItems().observe(getViewLifecycleOwner(), items -> {
            randomItemAdapter = new ClientItemAdapter(getContext(), items);
            randomItemAdapter.setOnItemClickListener(item -> {
                ClientItemDetailDialogFragment detailDialog = ClientItemDetailDialogFragment.newInstance(item);
                detailDialog.show(getChildFragmentManager(), "ItemDetailDialog");
            });
            binding.rvRandomItems.setAdapter(randomItemAdapter);
        });

        // --- Cart Button Setup ---
        binding.fabChart.setOnClickListener(v -> {
            updateCartCounter();
            CartDialogFragment cartDialogFragment = new CartDialogFragment();
            cartDialogFragment.show(getChildFragmentManager(), "CartDialog");
        });

        updateCartCounter();
        return root;
    }

    private void updateGreeting(TextView tvGreetingMessage, ImageView ivGreetingIcon, String userName) {
        Calendar calendar = Calendar.getInstance();
        int hour = calendar.get(Calendar.HOUR_OF_DAY);
        String greetingText;
        int iconResId;
        if (hour >= 5 && hour < 12) {
            greetingText = "Good Morning, " + userName;
            iconResId = R.drawable.sun;
        } else if (hour >= 12 && hour < 17) {
            greetingText = "Good Afternoon, " + userName;
            iconResId = R.drawable.sun;
        } else if (hour >= 17 && hour < 21) {
            greetingText = "Good Evening, " + userName;
            iconResId = R.drawable.night;
        } else {
            greetingText = "Good Night, " + userName;
            iconResId = R.drawable.night;
        }
        tvGreetingMessage.setText(greetingText);
        ivGreetingIcon.setImageResource(iconResId);
    }

    // Update the cart counter using the summed quantity of items.
    private void updateCartCounter() {
        int count = CartManager.getInstance(getContext()).getCartItemCount();
        if (tvCartBadge != null) {
            if (count > 0) {
                tvCartBadge.setVisibility(View.VISIBLE);
                tvCartBadge.setText(String.valueOf(count));
            } else {
                tvCartBadge.setVisibility(View.GONE);
            }
        }
    }

    @Override
    public void onResume() {
        super.onResume();
        updateCartCounter();
    }
}
