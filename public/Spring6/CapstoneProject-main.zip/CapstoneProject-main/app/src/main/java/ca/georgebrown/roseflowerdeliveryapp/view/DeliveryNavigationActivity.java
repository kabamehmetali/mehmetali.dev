package ca.georgebrown.roseflowerdeliveryapp.view;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;

import android.Manifest;
import android.location.Location;
import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseOrderRepository;

public class DeliveryNavigationActivity extends AppCompatActivity implements OnMapReadyCallback {

    private static final String TAG = "DeliveryNavActivity";
    private GoogleMap mMap;
    private Marker driverMarker;
    private Marker destinationMarker;
    private Polyline routePolyline;
    private FusedLocationProviderClient fusedLocationClient;
    private LocationCallback locationCallback;

    private Button btnPickedUp, btnComplete, btnCancel;
    private TextView tvStoreAddress, tvDestinationAddress;

    // Coordinates and addresses passed via Intent extras.
    private LatLng storeLatLng;
    private LatLng deliveryLatLng;
    private String storeAddress, deliveryAddress;
    private String orderId, storeId;

    // Replace with your real Google Directions API key.
    private String directionsApiKey = "YOUR_DIRECTIONS_API_KEY";

    // Firebase repository to update order status.
    private FirebaseOrderRepository orderRepository;
    private FirebaseFirestore firestore;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_navigation);

        // Retrieve extras.
        orderId = getIntent().getStringExtra("orderId");
        storeId = getIntent().getStringExtra("storeId");
        storeLatLng = new LatLng(
                getIntent().getDoubleExtra("store_lat", 0),
                getIntent().getDoubleExtra("store_lng", 0)
        );
        deliveryLatLng = new LatLng(
                getIntent().getDoubleExtra("delivery_lat", 0),
                getIntent().getDoubleExtra("delivery_lng", 0)
        );
        storeAddress = getIntent().getStringExtra("store_address");
        deliveryAddress = getIntent().getStringExtra("delivery_address");

        btnPickedUp = findViewById(R.id.btnPickedUp);
        btnComplete = findViewById(R.id.btnComplete);
        btnCancel = findViewById(R.id.btnCancel);
        tvStoreAddress = findViewById(R.id.tvStoreAddress);
        tvDestinationAddress = findViewById(R.id.tvDestinationAddress);

        // Display readable addresses.
        tvStoreAddress.setText("Store: " + storeAddress);
        tvDestinationAddress.setText("Destination: " + deliveryAddress);

        // Initially show only "Picked Up" and "Cancel".
        btnComplete.setVisibility(View.GONE);

        // Initialize Firebase repository.
        orderRepository = new FirebaseOrderRepository();
        firestore = FirebaseFirestore.getInstance();

        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this);

        // Initialize the map fragment.
        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapNavigation);
        mapFragment.getMapAsync(this);

        // "Picked Up" button click: update order status to 8 (Picked Up)
        btnPickedUp.setOnClickListener(v -> {
            if (mMap != null) {
                if (destinationMarker != null) {
                    destinationMarker.remove();
                }
                destinationMarker = mMap.addMarker(new MarkerOptions()
                        .position(deliveryLatLng)
                        .title("Delivery Destination"));
                mMap.animateCamera(CameraUpdateFactory.newLatLngZoom(deliveryLatLng, 14));
                if (driverMarker != null) {
                    fetchRoute(driverMarker.getPosition(), deliveryLatLng);
                }
            }
            // Update order status to 8 (Picked Up)
            orderRepository.updateOrderStatus(storeId, orderId, 8, new FirebaseOrderRepository.StatusUpdateCallback() {
                @Override
                public void onStatusUpdated() {
                    Toast.makeText(DeliveryNavigationActivity.this, "Order marked as Picked Up.", Toast.LENGTH_SHORT).show();
                }
                @Override
                public void onError(Exception e) {
                    Toast.makeText(DeliveryNavigationActivity.this, "Failed to update status: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
            btnPickedUp.setVisibility(View.GONE);
            btnComplete.setVisibility(View.VISIBLE);
        });

        // "Complete" button click: update order status to 10 (Completed)
        btnComplete.setOnClickListener(v -> {
            orderRepository.updateOrderStatus(storeId, orderId, 10, new FirebaseOrderRepository.StatusUpdateCallback() {
                @Override
                public void onStatusUpdated() {
                    Toast.makeText(DeliveryNavigationActivity.this, "Delivery completed.", Toast.LENGTH_SHORT).show();
                    finish();
                }
                @Override
                public void onError(Exception e) {
                    Toast.makeText(DeliveryNavigationActivity.this, "Failed to update status: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                }
            });
        });

        btnCancel.setOnClickListener(v -> {
            Toast.makeText(DeliveryNavigationActivity.this, "Delivery canceled.", Toast.LENGTH_SHORT).show();
            finish();
        });

        startLocationUpdates();
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;
        destinationMarker = mMap.addMarker(new MarkerOptions()
                .position(storeLatLng)
                .title("Store Location"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(storeLatLng, 14));
    }

    private void startLocationUpdates() {
        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(5000);
        locationRequest.setFastestInterval(3000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        if (ActivityCompat.checkSelfPermission(this,
                Manifest.permission.ACCESS_FINE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(this,
                        Manifest.permission.ACCESS_COARSE_LOCATION) != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            Toast.makeText(this, "Location permissions are not granted.", Toast.LENGTH_SHORT).show();
            return;
        }

        locationCallback = new LocationCallback(){
            @Override
            public void onLocationResult(LocationResult locationResult) {
                if (locationResult == null || mMap == null) return;
                Location location = locationResult.getLastLocation();
                LatLng currentLatLng = new LatLng(location.getLatitude(), location.getLongitude());
                if (driverMarker == null) {
                    driverMarker = mMap.addMarker(new MarkerOptions()
                            .position(currentLatLng)
                            .title("Your Location"));
                } else {
                    driverMarker.setPosition(currentLatLng);
                }
                if (destinationMarker != null) {
                    fetchRoute(currentLatLng, destinationMarker.getPosition());
                }
            }
        };

        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, null);
    }

    private void fetchRoute(LatLng origin, LatLng destination) {
        String url = getDirectionsUrl(origin, destination);
        new FetchRouteTask().execute(url);
    }

    private String getDirectionsUrl(LatLng origin, LatLng dest) {
        String str_origin = "origin=" + origin.latitude + "," + origin.longitude;
        String str_dest = "destination=" + dest.latitude + "," + dest.longitude;
        String mode = "mode=driving";
        String parameters = str_origin + "&" + str_dest + "&" + mode;
        String output = "json";
        return "https://maps.googleapis.com/maps/api/directions/" + output + "?" +
                parameters + "&key=" + directionsApiKey;
    }

    private class FetchRouteTask extends AsyncTask<String, Void, String> {
        @Override
        protected String doInBackground(String... url) {
            String data = "";
            try {
                data = downloadUrl(url[0]);
            } catch (Exception e) {
                Log.e(TAG, "Error downloading route", e);
            }
            return data;
        }
        @Override
        protected void onPostExecute(String result) {
            new ParseRouteTask().execute(result);
        }
    }

    private String downloadUrl(String strUrl) throws IOException {
        String data = "";
        InputStream iStream = null;
        HttpURLConnection urlConnection = null;
        try {
            URL url = new URL(strUrl);
            urlConnection = (HttpURLConnection) url.openConnection();
            urlConnection.connect();
            iStream = urlConnection.getInputStream();
            BufferedReader br = new BufferedReader(new InputStreamReader(iStream));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            data = sb.toString();
            br.close();
        } finally {
            if (iStream != null)
                iStream.close();
            if (urlConnection != null)
                urlConnection.disconnect();
        }
        return data;
    }

    private class ParseRouteTask extends AsyncTask<String, Void, List<LatLng>> {
        @Override
        protected List<LatLng> doInBackground(String... jsonData) {
            List<LatLng> points = new ArrayList<>();
            try {
                JSONObject jsonObject = new JSONObject(jsonData[0]);
                JSONArray routes = jsonObject.getJSONArray("routes");
                if (routes.length() > 0) {
                    JSONObject route = routes.getJSONObject(0);
                    JSONObject overviewPolyline = route.getJSONObject("overview_polyline");
                    String encodedPoints = overviewPolyline.getString("points");
                    points = decodePoly(encodedPoints);
                }
            } catch (JSONException e) {
                Log.e(TAG, "Error parsing route JSON", e);
            }
            return points;
        }
        @Override
        protected void onPostExecute(List<LatLng> points) {
            if (points != null && !points.isEmpty() && mMap != null) {
                if (routePolyline != null)
                    routePolyline.remove();
                PolylineOptions lineOptions = new PolylineOptions();
                lineOptions.addAll(points);
                lineOptions.width(10);
                lineOptions.color(getResources().getColor(com.google.android.libraries.places.R.color.quantum_vanillablueA700));
                routePolyline = mMap.addPolyline(lineOptions);
            }
        }
    }

    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new ArrayList<>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;
        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;
            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;
            LatLng p = new LatLng((lat / 1E5), (lng / 1E5));
            poly.add(p);
        }
        return poly;
    }

    @Override
    protected void onPause() {
        super.onPause();
        if (fusedLocationClient != null && locationCallback != null) {
            fusedLocationClient.removeLocationUpdates(locationCallback);
        }
    }
}
