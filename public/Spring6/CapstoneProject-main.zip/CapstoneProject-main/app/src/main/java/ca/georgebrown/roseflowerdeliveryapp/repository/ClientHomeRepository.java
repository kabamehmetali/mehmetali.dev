package ca.georgebrown.roseflowerdeliveryapp.repository;

import android.location.Location;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.Query;
import java.util.ArrayList;
import java.util.List;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;

public class ClientHomeRepository {

    private FirebaseFirestore firestore;

    public ClientHomeRepository() {
        firestore = FirebaseFirestore.getInstance();
    }

    // Query for stores (role==3). If a location is provided, order by a field; otherwise, apply a limit.
    public Query getStoresQuery(Location currentLocation) {
        Query query = firestore.collection("users")
                .whereEqualTo("role", 3);
        if (currentLocation != null) {
            // For demonstration only; for real geo‑search, consider a proper library (e.g. GeoFire)
            query = query.orderBy("storeLocation.latitude");
        } else {
            query = query.limit(10);
        }
        return query;
    }

    // Query for items using a collection group query.
    public Query getRandomItemsQuery() {
        return firestore.collectionGroup("items").limit(10);
    }

    // Query for items within a specific store (if needed)
    public Query getItemsForStore(String storeIdentifier) {
        return firestore.collection("users")
                .document(storeIdentifier)
                .collection("items")
                .orderBy("priority");
    }

    // New: Query for stores matching a search text.
    public Query getStoresSearchQuery(String queryText) {
        // Assumes each store document has a "storeNameLower" field.
        return firestore.collection("users")
                .whereEqualTo("role", 3)
                .orderBy("storeNameLower")
                .startAt(queryText)
                .endAt(queryText + "\uf8ff");
    }
    // In your repository class (for example, ClientHomeRepository)
    public void getStores(FirebaseMenuRepository.RepositoryCallback<List<Users>> callback) {
        FirebaseFirestore db = FirebaseFirestore.getInstance();
        db.collection("users")
                .whereEqualTo("role", 3)
                .get()
                .addOnSuccessListener(querySnapshot -> {
                    List<Users> stores = new ArrayList<>();
                    for (DocumentSnapshot doc : querySnapshot.getDocuments()) {
                        Users store = doc.toObject(Users.class);
                        if (store != null) {
                            store.setId(doc.getId()); // Set the document id!
                            stores.add(store);
                        }
                    }
                    callback.onSuccess(stores);
                })
                .addOnFailureListener(callback::onFailure);
    }

    // New: Query for items matching a search text.
    public Query getItemsSearchQuery(String queryText) {
        // Assumes each item document has a "nameLower" field.
        return firestore.collectionGroup("items")
                .orderBy("nameLower")
                .startAt(queryText)
                .endAt(queryText + "\uf8ff");
    }
}
