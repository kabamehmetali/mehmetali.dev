package ca.georgebrown.roseflowerdeliveryapp.view.ui.orders;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

public class ClientOrderHistoryViewModel extends ViewModel {

    private final MutableLiveData<String> mText;

    public ClientOrderHistoryViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is Order History fragment");
    }

    public LiveData<String> getText() {
        return mText;
    }
}