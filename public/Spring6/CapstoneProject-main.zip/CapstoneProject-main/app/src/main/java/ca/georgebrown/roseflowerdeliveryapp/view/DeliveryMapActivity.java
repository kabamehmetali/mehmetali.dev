package ca.georgebrown.roseflowerdeliveryapp.view;

import android.os.AsyncTask;
import android.os.Bundle;
import android.util.Log;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.MapFragment;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.model.BitmapDescriptorFactory;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MapStyleOptions;
import com.google.android.gms.maps.model.Marker;
import com.google.android.gms.maps.model.MarkerOptions;
import com.google.android.gms.maps.model.Polyline;
import com.google.android.gms.maps.model.PolylineOptions;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.R;

public class DeliveryMapActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;
    private Marker destinationMarker;
    private Polyline routePolyline;

    // Workflow buttons.
    private Button btnCancel, btnPickedUp, btnDelivered;

    // Coordinates.
    private double storeLat, storeLng, deliveryLat, deliveryLng;
    // Order and store IDs.
    private String orderId, storeId;
    /**
     * Order statuses:
     * 5 = Driver Accepted (not yet picked up)
     * 8 = Picked Up
     * 10 = Delivered (driver delivered)
     * 7 = Cancelled
     */
    private int currentStatus;

    private FirebaseFirestore firestore;
    private DocumentReference orderDocRef;

    // Your Compute Routes API key.
    private final String API_KEY = "AIzaSyDpw_FIyUrDG_ERsIrMh81vwsp5Syv3LG0";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_delivery_map);

        // Enable ActionBar up button.
        if (getSupportActionBar() != null) {
            getSupportActionBar().setDisplayHomeAsUpEnabled(true);
            getSupportActionBar().setTitle("Delivery Map");
        }

        firestore = FirebaseFirestore.getInstance();

        // Retrieve extras.
        orderId = getIntent().getStringExtra("orderId");
        storeId = getIntent().getStringExtra("storeId");
        storeLat = getIntent().getDoubleExtra("store_lat", 0);
        storeLng = getIntent().getDoubleExtra("store_lng", 0);
        deliveryLat = getIntent().getDoubleExtra("delivery_lat", 0);
        deliveryLng = getIntent().getDoubleExtra("delivery_lng", 0);
        currentStatus = getIntent().getIntExtra("orderStatus", 5);

        // Build Firestore document reference if valid.
        if (storeId != null && !storeId.isEmpty() && orderId != null && !orderId.isEmpty()) {
            orderDocRef = firestore.collection("orders").document(storeId)
                    .collection("orderItems").document(orderId);
        } else {
            Log.w("DeliveryMapActivity", "orderId or storeId missing – Firestore updates disabled.");
        }

        btnCancel = findViewById(R.id.btnCancel);
        btnPickedUp = findViewById(R.id.btnPickedUp);
        btnDelivered = findViewById(R.id.btnDelivered);

        btnCancel.setOnClickListener(v -> updateOrderStatus(7));
        btnPickedUp.setOnClickListener(v -> updateOrderStatus(8));
        btnDelivered.setOnClickListener(v -> updateOrderStatus(10));

        updateUIForStatus(currentStatus);

        MapFragment mapFragment = (MapFragment) getFragmentManager().findFragmentById(R.id.mapDelivery);
        mapFragment.getMapAsync(this);
    }

    @Override
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Apply dark map style.
        try {
            boolean success = mMap.setMapStyle(MapStyleOptions.loadRawResourceStyle(this, R.raw.map_style_dark));
            if (!success) {
                Log.e("DeliveryMapActivity", "Style parsing failed.");
            }
        } catch (Exception e) {
            Log.e("DeliveryMapActivity", "Can't find style. Error: ", e);
        }

        // Set marker and camera based on current status.
        if (currentStatus == 5) {
            addOrUpdateDestinationMarker(new LatLng(storeLat, storeLng), "Store");
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(storeLat, storeLng), 14));
        } else if (currentStatus >= 8) {
            addOrUpdateDestinationMarker(new LatLng(deliveryLat, deliveryLng), "Delivery Destination");
            mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(new LatLng(deliveryLat, deliveryLng), 14));
        }

        // Compute and display route from store to delivery.
        fetchRoute(new LatLng(storeLat, storeLng), new LatLng(deliveryLat, deliveryLng));
    }

    private void addOrUpdateDestinationMarker(LatLng latLng, String title) {
        if (destinationMarker == null) {
            destinationMarker = mMap.addMarker(new MarkerOptions()
                    .position(latLng)
                    .title(title)
                    .icon(BitmapDescriptorFactory.defaultMarker(BitmapDescriptorFactory.HUE_RED)));
        } else {
            destinationMarker.setPosition(latLng);
            destinationMarker.setTitle(title);
        }
    }

    private void updateOrderStatus(int newStatus) {
        if (orderDocRef == null) {
            Toast.makeText(this, "Order update disabled – document reference is invalid", Toast.LENGTH_SHORT).show();
            return;
        }
        orderDocRef.get().addOnSuccessListener(documentSnapshot -> {
            if (!documentSnapshot.exists()) {
                Toast.makeText(this, "Order document does not exist", Toast.LENGTH_SHORT).show();
                return;
            }
            orderDocRef.update("status", newStatus)
                    .addOnSuccessListener(aVoid -> {
                        currentStatus = newStatus;
                        updateUIForStatus(newStatus);
                        if (newStatus == 7) {
                            Toast.makeText(this, "Order cancelled", Toast.LENGTH_SHORT).show();
                            finish();
                        } else if (newStatus == 10) {
                            Toast.makeText(this, "Order delivered", Toast.LENGTH_SHORT).show();
                            finish();
                        } else if (newStatus == 8) {
                            addOrUpdateDestinationMarker(new LatLng(deliveryLat, deliveryLng), "Delivery Destination");
                            Toast.makeText(this, "Order picked up", Toast.LENGTH_SHORT).show();
                            fetchRoute(new LatLng(storeLat, storeLng), new LatLng(deliveryLat, deliveryLng));
                        }
                    })
                    .addOnFailureListener(e -> {
                        Toast.makeText(this, "Failed to update order status: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                        Log.e("DeliveryMapActivity", "Update error: ", e);
                    });
        }).addOnFailureListener(e -> {
            Toast.makeText(this, "Failed to get order document: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            Log.e("DeliveryMapActivity", "Get document error: ", e);
        });
    }

    private void updateUIForStatus(int status) {
        if (status == 5) {
            btnCancel.setVisibility(View.VISIBLE);
            btnPickedUp.setVisibility(View.VISIBLE);
            btnDelivered.setVisibility(View.GONE);
        } else if (status == 8) {
            btnCancel.setVisibility(View.GONE);
            btnPickedUp.setVisibility(View.GONE);
            btnDelivered.setVisibility(View.VISIBLE);
        } else {
            btnCancel.setVisibility(View.GONE);
            btnPickedUp.setVisibility(View.GONE);
            btnDelivered.setVisibility(View.GONE);
        }
    }

    // Compute route using Compute Routes API via HTTP POST.
    private void fetchRoute(LatLng origin, LatLng destination) {
        new ComputeRoutesTask().execute(origin, destination);
    }

    private class ComputeRoutesTask extends AsyncTask<LatLng, Void, List<LatLng>> {
        @Override
        protected List<LatLng> doInBackground(LatLng... params) {
            LatLng origin = params[0];
            LatLng dest = params[1];
            try {
                String urlString = "https://routes.googleapis.com/directions/v2:computeRoutes?key=" + API_KEY;
                URL url = new URL(urlString);
                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
                conn.setDoOutput(true);

                JSONObject jsonBody = new JSONObject();

                JSONObject originJson = new JSONObject();
                JSONObject originLoc = new JSONObject();
                originLoc.put("lat", origin.latitude);
                originLoc.put("lng", origin.longitude);
                originJson.put("location", originLoc);
                jsonBody.put("origin", originJson);

                JSONObject destinationJson = new JSONObject();
                JSONObject destinationLoc = new JSONObject();
                destinationLoc.put("lat", dest.latitude);
                destinationLoc.put("lng", dest.longitude);
                destinationJson.put("location", destinationLoc);
                jsonBody.put("destination", destinationJson);

                jsonBody.put("travelMode", "DRIVE");
                jsonBody.put("routingPreference", "TRAFFIC_AWARE");
                jsonBody.put("computeAlternativeRoutes", false);
                jsonBody.put("languageCode", "en-US");
                jsonBody.put("units", "METRIC");

                String requestBody = jsonBody.toString();
                OutputStream os = conn.getOutputStream();
                os.write(requestBody.getBytes("UTF-8"));
                os.close();

                int responseCode = conn.getResponseCode();
                if (responseCode != 200) {
                    Log.e("ComputeRoutesTask", "HTTP error code: " + responseCode);
                    return null;
                }

                BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
                StringBuilder sb = new StringBuilder();
                String line;
                while ((line = br.readLine()) != null) {
                    sb.append(line);
                }
                br.close();
                String response = sb.toString();
                Log.d("ComputeRoutesTask", "Response: " + response);

                return parseRoute(response);

            } catch (Exception e) {
                Log.e("ComputeRoutesTask", "Exception: " + e.getMessage());
            }
            return null;
        }

        @Override
        protected void onPostExecute(List<LatLng> points) {
            if (points != null && !points.isEmpty()) {
                drawRoute(points);
            }
        }
    }

    private List<LatLng> parseRoute(String jsonData) {
        List<LatLng> points = new ArrayList<>();
        try {
            JSONObject jsonObject = new JSONObject(jsonData);
            JSONArray routes = jsonObject.getJSONArray("routes");
            if (routes.length() > 0) {
                JSONObject route = routes.getJSONObject(0);
                JSONObject polylineObj = route.getJSONObject("polyline");
                String encodedPoints = polylineObj.getString("encodedPolyline");
                points = decodePoly(encodedPoints);
            }
        } catch (Exception e) {
            Log.e("parseRoute", "Error: " + e.getMessage());
        }
        return points;
    }

    private void drawRoute(List<LatLng> points) {
        if (routePolyline != null) {
            routePolyline.remove();
        }
        PolylineOptions options = new PolylineOptions().addAll(points)
                .color(getResources().getColor(com.google.android.libraries.places.R.color.quantum_purple700))
                .width(8);
        routePolyline = mMap.addPolyline(options);
    }

    private List<LatLng> decodePoly(String encoded) {
        List<LatLng> poly = new ArrayList<>();
        int index = 0, len = encoded.length();
        int lat = 0, lng = 0;
        while (index < len) {
            int b, shift = 0, result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlat = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lat += dlat;

            shift = 0;
            result = 0;
            do {
                b = encoded.charAt(index++) - 63;
                result |= (b & 0x1f) << shift;
                shift += 5;
            } while (b >= 0x20);
            int dlng = ((result & 1) != 0 ? ~(result >> 1) : (result >> 1));
            lng += dlng;

            LatLng p = new LatLng(((double) lat / 1E5), ((double) lng / 1E5));
            poly.add(p);
        }
        return poly;
    }

    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
        if (item.getItemId() == android.R.id.home) {
            finish(); // Return to DriverPage.
            return true;
        }
        return super.onOptionsItemSelected(item);
    }

    @Override
    public void onBackPressed() {
        finish();
    }
}
