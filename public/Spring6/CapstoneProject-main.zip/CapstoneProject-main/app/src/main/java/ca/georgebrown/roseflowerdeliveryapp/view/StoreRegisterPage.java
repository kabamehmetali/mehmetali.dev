package ca.georgebrown.roseflowerdeliveryapp.view;

import android.Manifest;
import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.ImageDecoder;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.AutoCompleteTextView;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;

import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import com.google.android.gms.tasks.Continuation;
import com.google.android.gms.tasks.Task;
import com.google.android.libraries.places.api.Places;
import com.google.android.libraries.places.api.model.AddressComponent;
import com.google.android.libraries.places.api.model.AddressComponents;
import com.google.android.libraries.places.api.model.Place;
import com.google.android.libraries.places.api.net.FetchPlaceRequest;
import com.google.android.libraries.places.api.net.PlacesClient;
import com.google.android.material.snackbar.Snackbar;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;

import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Locale;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.adapter.PlaceAutoSuggestAdapter;
import ca.georgebrown.roseflowerdeliveryapp.model.Location;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;


public class StoreRegisterPage extends AppCompatActivity {

    private static final String TAG = "StoreRegisterPage";
    private static final int READ_EXTERNAL_STORAGE_REQUEST = 100;

    // UI Elements
    private ImageView storeImagePreview;
    private EditText ownerNameInput, ownerLastNameInput, emailRegisterInput,
            passwordRegisterInput, dateOfBirthInput, storeNameInput, businessNumberInput, storePhoneNumberInput;
    private AutoCompleteTextView storeAddressInput;
    private CheckBox termsCheckBox;
    private Button storeRegisterBtn;

    // Google Places API objects
    private PlacesClient placesClient;
    private PlaceAutoSuggestAdapter autoSuggestAdapter;
    private Location selectedLocation;

    // Firebase instances
    private FirebaseAuth auth;
    private FirebaseFirestore db;
    private StorageReference storageReference;

    // ActivityResultLauncher for image picking
    private final ActivityResultLauncher<Intent> documentLauncher =
            registerForActivityResult(new ActivityResultContracts.StartActivityForResult(), result -> {
                if (result.getResultCode() == RESULT_OK && result.getData() != null) {
                    Uri imageData = result.getData().getData();
                    try {
                        getContentResolver().takePersistableUriPermission(
                                imageData,
                                Intent.FLAG_GRANT_READ_URI_PERMISSION
                        );
                        Bitmap selectedImage;
                        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                            ImageDecoder.Source source = ImageDecoder.createSource(getContentResolver(), imageData);
                            selectedImage = ImageDecoder.decodeBitmap(source);
                        } else {
                            selectedImage = MediaStore.Images.Media.getBitmap(getContentResolver(), imageData);
                        }
                        Picasso.get().load(imageData).into(storeImagePreview);
                        storeImagePreview.setTag(imageData);
                        Log.d(TAG, "Image selected successfully: " + imageData.toString());
                    } catch (Exception e) {
                        showError("Error loading image: " + e.getMessage());
                        Log.e(TAG, "Error loading image", e);
                    }
                }
            });

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_store_register_page);

        View main = findViewById(R.id.main);
        if (main != null) {
            ViewCompat.setOnApplyWindowInsetsListener(main, (v, insets) -> {
                Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
                v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
                return insets;
            });
        }

        auth = FirebaseAuth.getInstance();
        db = FirebaseFirestore.getInstance();
        storageReference = FirebaseStorage.getInstance().getReference();

        if (!Places.isInitialized()) {
            Places.initialize(getApplicationContext(), getString(R.string.google_maps_key), Locale.getDefault());
        }
        placesClient = Places.createClient(this);

        storeImagePreview = findViewById(R.id.storeImagePreview);
        ownerNameInput = findViewById(R.id.ownerNameInput);
        ownerLastNameInput = findViewById(R.id.ownerLastNameInput);
        emailRegisterInput = findViewById(R.id.emailRegisterInput);
        passwordRegisterInput = findViewById(R.id.passwordRegisterInput);
        dateOfBirthInput = findViewById(R.id.dateOfBirthInput);
        storeNameInput = findViewById(R.id.storeNameInput);
        businessNumberInput = findViewById(R.id.businessNumberInput);
        storePhoneNumberInput = findViewById(R.id.storePhoneNumberInput);
        storeAddressInput = findViewById(R.id.storeAddressInput);
        termsCheckBox = findViewById(R.id.termsCheckBox);
        storeRegisterBtn = findViewById(R.id.storeRegisterBtn);

        // Setup DatePicker for Date of Birth with age verification (min age 18)
        // Default and max selectable date is today - 18 years.
        Calendar maxDate = Calendar.getInstance();
        maxDate.add(Calendar.YEAR, -18);
        dateOfBirthInput.setText(new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(maxDate.getTime()));
        dateOfBirthInput.setFocusable(false);
        dateOfBirthInput.setClickable(true);
        dateOfBirthInput.setOnClickListener(v -> showDatePickerDialog());

        storeImagePreview.setOnClickListener(this::selectImage);
        storeRegisterBtn.setOnClickListener(this::registerStore);

        autoSuggestAdapter = new PlaceAutoSuggestAdapter(this, android.R.layout.simple_dropdown_item_1line, placesClient);
        storeAddressInput.setAdapter(autoSuggestAdapter);
        storeAddressInput.setThreshold(1);
        storeAddressInput.setOnItemClickListener((parent, view, position, id) -> {
            String selectedPlaceId = autoSuggestAdapter.getPlaceId(position);
            fetchPlaceDetails(selectedPlaceId);
        });
    }

    /**
     * Displays a DatePickerDialog configured so that the maximum selectable date is (today - 18 years).
     * If the selected date is after (today - 18 years), a Toast notifies the user that they must be at least 18.
     */
    private void showDatePickerDialog() {
        // Set maxDate to today - 18 years.
        Calendar maxDate = Calendar.getInstance();
        maxDate.add(Calendar.YEAR, -18);
        int defaultYear = maxDate.get(Calendar.YEAR);
        int defaultMonth = maxDate.get(Calendar.MONTH);
        int defaultDay = maxDate.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(
                StoreRegisterPage.this,
                (DatePicker view, int selectedYear, int selectedMonth, int selectedDay) -> {
                    Calendar selectedDate = Calendar.getInstance();
                    selectedDate.set(selectedYear, selectedMonth, selectedDay);
                    // Create calendar for 18 years ago from today
                    Calendar eighteenYearsAgo = Calendar.getInstance();
                    eighteenYearsAgo.add(Calendar.YEAR, -18);
                    if (selectedDate.after(eighteenYearsAgo)) {
                        Toast.makeText(StoreRegisterPage.this, "You must be at least 18 years old.", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
                    dateOfBirthInput.setText(format.format(selectedDate.getTime()));
                },
                defaultYear, defaultMonth, defaultDay);
        // Prevent selection of a date that would make the user younger than 18
        datePickerDialog.getDatePicker().setMaxDate(maxDate.getTimeInMillis());
        datePickerDialog.show();
    }

    /**
     * Checks and requests the proper permission for image selection.
     */
    public void selectImage(View view) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_MEDIA_IMAGES},
                        READ_EXTERNAL_STORAGE_REQUEST);
                return;
            }
        } else {
            if (ContextCompat.checkSelfPermission(this, Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                ActivityCompat.requestPermissions(this,
                        new String[]{Manifest.permission.READ_EXTERNAL_STORAGE},
                        READ_EXTERNAL_STORAGE_REQUEST);
                return;
            }
        }
        launchImagePicker();
    }

    private void launchImagePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        documentLauncher.launch(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == READ_EXTERNAL_STORAGE_REQUEST) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                launchImagePicker();
            } else {
                Toast.makeText(this, "Permission required to select an image.", Toast.LENGTH_SHORT).show();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }

    public void registerStore(View view) {
        Button btn = findViewById(R.id.storeRegisterBtn);
        btn.setEnabled(false);
        String ownerFirstName = ownerNameInput.getText().toString().trim();
        String ownerLastName = ownerLastNameInput.getText().toString().trim();
        String email = emailRegisterInput.getText().toString().trim();
        String password = passwordRegisterInput.getText().toString().trim();
        String dateOfBirth = dateOfBirthInput.getText().toString().trim();
        String storeName = storeNameInput.getText().toString().trim();
        String businessNumber = businessNumberInput.getText().toString().trim();
        String phoneNumber = storePhoneNumberInput.getText().toString().trim();
        String storeAddress = storeAddressInput.getText().toString().trim();
        boolean termsAccepted = termsCheckBox.isChecked();

        if (ownerFirstName.isEmpty() || ownerLastName.isEmpty() || email.isEmpty() ||
                password.isEmpty() || dateOfBirth.isEmpty() || storeName.isEmpty() ||
                businessNumber.isEmpty() || phoneNumber.isEmpty() || storeAddress.isEmpty() ||
                selectedLocation == null) {
            btn.setEnabled(true);
            Toast.makeText(this, "Please fill in all required fields.", Toast.LENGTH_SHORT).show();
            return;
        }
        if (!termsAccepted) {
            btn.setEnabled(true);
            Toast.makeText(this, "You must agree to the Terms and Conditions.", Toast.LENGTH_SHORT).show();
            return;
        }
        // Ensure image is selected; registration will not proceed without it.
        if (storeImagePreview.getTag() == null) {
            btn.setEnabled(true);
            Toast.makeText(this, "Image is required.", Toast.LENGTH_SHORT).show();
            return;
        }

        auth.createUserWithEmailAndPassword(email, password)
                .addOnCompleteListener(this, task -> {
                    if (task.isSuccessful()) {
                        FirebaseUser firebaseUser = auth.getCurrentUser();
                        if (firebaseUser != null) {
                            Users storeUser = new Users();
                            storeUser.setRole(3);
                            storeUser.setFirstName(ownerFirstName);
                            storeUser.setLastName(ownerLastName);
                            storeUser.setEmail(email);
                            storeUser.setPassword(password);
                            storeUser.setDateOfBirth(dateOfBirth);
                            storeUser.setStoreName(storeName);
                            storeUser.setBusinessNumber(businessNumber);
                            storeUser.setPhoneNumber(phoneNumber);
                            storeUser.setStoreLocation(selectedLocation);
                            storeUser.setAcceptedTerms(termsAccepted);

                            // Upload image first
                            Uri imageUri = (Uri) storeImagePreview.getTag();
                            uploadImage(imageUri, firebaseUser.getUid(), storeUser);
                        } else {
                            Log.e(TAG, "FirebaseUser is null after account creation.");
                            btn.setEnabled(true);
                        }
                    } else {
                        Toast.makeText(StoreRegisterPage.this, "Authentication failed: " +
                                task.getException().getMessage(), Toast.LENGTH_LONG).show();
                        Log.e(TAG, "Authentication failed", task.getException());
                        btn.setEnabled(true);
                    }
                });
    }

    private void uploadImage(Uri imageUri, String uid, Users storeUser) {
        StorageReference imageRef = storageReference.child("store_images/" + uid + ".jpg");
        UploadTask uploadTask = imageRef.putFile(imageUri);

        uploadTask.continueWithTask((Continuation<UploadTask.TaskSnapshot, Task<Uri>>) task -> {
            if (!task.isSuccessful()) {
                Log.e(TAG, "Image upload failed", task.getException());
                throw task.getException();
            }
            return imageRef.getDownloadUrl();
        }).addOnSuccessListener(uri -> {
            String downloadUrl = uri.toString();
            storeUser.setImageUrl(downloadUrl);
            Log.d(TAG, "Image uploaded. Download URL: " + downloadUrl);
            saveUserToFirestore(uid, storeUser);
        }).addOnFailureListener(e -> {
            showError("Image upload failed: " + e.getMessage());
            Log.e(TAG, "Image upload failed", e);
        });
    }

    private void saveUserToFirestore(String uid, Users storeUser) {
        db.collection("users").document(uid)
                .set(storeUser)
                .addOnSuccessListener(aVoid -> {
                    Toast.makeText(StoreRegisterPage.this, "Store registration successful!", Toast.LENGTH_SHORT).show();
                    Log.d(TAG, "User data saved to Firestore.");
                    Intent intent = new Intent(StoreRegisterPage.this, StorePage.class);
                    startActivity(intent);
                    finish();
                })
                .addOnFailureListener(e -> {
                    showError("Registration failed: " + e.getMessage());
                    Log.e(TAG, "Failed to save user data", e);
                });
    }

    private void fetchPlaceDetails(String placeId) {
        FetchPlaceRequest request = FetchPlaceRequest.newInstance(placeId, Arrays.asList(
                Place.Field.ID, Place.Field.NAME, Place.Field.ADDRESS,
                Place.Field.LAT_LNG, Place.Field.ADDRESS_COMPONENTS
        ));
        placesClient.fetchPlace(request)
                .addOnSuccessListener(response -> {
                    Place place = response.getPlace();
                    if (place.getLatLng() != null) {
                        selectedLocation = new Location();
                        selectedLocation.setPlaceId(placeId);
                        selectedLocation.setFormattedAddress(place.getAddress());
                        selectedLocation.setLatitude(place.getLatLng().latitude);
                        selectedLocation.setLongitude(place.getLatLng().longitude);
                        AddressComponents components = place.getAddressComponents();
                        if (components != null) {
                            for (AddressComponent component : components.asList()) {
                                if (component.getTypes().contains("postal_code")) {
                                    selectedLocation.setPostalCode(component.getName());
                                } else if (component.getTypes().contains("locality")) {
                                    selectedLocation.setCity(component.getName());
                                } else if (component.getTypes().contains("country")) {
                                    selectedLocation.setCountry(component.getName());
                                }
                            }
                        }
                        Log.d(TAG, "Selected location: " + selectedLocation.getFormattedAddress());
                    }
                })
                .addOnFailureListener(e -> {
                    Toast.makeText(StoreRegisterPage.this, "Failed to fetch address details.", Toast.LENGTH_SHORT).show();
                    Log.e(TAG, "Failed to fetch address details", e);
                });
    }

    public void backBtn(View view) {
        Intent intent = new Intent(StoreRegisterPage.this, LoginPage.class);
        startActivity(intent);
        finish();
    }

    private void showError(String message) {
        Snackbar.make(findViewById(R.id.main), message, Snackbar.LENGTH_LONG).show();
    }
}
