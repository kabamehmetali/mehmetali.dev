package ca.georgebrown.roseflowerdeliveryapp.utils;

import android.content.Context;
import android.os.Handler;
import android.util.Log;

import com.google.firebase.Timestamp;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.GeoPoint;

import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.model.Order;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseOrderRepository;

public class DriverAssignmentManager {

    private static final String TAG = "DriverAssignmentManager";
    private static final int MAX_ASSIGN_ATTEMPTS = 5;
    private Context context;
    private FirebaseFirestore firestore;
    private FirebaseOrderRepository orderRepository;
    private int attemptCount = 0;

    public DriverAssignmentManager(Context context) {
        this.context = context;
        firestore = FirebaseFirestore.getInstance();
        orderRepository = new FirebaseOrderRepository();
    }

    /**
     * Starts the driver assignment process for the given order.
     *
     * @param storeId       The store's Firestore document id.
     * @param order         The order that needs a driver.
     * @param storeLocation The store's location as a GeoPoint.
     */
    public void assignDriver(final String storeId, final Order order, final GeoPoint storeLocation) {
        attemptCount = 0;
        Log.d(TAG, "Assigning driver for order " + order.getId() + " from store " + storeId);
        searchAndAssignDriver(storeId, order, storeLocation);
    }

    /**
     * Queries the "drivers" collection for available drivers.
     * Checks that each driver:
     *   – is accepting orders,
     *   – has a valid GeoPoint location,
     *   – is not the store (skips if driverId equals storeId).
     * Chooses the driver with the smallest distance from the store.
     * Then updates the order with the assigned driver and sets its status to 4 ("Ready for Pickup").
     */
    private void searchAndAssignDriver(final String storeId, final Order order, final GeoPoint storeLocation) {
        firestore.collection("drivers")
                .get()
                .addOnSuccessListener((QuerySnapshot queryDocumentSnapshots) -> {
                    List<DocumentSnapshot> driverDocs = queryDocumentSnapshots.getDocuments();
                    Log.d(TAG, "Found " + driverDocs.size() + " driver documents from drivers collection.");
                    if (driverDocs.isEmpty()) {
                        handleNoDriverFound(storeId, order, storeLocation);
                        return;
                    }

                    DocumentSnapshot closestDriverDoc = null;
                    double minDistance = Double.MAX_VALUE;

                    for (DocumentSnapshot doc : driverDocs) {
                        if (!doc.exists()) continue;
                        String driverId = doc.getId();
                        if (driverId.equals(storeId)) {
                            Log.d(TAG, "Skipping driver " + driverId + " because it equals the store id.");
                            continue;
                        }
                        Object acceptingObj = doc.get("acceptingOrders");
                        boolean accepting = false;
                        if (acceptingObj instanceof Boolean) {
                            accepting = (Boolean) acceptingObj;
                        } else if (acceptingObj instanceof Number) {
                            accepting = ((Number) acceptingObj).intValue() != 0;
                        } else if (acceptingObj instanceof String) {
                            accepting = Boolean.parseBoolean((String) acceptingObj);
                        } else {
                            Log.e(TAG, "Driver " + driverId + " has invalid acceptingOrders value: " + acceptingObj);
                            continue;
                        }
                        if (!accepting) {
                            Log.d(TAG, "Skipping driver " + driverId + " because acceptingOrders is false.");
                            continue;
                        }
                        GeoPoint driverLocation = doc.getGeoPoint("location");
                        if (driverLocation == null) {
                            Log.e(TAG, "Driver " + driverId + " has no valid location.");
                            continue;
                        }
                        double distance = haversineDistance(
                                storeLocation.getLatitude(), storeLocation.getLongitude(),
                                driverLocation.getLatitude(), driverLocation.getLongitude());
                        Log.d(TAG, "Driver " + driverId + " at (" + driverLocation.getLatitude() + ", " +
                                driverLocation.getLongitude() + ") is " + distance + " km away.");
                        if (distance < minDistance) {
                            minDistance = distance;
                            closestDriverDoc = doc;
                        }
                    }

                    if (closestDriverDoc == null) {
                        Log.d(TAG, "No suitable driver found after checking all documents.");
                        handleNoDriverFound(storeId, order, storeLocation);
                        return;
                    }

                    final String driverId = closestDriverDoc.getId();
                    Log.d(TAG, "Closest driver found: " + driverId + " with distance " + minDistance + " km.");
                    // Update the order with the assigned driver and set status = 4 ("Ready for Pickup").
                    orderRepository.updateOrderAssignedDriver(storeId, order.getId(), driverId, new FirebaseOrderRepository.StatusUpdateCallback() {
                        @Override
                        public void onStatusUpdated() {
                            Log.d(TAG, "Order " + order.getId() + " updated with assigned driver " + driverId);
                            orderRepository.updateOrderStatus(storeId, order.getId(), 4, new FirebaseOrderRepository.StatusUpdateCallback() {
                                @Override
                                public void onStatusUpdated() {
                                    Log.d(TAG, "Order " + order.getId() + " status set to 'Ready for Pickup' (4)");
                                }
                                @Override
                                public void onError(Exception e) {
                                    Log.e(TAG, "Error updating order status to 4: " + e.getMessage());
                                }
                            });
                        }
                        @Override
                        public void onError(Exception e) {
                            Log.e(TAG, "Error updating assigned driver for order " + order.getId() + ": " + e.getMessage());
                        }
                    });
                })
                .addOnFailureListener(e -> {
                    Log.e(TAG, "Failed to query driver documents: " + e.getMessage());
                    handleNoDriverFound(storeId, order, storeLocation);
                });
    }

    private void handleNoDriverFound(final String storeId, final Order order, final GeoPoint storeLocation) {
        attemptCount++;
        Log.d(TAG, "handleNoDriverFound attempt " + attemptCount + " for order " + order.getId());
        if (attemptCount < MAX_ASSIGN_ATTEMPTS) {
            new Handler().postDelayed(() -> searchAndAssignDriver(storeId, order, storeLocation), 5000);
        } else {
            orderRepository.updateOrderStatus(storeId, order.getId(), 7, new FirebaseOrderRepository.StatusUpdateCallback() {
                @Override
                public void onStatusUpdated() {
                    Log.d(TAG, "Order " + order.getId() + " cancelled due to no available drivers.");
                }
                @Override
                public void onError(Exception e) {
                    Log.e(TAG, "Error updating order status to cancelled: " + e.getMessage());
                }
            });
        }
    }

    /**
     * Haversine formula to calculate the distance (in kilometers) between two geo-points.
     */
    private double haversineDistance(double lat1, double lon1, double lat2, double lon2) {
        final int R = 6371; // Earth's radius in km
        double latDistance = Math.toRadians(lat2 - lat1);
        double lonDistance = Math.toRadians(lon2 - lon1);
        double a = Math.sin(latDistance / 2) * Math.sin(latDistance / 2)
                + Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2))
                * Math.sin(lonDistance / 2) * Math.sin(lonDistance / 2);
        double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
        return R * c;
    }

    /**
     * Called when the driver picks up the order.
     */
    public void driverPickedUpOrder(final String storeId, final Order order) {
        orderRepository.updateOrderPickup(storeId, order.getId(), Timestamp.now(), new FirebaseOrderRepository.StatusUpdateCallback() {
            @Override
            public void onStatusUpdated() {
                Log.d(TAG, "Order " + order.getId() + " pickup confirmed.");
            }
            @Override
            public void onError(Exception e) {
                Log.e(TAG, "Error updating pickup time: " + e.getMessage());
            }
        });
    }
}
