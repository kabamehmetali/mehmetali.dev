package ca.georgebrown.roseflowerdeliveryapp.model;

import com.google.firebase.Timestamp;
import java.io.Serializable;
import java.util.List;

public class Order implements Serializable {

    private String id;              // Firestore document ID
    private String userId;          // ID of the user who placed the order
    private String userName;        // Name of the user who placed the order
    private List<CartItem> orderItems;
    private int status;             // 1 = New, 2 = Accepted, 3 = Rejected, 4 = Completed, 5 = Driver Accepted, 6 = Driver Rejected, 7 = Cancelled, 8 = Picked Up
    private Timestamp timestamp;

    // New fields for driver assignment
    private String assignedDriverId;
    private Timestamp pickupTimestamp;

    // New field to store the delivery location (to avoid Firestore mapping errors)
    private Location deliveryLocation;

    public Order() {
    }

    public Order(String userId, String userName, List<CartItem> orderItems, int status, Timestamp timestamp) {
        this.userId = userId;
        this.userName = userName;
        this.orderItems = orderItems;
        this.status = status;
        this.timestamp = timestamp;
    }

    // Getters and setters for existing fields
    public String getId() {
        return id;
    }
    public void setId(String id) {
        this.id = id;
    }
    public String getUserId() {
        return userId;
    }
    public void setUserId(String userId) {
        this.userId = userId;
    }
    public String getUserName() {
        return userName;
    }
    public void setUserName(String userName) {
        this.userName = userName;
    }
    public List<CartItem> getOrderItems() {
        return orderItems;
    }
    public void setOrderItems(List<CartItem> orderItems) {
        this.orderItems = orderItems;
    }
    public int getStatus() {
        return status;
    }
    public void setStatus(int status) {
        this.status = status;
    }
    public Timestamp getTimestamp() {
        return timestamp;
    }
    public void setTimestamp(Timestamp timestamp) {
        this.timestamp = timestamp;
    }

    // Getters and setters for new fields
    public String getAssignedDriverId() {
        return assignedDriverId;
    }
    public void setAssignedDriverId(String assignedDriverId) {
        this.assignedDriverId = assignedDriverId;
    }
    public Timestamp getPickupTimestamp() {
        return pickupTimestamp;
    }
    public void setPickupTimestamp(Timestamp pickupTimestamp) {
        this.pickupTimestamp = pickupTimestamp;
    }
    public Location getDeliveryLocation() {
        return deliveryLocation;
    }
    public void setDeliveryLocation(Location deliveryLocation) {
        this.deliveryLocation = deliveryLocation;
    }
}
