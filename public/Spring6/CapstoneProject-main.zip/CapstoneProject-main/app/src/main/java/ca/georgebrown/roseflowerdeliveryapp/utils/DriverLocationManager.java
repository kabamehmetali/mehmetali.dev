package ca.georgebrown.roseflowerdeliveryapp.utils;

import android.Manifest;
import android.content.Context;
import android.content.pm.PackageManager;
import android.location.Location;
import android.os.Looper;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.core.app.ActivityCompat;

import com.google.android.gms.location.FusedLocationProviderClient;
import com.google.android.gms.location.LocationCallback;
import com.google.android.gms.location.LocationRequest;
import com.google.android.gms.location.LocationResult;
import com.google.android.gms.location.LocationServices;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;
import com.google.firebase.firestore.SetOptions;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class DriverLocationManager {

    // Listener interface to notify caller of update errors.
    public interface LocationUpdateListener {
        void onLocationUpdateError(String errorMessage);
    }

    private static DriverLocationManager instance;
    private final Context context;
    private final FusedLocationProviderClient fusedLocationClient;
    private final FirebaseFirestore firestore;
    private final String driverId;
    private boolean isUpdatingLocation = false;
    private LocationUpdateListener locationUpdateListener;

    private final LocationCallback locationCallback = new LocationCallback() {
        @Override
        public void onLocationResult(@NonNull LocationResult locationResult) {
            if (locationResult == null || driverId == null) {
                return;
            }
            for (Location location : locationResult.getLocations()) {
                if (location != null) {
                    updateDriverLocation(location);
                }
            }
        }
    };

    private DriverLocationManager(Context context) {
        this.context = context.getApplicationContext();
        fusedLocationClient = LocationServices.getFusedLocationProviderClient(this.context);
        firestore = FirebaseFirestore.getInstance();
        driverId = FirebaseAuth.getInstance().getUid();
    }

    public static synchronized DriverLocationManager getInstance(Context context) {
        if (instance == null) {
            instance = new DriverLocationManager(context);
        }
        return instance;
    }

    /**
     * Sets a listener to be notified if a location update fails.
     */
    public void setLocationUpdateListener(LocationUpdateListener listener) {
        this.locationUpdateListener = listener;
    }

    /**
     * Starts location updates every 10 seconds.
     * Ensure location permissions are granted before calling.
     */
    public void startLocationUpdates() {
        if (isUpdatingLocation) {
            return;
        }

        LocationRequest locationRequest = LocationRequest.create();
        locationRequest.setInterval(10000); // 10 seconds
        locationRequest.setFastestInterval(5000);
        locationRequest.setPriority(LocationRequest.PRIORITY_HIGH_ACCURACY);

        if (ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != PackageManager.PERMISSION_GRANTED &&
                ActivityCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != PackageManager.PERMISSION_GRANTED) {
            Log.e("DriverLocationManager", "Location permissions are not granted.");
            if (locationUpdateListener != null) {
                locationUpdateListener.onLocationUpdateError("Location permissions are not granted.");
            }
            return;
        }
        fusedLocationClient.requestLocationUpdates(locationRequest, locationCallback, Looper.getMainLooper());
        isUpdatingLocation = true;
        Log.d("DriverLocationManager", "Location updates started.");
    }

    /**
     * Stops the location updates.
     */
    public void stopLocationUpdates() {
        if (!isUpdatingLocation) {
            return;
        }
        fusedLocationClient.removeLocationUpdates(locationCallback);
        isUpdatingLocation = false;
        Log.d("DriverLocationManager", "Location updates stopped.");
    }

    /**
     * Updates the driver's location in Firestore under the "drivers" collection.
     * Also adds a "lastUpdated" field (formatted timestamp). Uses set() with merge.
     */
    private void updateDriverLocation(Location location) {
        double latitude = location.getLatitude();
        double longitude = location.getLongitude();
        if (driverId == null) {
            Log.e("DriverLocationManager", "Driver ID is null. Cannot update location.");
            if (locationUpdateListener != null) {
                locationUpdateListener.onLocationUpdateError("Driver ID is null.");
            }
            return;
        }

        // Format the current time as a readable string.
        String currentTime = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault()).format(new Date());

        // Prepare the location data.
        Map<String, Object> data = new HashMap<>();
        data.put("location", new GeoPoint(latitude, longitude));
        data.put("lastUpdated", currentTime);

        firestore.collection("drivers").document(driverId)
                .set(data, SetOptions.merge())
                .addOnSuccessListener(aVoid ->
                        Log.d("DriverLocationManager", "Location updated: (" + latitude + ", " + longitude + ") at " + currentTime)
                )
                .addOnFailureListener(e -> {
                    Log.e("DriverLocationManager", "Failed to update location: " + e.getMessage());
                    if (locationUpdateListener != null) {
                        locationUpdateListener.onLocationUpdateError(e.getMessage());
                    }
                });
    }
}
