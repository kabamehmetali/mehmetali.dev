package ca.georgebrown.roseflowerdeliveryapp.view.ui.home;

import android.os.Bundle;
import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.DialogFragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import com.squareup.picasso.Picasso;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;

public class ClientStoreItemDetailFragment extends DialogFragment {

    private static final String ARG_ITEM = "item";
    private Item item;

    public ClientStoreItemDetailFragment() {
        // Required empty public constructor.
    }

    public static ClientStoreItemDetailFragment newInstance(Item item) {
        ClientStoreItemDetailFragment fragment = new ClientStoreItemDetailFragment();
        Bundle args = new Bundle();
        args.putSerializable(ARG_ITEM, item); // Ensure Item implements Serializable
        fragment.setArguments(args);
        return fragment;
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (getArguments() != null) {
            item = (Item) getArguments().getSerializable(ARG_ITEM);
        }
        // Optional: set a style for the dialog
        setStyle(DialogFragment.STYLE_NORMAL, R.style.Theme_RoseFlowerDeliveryApp);
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_client_store_item_detail, container, false);
        ImageView ivItemImage = view.findViewById(R.id.ivItemImage);
        TextView tvItemName = view.findViewById(R.id.tvItemName);
        TextView tvItemPrice = view.findViewById(R.id.tvItemPrice);
        TextView tvItemDescription = view.findViewById(R.id.tvItemDescription);

        if (item != null) {
            tvItemName.setText(item.getName());
            tvItemPrice.setText("$" + item.getPrice());
            tvItemDescription.setText(item.getDescription());
            if (item.getImageUrl() != null && !item.getImageUrl().isEmpty()) {
                Picasso.get().load(item.getImageUrl()).into(ivItemImage);
            }
        }
        return view;
    }
}
