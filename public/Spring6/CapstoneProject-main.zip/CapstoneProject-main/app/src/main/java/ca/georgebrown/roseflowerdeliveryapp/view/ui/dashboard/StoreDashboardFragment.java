package ca.georgebrown.roseflowerdeliveryapp.view.ui.dashboard;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.appcompat.widget.SwitchCompat;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.ViewModelProvider;

import ca.georgebrown.roseflowerdeliveryapp.databinding.StoreFragmentDashboardBinding;
import ca.georgebrown.roseflowerdeliveryapp.view.StorePage;

public class StoreDashboardFragment extends Fragment {

    private StoreFragmentDashboardBinding binding;
    // Initial status assumed true (store is accepting orders)
    private boolean isAcceptingOrders = true;

    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        StoreDashboardViewModel dashboardViewModel =
                new ViewModelProvider(this).get(StoreDashboardViewModel.class);

        binding = StoreFragmentDashboardBinding.inflate(inflater, container, false);
        View root = binding.getRoot();

        // Set up the SwitchCompat toggle.
        SwitchCompat switchAcceptingOrders = binding.switchAcceptingOrders;
        switchAcceptingOrders.setChecked(isAcceptingOrders);
        switchAcceptingOrders.setOnCheckedChangeListener((buttonView, isChecked) -> {
            isAcceptingOrders = isChecked;
            // Inform the parent activity (StorePage) about the status change.
            if (getActivity() instanceof StorePage) {
                ((StorePage) getActivity()).setAcceptingOrders(isAcceptingOrders);
            }
        });

        return root;
    }

    @Override
    public void onDestroyView() {
        super.onDestroyView();
        binding = null;
    }
}
