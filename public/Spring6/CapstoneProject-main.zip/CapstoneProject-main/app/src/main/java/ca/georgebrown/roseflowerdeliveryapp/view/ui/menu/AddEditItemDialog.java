package ca.georgebrown.roseflowerdeliveryapp.view.ui.menu;

import android.Manifest;
import android.app.Dialog;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Toast;
import androidx.activity.result.ActivityResultLauncher;
import androidx.activity.result.contract.ActivityResultContracts;
import androidx.annotation.NonNull;
import androidx.appcompat.app.AlertDialog;
import androidx.core.content.ContextCompat;
import androidx.fragment.app.DialogFragment;
import com.squareup.picasso.Picasso;
import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.model.Item;

public class AddEditItemDialog extends DialogFragment {

    public interface ItemDialogListener {
        void onItemSaved(String categoryId, Item item, Uri localImageUri);
    }

    private Item item; // Null if adding a new item.
    private String categoryId;
    private ItemDialogListener listener;
    private Uri selectedImageUri;
    private ImageView ivItemImage;
    private ActivityResultLauncher<Intent> imagePickerLauncher;

    public static AddEditItemDialog newInstance(Item item, String categoryId) {
        AddEditItemDialog dialog = new AddEditItemDialog();
        dialog.item = item;
        dialog.categoryId = categoryId;
        dialog.setCancelable(true);
        return dialog;
    }

    @Override
    public void onAttach(@NonNull Context context) {
        super.onAttach(context);
        if (getTargetFragment() instanceof ItemDialogListener) {
            listener = (ItemDialogListener) getTargetFragment();
        } else if (context instanceof ItemDialogListener) {
            listener = (ItemDialogListener) context;
        } else {
            throw new RuntimeException("Must implement ItemDialogListener");
        }
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        imagePickerLauncher = registerForActivityResult(
                new ActivityResultContracts.StartActivityForResult(),
                result -> {
                    if (result.getResultCode() == getActivity().RESULT_OK && result.getData() != null) {
                        Uri imageData = result.getData().getData();
                        if (imageData != null) {
                            selectedImageUri = imageData;
                            Picasso.get().load(imageData).into(ivItemImage);
                        }
                    }
                }
        );
    }

    @NonNull
    @Override
    public Dialog onCreateDialog(Bundle savedInstanceState) {
        LayoutInflater inflater = LayoutInflater.from(getContext());
        View view = inflater.inflate(R.layout.dialog_add_edit_item, null);

        EditText etItemName = view.findViewById(R.id.etItemName);
        EditText etItemDescription = view.findViewById(R.id.etItemDescription);
        EditText etItemPrice = view.findViewById(R.id.etItemPrice);
        EditText etItemPriority = view.findViewById(R.id.etItemPriority);
        EditText etFlowerType = view.findViewById(R.id.etFlowerType);
        EditText etFlowerColor = view.findViewById(R.id.etFlowerColor);
        EditText etBouquetSize = view.findViewById(R.id.etBouquetSize);
        CheckBox cbItemAvailable = view.findViewById(R.id.cbItemAvailable);
        ivItemImage = view.findViewById(R.id.ivItemImage);
        Button btnSave = view.findViewById(R.id.btnSaveItem);
        Button btnCancel = view.findViewById(R.id.btnCancelItem);

        if (item != null) {
            etItemName.setText(item.getName());
            etItemDescription.setText(item.getDescription());
            etItemPrice.setText(String.valueOf(item.getPrice()));
            etItemPriority.setText(String.valueOf(item.getPriority()));
            etFlowerType.setText(item.getFlowerType());
            etFlowerColor.setText(item.getFlowerColor());
            etBouquetSize.setText(item.getBouquetSize());
            cbItemAvailable.setChecked(item.isAvailable());
            if (!TextUtils.isEmpty(item.getImageUrl())) {
                Picasso.get().load(item.getImageUrl()).placeholder(R.drawable.pictureselect).into(ivItemImage);
            }
        } else {
            cbItemAvailable.setChecked(true);
        }

        ivItemImage.setOnClickListener(v -> checkPermissionAndSelectImage());

        btnSave.setOnClickListener(v -> {
            String name = etItemName.getText().toString().trim();
            String description = etItemDescription.getText().toString().trim();
            String priceStr = etItemPrice.getText().toString().trim();
            String priorityStr = etItemPriority.getText().toString().trim();
            String flowerType = etFlowerType.getText().toString().trim();
            String flowerColor = etFlowerColor.getText().toString().trim();
            String bouquetSize = etBouquetSize.getText().toString().trim();
            boolean available = cbItemAvailable.isChecked();

            if (TextUtils.isEmpty(name) || TextUtils.isEmpty(priceStr) || TextUtils.isEmpty(priorityStr)) {
                Toast.makeText(getContext(), "Please fill required fields", Toast.LENGTH_SHORT).show();
                return;
            }

            double price;
            int priority;
            try {
                price = Double.parseDouble(priceStr);
                priority = Integer.parseInt(priorityStr);
            } catch (NumberFormatException e) {
                Toast.makeText(getContext(), "Invalid number format", Toast.LENGTH_SHORT).show();
                return;
            }

            // When editing, preserve the existing imageUrl if no new image is selected.
            if (item == null) {
                item = new Item();
                item.setCategoryId(categoryId);
            } else if (selectedImageUri == null && !TextUtils.isEmpty(item.getImageUrl())) {
                // Do nothing; the existing imageUrl remains.
            }
            item.setName(name);
            item.setDescription(description);
            item.setPrice(price);
            item.setPriority(priority);
            item.setFlowerType(flowerType);
            item.setFlowerColor(flowerColor);
            item.setBouquetSize(bouquetSize);
            item.setAvailable(available);

            if (listener != null) {
                listener.onItemSaved(categoryId, item, selectedImageUri);
            }
            dismiss();
        });


        btnCancel.setOnClickListener(v -> dismiss());

        AlertDialog.Builder builder = new AlertDialog.Builder(getActivity());
        builder.setView(view);
        return builder.create();
    }

    private void checkPermissionAndSelectImage() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_MEDIA_IMAGES)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_MEDIA_IMAGES}, 101);
                return;
            }
        } else {
            if (ContextCompat.checkSelfPermission(getContext(), Manifest.permission.READ_EXTERNAL_STORAGE)
                    != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 101);
                return;
            }
        }
        launchImagePicker();
    }

    private void launchImagePicker() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("image/*");
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION | Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        imagePickerLauncher.launch(intent);
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions,
                                           @NonNull int[] grantResults) {
        if (requestCode == 101) {
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                launchImagePicker();
            } else {
                Toast.makeText(getContext(), "Permission required to select an image", Toast.LENGTH_SHORT).show();
            }
        } else {
            super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        }
    }
}
