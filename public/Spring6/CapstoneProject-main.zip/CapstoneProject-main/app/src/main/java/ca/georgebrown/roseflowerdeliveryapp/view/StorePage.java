package ca.georgebrown.roseflowerdeliveryapp.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.view.View;

import androidx.appcompat.app.AppCompatActivity;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;

import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.databinding.ActivityStorePageBinding;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseStoreRepository;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseOrderRepository;
import ca.georgebrown.roseflowerdeliveryapp.utils.OrderDialogManager;
import ca.georgebrown.roseflowerdeliveryapp.view.ui.orders.StoreOrdersViewModel;

public class StorePage extends AppCompatActivity {

    private ActivityStorePageBinding binding;
    private Handler handler;
    private Runnable updateStatusRunnable;
    private boolean isAcceptingOrders = true; // Initially accepting orders
    private String storeId;
    private FirebaseStoreRepository storeRepository;
    private SharedPreferences prefs;
    private static final String PREFS_NAME = "OrderOncePrefs";

    // Global orders ViewModel to listen for orders
    private StoreOrdersViewModel ordersViewModel;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityStorePageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Get store ID (for example, from FirebaseAuth)
        storeId = FirebaseAuth.getInstance().getCurrentUser().getUid();
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);
        storeRepository = new FirebaseStoreRepository();

        // Set initial store status (accepting orders)
        updateStoreStatus();

        // Set up periodic status updates (every 60 seconds)
        handler = new Handler(Looper.getMainLooper());
        updateStatusRunnable = new Runnable() {
            @Override
            public void run() {
                if (isAcceptingOrders) {
                    updateStoreStatus();
                    handler.postDelayed(this, 60000);
                }
            }
        };
        handler.postDelayed(updateStatusRunnable, 60000);

        // Set up navigation (BottomNavigationView and NavController)
        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.navigation_dashboard,
                R.id.navigation_store,
                R.id.navigation_settings
        ).build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_store_page);
        NavigationUI.setupWithNavController(binding.navView, navController);

        // Initialize the orders ViewModel for global listening
        ordersViewModel = new ViewModelProvider(this).get(StoreOrdersViewModel.class);
        ordersViewModel.getOrdersLiveData().observe(this, new Observer<List<Order>>() {
            @Override
            public void onChanged(List<Order> orders) {
                checkForNewOrders(orders);
            }
        });
        ordersViewModel.listenToOrders(storeId);
    }

    /**
     * Updates the store's status in Firestore.
     */
    private void updateStoreStatus() {
        storeRepository.updateStoreStatus(storeId, isAcceptingOrders, Timestamp.now(), new FirebaseStoreRepository.RepositoryCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                // Successfully updated store status.
            }
            @Override
            public void onFailure(Exception e) {
                // Optionally handle the failure.
            }
        });
    }

    /**
     * Checks all fetched orders for new orders (status == 1) that haven’t yet been prompted,
     * and displays the new order popup.
     */
    private void checkForNewOrders(List<Order> orders) {
        if (orders == null) return;
        for (Order order : orders) {
            if (order.getStatus() == 1) {
                boolean prompted = prefs.getBoolean("prompted_" + order.getId(), false);
                if (!prompted) {
                    prefs.edit().putBoolean("prompted_" + order.getId(), true).apply();

                    OrderDialogManager.showOrderPopup(this, order, new OrderDialogManager.OrderDialogActionListener() {
                        @Override
                        public void onAccept(Order order) {
                            ordersViewModel.updateOrderStatus(storeId, order.getId(), 2, newOrderStatusCallback("ACCEPT"));
                        }
                        @Override
                        public void onReject(Order order) {
                            ordersViewModel.updateOrderStatus(storeId, order.getId(), 3, newOrderStatusCallback("REJECT"));
                        }
                    });

                }
            }
        }
    }

    /**
     * Helper callback for order status updates.
     */
    private FirebaseOrderRepository.StatusUpdateCallback newOrderStatusCallback(String action) {
        return new FirebaseOrderRepository.StatusUpdateCallback() {
            @Override
            public void onStatusUpdated() {
                Log.d("StorePage", "Order " + action + " successful.");
            }
            @Override
            public void onError(Exception e) {
                Log.e("StorePage", "Error " + action + ": " + e.getMessage());
            }
        };
    }

    /**
     * Called (for example, from a dashboard fragment) to change whether orders are accepted.
     */
    public void setAcceptingOrders(boolean status) {
        isAcceptingOrders = status;
        updateStoreStatus();
        if (isAcceptingOrders && handler != null) {
            handler.removeCallbacks(updateStatusRunnable);
            handler.postDelayed(updateStatusRunnable, 60000);
        } else if (!isAcceptingOrders && handler != null) {
            handler.removeCallbacks(updateStatusRunnable);
        }
    }

    /**
     * Called when the logout button is clicked.
     * Updates store status to not accepting orders then logs out.
     */
    public void storeLogoutBtn(View view) {
        if (handler != null) {
            handler.removeCallbacks(updateStatusRunnable);
        }
        storeRepository.updateStoreStatus(storeId, false, Timestamp.now(), new FirebaseStoreRepository.RepositoryCallback<Void>() {
            @Override
            public void onSuccess(Void result) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(StorePage.this, LoginPage.class);
                startActivity(intent);
                finish();
            }
            @Override
            public void onFailure(Exception e) {
                FirebaseAuth.getInstance().signOut();
                Intent intent = new Intent(StorePage.this, LoginPage.class);
                startActivity(intent);
                finish();
            }
        });
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        if (handler != null) {
            handler.removeCallbacks(updateStatusRunnable);
        }
    }
}
