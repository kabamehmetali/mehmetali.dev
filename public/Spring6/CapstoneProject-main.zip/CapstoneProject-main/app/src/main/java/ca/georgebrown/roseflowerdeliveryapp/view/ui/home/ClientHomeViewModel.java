package ca.georgebrown.roseflowerdeliveryapp.view.ui.home;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;

import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QuerySnapshot;

import java.util.ArrayList;
import java.util.List;

import ca.georgebrown.roseflowerdeliveryapp.model.Item;
import ca.georgebrown.roseflowerdeliveryapp.model.Users;
import ca.georgebrown.roseflowerdeliveryapp.repository.ClientHomeRepository;
import javax.annotation.Nullable;

public class ClientHomeViewModel extends ViewModel {

    private final MutableLiveData<List<Users>> closestStoresLiveData = new MutableLiveData<>();
    private final MutableLiveData<List<Users>> randomStoresLiveData = new MutableLiveData<>();
    private final MutableLiveData<List<Item>> closestItemsLiveData = new MutableLiveData<>();
    private final MutableLiveData<List<Item>> randomItemsLiveData = new MutableLiveData<>();

    private ClientHomeRepository repository;

    public ClientHomeViewModel() {
        repository = new ClientHomeRepository();
    }

    public LiveData<List<Users>> getClosestStores() {
        return closestStoresLiveData;
    }

    public LiveData<List<Users>> getRandomStores() {
        return randomStoresLiveData;
    }

    public LiveData<List<Item>> getClosestItems() {
        return closestItemsLiveData;
    }

    public LiveData<List<Item>> getRandomItems() {
        return randomItemsLiveData;
    }

    // Load "closest" stores based on the current location.
    public void loadClosestStores(android.location.Location location) {
        Query query = repository.getStoresQuery(location);
        query.addSnapshotListener((@Nullable QuerySnapshot snapshot,
                                   @Nullable FirebaseFirestoreException error) -> {
            if (error != null || snapshot == null) {
                closestStoresLiveData.setValue(new ArrayList<>());
                return;
            }
            List<Users> stores = new ArrayList<>();
            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                Users store = doc.toObject(Users.class);
                if (store != null) {
                    store.setId(doc.getId());
                    stores.add(store);
                }
            }
            closestStoresLiveData.setValue(stores);
        });
    }

    // Load "random" stores.
    public void loadRandomStores() {
        Query query = repository.getStoresQuery(null);
        query.addSnapshotListener((@Nullable QuerySnapshot snapshot,
                                   @Nullable FirebaseFirestoreException error) -> {
            if (error != null || snapshot == null) {
                randomStoresLiveData.setValue(new ArrayList<>());
                return;
            }
            List<Users> stores = new ArrayList<>();
            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                Users store = doc.toObject(Users.class);
                if (store != null) {
                    store.setId(doc.getId());
                    stores.add(store);
                }
            }
            randomStoresLiveData.setValue(stores);
        });
    }

    // Load "random" items. If an item is missing storeId, extract it from the document path.
    public void loadRandomItems() {
        Query query = repository.getRandomItemsQuery();
        query.addSnapshotListener((@Nullable QuerySnapshot snapshot,
                                   @Nullable FirebaseFirestoreException error) -> {
            if (error != null || snapshot == null) {
                randomItemsLiveData.setValue(new ArrayList<>());
                return;
            }
            List<Item> items = new ArrayList<>();
            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                Item item = doc.toObject(Item.class);
                if (item != null) {
                    // If storeId is missing, try to extract it from the document path.
                    if (item.getStoreId() == null || item.getStoreId().isEmpty()) {
                        // For example, if the document path is:
                        // "users/STORE_ID/categories/CAT_ID/items/ITEM_ID"
                        String path = doc.getReference().getPath(); // e.g. "users/STORE_ID/categories/CAT_ID/items/ITEM_ID"
                        String[] parts = path.split("/");
                        if (parts.length >= 2) {
                            String storeIdFromPath = parts[1];
                            item.setStoreId(storeIdFromPath);
                        }
                    }
                    items.add(item);
                }
            }
            randomItemsLiveData.setValue(items);
        });
    }

    // Load items from a specific store.
    public void loadClosestItems(String storeIdentifier) {
        Query query = repository.getItemsForStore(storeIdentifier);
        query.addSnapshotListener((@Nullable QuerySnapshot snapshot,
                                   @Nullable FirebaseFirestoreException error) -> {
            if (error != null || snapshot == null) {
                closestItemsLiveData.setValue(new ArrayList<>());
                return;
            }
            List<Item> items = snapshot.toObjects(Item.class);
            closestItemsLiveData.setValue(items);
        });
    }

    // Real-time search: if query is empty, reload default data. Otherwise, perform search queries.
    public void search(String queryText) {
        String trimmedQuery = queryText.trim().toLowerCase();
        if(trimmedQuery.isEmpty()){
            loadRandomStores();
            loadRandomItems();
            return;
        }

        Query storeSearchQuery = repository.getStoresSearchQuery(trimmedQuery);
        storeSearchQuery.addSnapshotListener((@Nullable QuerySnapshot snapshot,
                                              @Nullable FirebaseFirestoreException error) -> {
            if (error != null || snapshot == null) {
                closestStoresLiveData.setValue(new ArrayList<>());
                randomStoresLiveData.setValue(new ArrayList<>());
                return;
            }
            List<Users> stores = new ArrayList<>();
            for (DocumentSnapshot doc : snapshot.getDocuments()) {
                Users store = doc.toObject(Users.class);
                if (store != null) {
                    store.setId(doc.getId());
                    stores.add(store);
                }
            }
            closestStoresLiveData.setValue(stores);
            randomStoresLiveData.setValue(stores);
        });

        Query itemSearchQuery = repository.getItemsSearchQuery(trimmedQuery);
        itemSearchQuery.addSnapshotListener((@Nullable QuerySnapshot snapshot,
                                             @Nullable FirebaseFirestoreException error) -> {
            if (error != null || snapshot == null) {
                closestItemsLiveData.setValue(new ArrayList<>());
                randomItemsLiveData.setValue(new ArrayList<>());
                return;
            }
            List<Item> items = snapshot.toObjects(Item.class);
            closestItemsLiveData.setValue(items);
            randomItemsLiveData.setValue(items);
        });
    }
}
