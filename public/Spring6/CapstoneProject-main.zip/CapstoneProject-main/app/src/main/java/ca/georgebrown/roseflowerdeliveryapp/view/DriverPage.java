package ca.georgebrown.roseflowerdeliveryapp.view;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.google.android.material.bottomnavigation.BottomNavigationView;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.GeoPoint;

import ca.georgebrown.roseflowerdeliveryapp.R;
import ca.georgebrown.roseflowerdeliveryapp.databinding.ActivityDriverPageBinding;
import ca.georgebrown.roseflowerdeliveryapp.model.Location;
import ca.georgebrown.roseflowerdeliveryapp.model.Order;
import ca.georgebrown.roseflowerdeliveryapp.repository.FirebaseOrderRepository;
import ca.georgebrown.roseflowerdeliveryapp.utils.DriverLocationManager;
import ca.georgebrown.roseflowerdeliveryapp.utils.DriverOrderDialogManager;
import ca.georgebrown.roseflowerdeliveryapp.utils.DriverAssignmentManager;

public class DriverPage extends AppCompatActivity {

    private ActivityDriverPageBinding binding;
    private FirebaseFirestore firestore;
    private String driverId;
    private SharedPreferences prefs;
    private static final String PREFS_NAME = "DriverDeliveryPrefs";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        binding = ActivityDriverPageBinding.inflate(getLayoutInflater());
        setContentView(binding.getRoot());

        // Setup bottom navigation.
        BottomNavigationView navView = findViewById(R.id.nav_view);
        AppBarConfiguration appBarConfiguration = new AppBarConfiguration.Builder(
                R.id.driver_navigation_orders, R.id.navigation_dashboard, R.id.driver_navigation_profile)
                .build();
        NavController navController = Navigation.findNavController(this, R.id.nav_host_fragment_activity_driver_page);
        NavigationUI.setupWithNavController(binding.navView, navController);

        // Start live location updates.
        DriverLocationManager.getInstance(this).startLocationUpdates();

        driverId = FirebaseAuth.getInstance().getUid();
        firestore = FirebaseFirestore.getInstance();
        prefs = getSharedPreferences(PREFS_NAME, MODE_PRIVATE);

        // Listen for orders assigned to this driver with status = 4 ("Ready for Pickup")
        listenForAssignedOrders();
    }

    /**
     * Listen for orders with assignedDriverId equal to this driver and status = 4.
     */
    private void listenForAssignedOrders() {
        firestore.collectionGroup("orderItems")
                .whereEqualTo("assignedDriverId", driverId)
                .whereEqualTo("status", 4)
                .addSnapshotListener((snapshots, e) -> {
                    if (e != null) {
                        Log.e("DriverPage", "Error listening for orders: " + e.getMessage());
                        return;
                    }
                    if (snapshots != null && !snapshots.isEmpty()) {
                        snapshots.getDocuments().forEach(doc -> {
                            Order order = doc.toObject(Order.class);
                            if (order != null) {
                                order.setId(doc.getId());
                                if (order.getUserId() == null || order.getUserId().trim().isEmpty()) {
                                    Log.e("DriverPage", "Order " + order.getId() + " does not have a valid store id.");
                                    return;
                                }
                                // For demonstration, we use a hardcoded store location and address.
                                final GeoPoint storeLocation = new GeoPoint(43.6532, -79.3832);
                                final String storeAddress = "123 Main St, Toronto, ON";

                                // Use the deliveryLocation from the order.
                                Location deliveryLocation = order.getDeliveryLocation();
                                final String deliveryAddress;
                                if (deliveryLocation == null) {
                                    // Fallback if deliveryLocation is null.
                                    deliveryLocation = new Location();
                                    deliveryLocation.setLatitude(43.7000);
                                    deliveryLocation.setLongitude(-79.4000);
                                    deliveryLocation.setFormattedAddress("456 Queen St, Toronto, ON");
                                    deliveryAddress = "456 Queen St, Toronto, ON";
                                } else {
                                    // Use formattedAddress if available; otherwise use 'address' field.
                                    if (deliveryLocation.getFormattedAddress() != null && !deliveryLocation.getFormattedAddress().isEmpty()) {
                                        deliveryAddress = deliveryLocation.getFormattedAddress();
                                    } else if (deliveryLocation.getAddress() != null && !deliveryLocation.getAddress().isEmpty()) {
                                        deliveryAddress = deliveryLocation.getAddress();
                                    } else {
                                        deliveryAddress = "Delivery Address";
                                    }
                                }
                                final Location finalDeliveryLocation = deliveryLocation;
                                final DocumentReference orderDocRef = doc.getReference();
                                runOnUiThread(() -> {
                                    DriverOrderDialogManager.showDriverOrderPopup(
                                            DriverPage.this,
                                            order,
                                            driverId,
                                            storeLocation,
                                            storeAddress,
                                            finalDeliveryLocation,
                                            deliveryAddress,
                                            new DriverOrderDialogManager.DriverOrderDialogListener() {
                                                @Override
                                                public void onAccept(Order order) {
                                                    // Update order status to 5 (Driver Accepted)
                                                    orderDocRef.update("status", 5)
                                                            .addOnSuccessListener(aVoid -> {
                                                                Log.d("DriverPage", "Order " + order.getId() + " accepted.");
                                                                firestore.collection("drivers")
                                                                        .document(driverId)
                                                                        .update("orderAccepted", true)
                                                                        .addOnSuccessListener(aVoid2 -> Log.d("DriverPage", "Driver marked as busy."))
                                                                        .addOnFailureListener(err -> Log.e("DriverPage", "Error marking busy: " + err.getMessage()));

                                                                // Launch DeliveryNavigationActivity with address data
                                                                Intent intent = new Intent(DriverPage.this, DeliveryNavigationActivity.class);
                                                                intent.putExtra("orderId", order.getId());
                                                                intent.putExtra("storeId", order.getUserId());
                                                                intent.putExtra("store_lat", storeLocation.getLatitude());
                                                                intent.putExtra("store_lng", storeLocation.getLongitude());
                                                                intent.putExtra("delivery_lat", finalDeliveryLocation.getLatitude());
                                                                intent.putExtra("delivery_lng", finalDeliveryLocation.getLongitude());
                                                                intent.putExtra("store_address", storeAddress);
                                                                intent.putExtra("delivery_address", deliveryAddress);
                                                                startActivity(intent);
                                                            })
                                                            .addOnFailureListener(err -> Log.e("DriverPage", "Error updating order status: " + err.getMessage()));
                                                }

                                                @Override
                                                public void onReject(Order order) {
                                                    // Update order status to 6 (Driver Rejected) and clear assigned driver,
                                                    // then re-initiate assignment.
                                                    orderDocRef.update("status", 6, "assignedDriverId", null)
                                                            .addOnSuccessListener(aVoid -> {
                                                                Log.d("DriverPage", "Order " + order.getId() + " rejected.");
                                                                new DriverAssignmentManager(DriverPage.this).assignDriver(order.getUserId(), order, storeLocation);
                                                            })
                                                            .addOnFailureListener(err -> Log.e("DriverPage", "Error updating order status on rejection: " + err.getMessage()));
                                                }
                                            }
                                    );
                                });
                            }
                        });
                    }
                });
    }

    public void driverLogoutBtn(View view) {
        FirebaseAuth.getInstance().signOut();
        Intent intent = new Intent(this, LoginPage.class);
        startActivity(intent);
        finish();
    }
}
