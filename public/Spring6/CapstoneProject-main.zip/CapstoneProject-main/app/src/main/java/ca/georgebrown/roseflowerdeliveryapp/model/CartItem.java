package ca.georgebrown.roseflowerdeliveryapp.model;

import com.google.gson.annotations.SerializedName;
import java.io.Serializable;
import java.util.List;

public class CartItem implements Serializable {

    private static final long serialVersionUID = 1L;

    @SerializedName("item")
    private Item item;

    @SerializedName("quantity")
    private int quantity;

    @SerializedName("note")
    private String note;

    // If you have selectedExtras
    @SerializedName("selectedExtras")
    private List<ExtraItem> selectedExtras;

    public CartItem() {
    }

    public CartItem(Item item, int quantity, String note, List<ExtraItem> selectedExtras) {
        this.item = item;
        this.quantity = quantity;
        this.note = note;
        this.selectedExtras = selectedExtras;
    }

    public Item getItem() {
        return item;
    }
    public void setItem(Item item) {
        this.item = item;
    }

    public int getQuantity() {
        return quantity;
    }
    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }

    public String getNote() {
        return note;
    }
    public void setNote(String note) {
        this.note = note;
    }

    public List<ExtraItem> getSelectedExtras() {
        return selectedExtras;
    }
    public void setSelectedExtras(List<ExtraItem> selectedExtras) {
        this.selectedExtras = selectedExtras;
    }
}
